import { supabase } from "./supabase";

export interface InvigilatorExam {
  id: string;
  title: string;
  course_code: string;
  starts_at: string;
  ends_at: string | null;
  duration_min: number | null;
  status: string;
}

export interface RosterRow {
  student_id: string;
  full_name: string;
  roll_no: string;
  course_code: string;
  year: number | null;
  checkin_status: "waiting" | "approved" | null;
  code: number | null;
  phone_checked: boolean | null;
  requested_at: string | null;
  approved_at: string | null;
  attempt_status: "in_progress" | "submitted" | null;
  started_at: string | null;
  submitted_at: string | null;
  deadline_at: string | null;
  strikes: number | null;
  last_event: string | null;
  last_event_at: string | null;
  /** All strike events ever recorded for this attempt history. */
  strikes_total: number | null;
  /** Locked out right now (no check-in row until they request again). */
  ejected: boolean | null;
  /** How many times this student has been locked out. */
  ejections: number | null;
  eject_reason: "long_absence" | "strikes" | null;
}

export interface InvigProctorRules {
  strike_ms: number;
  lock_ms: number;
  limit: number;
}

/** Fallback until the server rules arrive; one constant only. */
export const DEFAULT_INV_PROCTOR_RULES: InvigProctorRules = {
  strike_ms: 3000,
  lock_ms: 12000,
  limit: 3,
};

export async function fetchProctorRules() {
  const { data, error } = await supabase.rpc("proctor_rules");
  return { data: (data ?? null) as InvigProctorRules | null, error };
}

let rulesCache: Promise<InvigProctorRules | null> | null = null;

/** Fetch once per page load, then serve the cached promise. */
export function getProctorRulesCached(): Promise<InvigProctorRules | null> {
  if (!rulesCache) {
    rulesCache = fetchProctorRules().then((r) => (r.error ? null : r.data));
  }
  return rulesCache;
}

export interface StudentEventRow {
  kind: "tab_hidden" | "back" | "offline" | "copy" | "paste" | string;
  duration_ms: number | null;
  occurred_at: string;
  is_strike: boolean | null;
}

export interface AwayRow {
  student_id: string;
  full_name: string | null;
  roll_no: string | null;
  away_since: string;
  away_kind: "tab_hidden" | "window_shrunk" | string;
  server_now: string;
}

/** Live "away now" signals: approved + in-progress students with an
 *  uncleared "left" ping. No strikes are created by this signal. */
export async function fetchAway(examId: string) {
  const { data, error } = await supabase.rpc("invigilator_away", { p_exam_id: examId });
  return { data: (data ?? []) as AwayRow[], error };
}

/** Newest-first event timeline for one student (≤100 rows, RLS-scoped). */
export async function fetchStudentEvents(examId: string, studentId: string) {
  const { data, error } = await supabase.rpc("invigilator_events", {
    p_exam_id: examId,
    p_student_id: studentId,
  });
  return { data: (data ?? []) as StudentEventRow[], error };
}

/** Exams assigned to this invigilator (RLS-scoped). */
export async function fetchMyExams() {
  const { data, error } = await supabase
    .from("exams")
    .select("id, title, course_code, starts_at, ends_at, duration_min, status")
    .order("starts_at", { ascending: true });
  return { data: (data ?? []) as InvigilatorExam[], error };
}

export async function fetchRoster(examId: string) {
  const { data, error } = await supabase.rpc("invigilator_roster", { p_exam_id: examId });
  return { data: (data ?? []) as RosterRow[], error };
}

/** Server rejects unless phoneChecked is true and the code still matches. */
export async function approveCheckin(
  examId: string,
  studentId: string,
  code: number,
  phoneChecked: boolean,
) {
  const { error } = await supabase.rpc("approve_checkin", {
    p_exam_id: examId,
    p_student_id: studentId,
    p_code: code,
    p_phone_checked: phoneChecked,
  });
  return { error };
}

/** Deletes the check-in; the student's login is kicked, answers are kept. */
export async function revokeCheckin(examId: string, studentId: string) {
  const { error } = await supabase.rpc("revoke_checkin", {
    p_exam_id: examId,
    p_student_id: studentId,
  });
  return { error };
}

/** Grades attempts stuck in progress long after the deadline. */
export async function finalizeExpired(examId: string) {
  const { data, error } = await supabase.rpc("finalize_expired", { p_exam_id: examId });
  return { data: (data ?? 0) as number, error };
}

export async function signOutInvigilator() {
  await supabase.auth.signOut();
}
