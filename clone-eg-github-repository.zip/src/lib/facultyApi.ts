import { supabase } from "./supabase";

/* ------------------------------------------------------------------ */
/*  Faculty auth                                                       */
/* ------------------------------------------------------------------ */

export type FacultySignInResult =
  | { ok: true; name: string }
  | { ok: false; reason: "invalid" | "network" };

/** Identifier may be a full email or a bare staff username.
 *  Wrong password and "not a faculty account" are indistinguishable to the caller. */
export async function signInFaculty(identifier: string, password: string): Promise<FacultySignInResult> {
  const id = identifier.trim();
  const email = id.includes("@") ? id.toLowerCase() : `${id.toLowerCase()}@staff.chm.local`;

  const { data, error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) {
    return { ok: false, reason: error.status === 400 || error.status === 401 ? "invalid" : "network" };
  }

  const uid = data.user?.id;
  const { data: profile, error: pErr } = await supabase
    .from("profiles")
    .select("full_name, role")
    .eq("id", uid ?? "")
    .maybeSingle();

  if (pErr || !profile || profile.role !== "faculty") {
    await supabase.auth.signOut();
    return { ok: false, reason: "invalid" };
  }
  return { ok: true, name: profile.full_name || id };
}

export async function signOutFaculty(): Promise<void> {
  await supabase.auth.signOut();
}

/* ------------------------------------------------------------------ */
/*  Dashboard data                                                     */
/* ------------------------------------------------------------------ */

export interface FacultyCohort {
  year: number | null;
  department: string | null;
}

export interface FacultyExam {
  id: string;
  title: string;
  course_code: string;
  starts_at: string;
  ends_at: string | null;
  duration_min: number | null;
  status: "draft" | "published" | "closed" | string;
  exam_cohorts: FacultyCohort[] | null;
  questions: { count: number }[] | null;
  results_published?: boolean | null;
  results_released_at?: string | null;
}

/** One embedded request; if the embeds fail, fall back to separate queries. */
export async function fetchFacultyExams() {
  const { data, error } = await supabase
    .from("exams")
    .select(
      "id, title, course_code, starts_at, ends_at, duration_min, status, results_published, results_released_at, exam_cohorts(year, department), questions(count)",
    )
    .order("starts_at", { ascending: false });

  if (!error) return { data: (data ?? []) as FacultyExam[], error: null };

  const base = await supabase
    .from("exams")
    .select("id, title, course_code, starts_at, ends_at, duration_min, status, results_published, results_released_at")
    .order("starts_at", { ascending: false });
  if (base.error) return { data: [] as FacultyExam[], error: base.error };

  const rows = (base.data ?? []) as FacultyExam[];
  const ids = rows.map((r) => r.id);
  let cohorts: { exam_id: string; year: number | null; department: string | null }[] = [];
  const counts: Record<string, number> = {};
  if (ids.length > 0) {
    const c = await supabase.from("exam_cohorts").select("exam_id, year, department").in("exam_id", ids);
    if (!c.error) cohorts = (c.data ?? []) as typeof cohorts;
    const q = await supabase.from("questions").select("exam_id").in("exam_id", ids);
    if (!q.error) {
      for (const row of (q.data ?? []) as { exam_id: string }[]) {
        counts[row.exam_id] = (counts[row.exam_id] ?? 0) + 1;
      }
    }
  }
  for (const r of rows) {
    r.exam_cohorts = cohorts.filter((c) => c.exam_id === r.id).map((c) => ({ year: c.year, department: c.department }));
    r.questions = [{ count: counts[r.id] ?? 0 }];
  }
  return { data: rows, error: null };
}

export async function fetchFacultyServerTime() {
  const { data, error } = await supabase.rpc("server_time");
  return { data: (data ?? null) as string | null, error };
}

/** Only true once the window closed >60s ago and no attempt is in progress. */
export async function fetchExamIsOver(examId: string) {
  const { data, error } = await supabase.rpc("exam_is_over", { p_exam_id: examId });
  return { data: Boolean(data), error };
}

export async function deleteDraftExam(examId: string) {
  const { data, error } = await supabase
    .from("exams")
    .delete()
    .eq("id", examId)
    .eq("status", "draft")
    .select("id");
  if (error) return { error };
  if (!data || data.length === 0) {
    return { error: { message: "Draft not found, or it was already scheduled." } as { message: string } };
  }
  return { error: null };
}

/* ------------------------------------------------------------------ */
/*  Results (read-only; RLS returns rows only once the exam is over)   */
/* ------------------------------------------------------------------ */

export interface FacultyResultRow {
  attempt_id: string;
  exam_id: string;
  student_id: string;
  score_marks: number | null;
  total_marks: number | null;
  passed: boolean | null;
  profiles: { full_name: string | null; roll_no: string | null } | null;
}

export async function fetchFacultyResults(examId: string) {
  const { data, error } = await supabase
    .from("results")
    .select("attempt_id, exam_id, student_id, score_marks, total_marks, passed, profiles(full_name, roll_no)")
    .eq("exam_id", examId);
  return { data: (data ?? []) as unknown as FacultyResultRow[], error };
}

/* ------------------------------------------------------------------ */
/*  Exam builder (drafts) + review/lock plumbing for the next task     */
/* ------------------------------------------------------------------ */

export interface DraftExamInput {
  title: string;
  course_code: string;
  starts_at: string | null;
  ends_at: string | null;
  duration_min: number;
  pass_pct: number;
  negative_fraction: number;
}

export interface DraftCohortInput {
  year: number;
  department: string | null;
}

export interface DraftQuestionInput {
  prompt: string;
  options: string[];
  correct: number | null;
  marks: number;
}

export interface DraftOut {
  exam: DraftExamInput;
  cohorts: DraftCohortInput[];
  invigilator_ids: string[];
  questions: DraftQuestionInput[];
}

export interface InvigilatorOption {
  id: string;
  full_name: string | null;
}

/** null id creates a fresh draft; an id replaces it atomically. Returns the uuid. */
export async function saveDraft(
  id: string | null,
  exam: DraftExamInput,
  cohorts: DraftCohortInput[],
  questions: DraftQuestionInput[],
) {
  const { data, error } = await supabase.rpc("save_draft", {
    p_exam_id: id,
    p_exam: exam,
    p_cohorts: cohorts,
    p_questions: questions,
  });
  return { data: (data ?? null) as string | null, error };
}

export async function getDraft(examId: string) {
  const { data, error } = await supabase.rpc("get_draft", { p_exam_id: examId });
  return { data: (data ?? null) as DraftOut | null, error };
}

export async function listInvigilators() {
  const { data, error } = await supabase.rpc("list_invigilators");
  return { data: (data ?? []) as InvigilatorOption[], error };
}

export async function setInvigilators(examId: string, ids: string[]) {
  const { error } = await supabase.rpc("set_invigilators", { p_exam_id: examId, p_ids: ids });
  return { error };
}

/* --- used by the Review & lock step (next task) --- */

export async function examProblems(examId: string) {
  const { data, error } = await supabase.rpc("exam_problems", { p_exam_id: examId });
  return { data: (data ?? []) as string[], error };
}

export async function lockExam(examId: string, passphrase: string) {
  const { data, error } = await supabase.rpc("lock_exam", { p_exam_id: examId, p_passphrase: passphrase });
  return { data, error };
}

export async function unlockExam(examId: string, passphrase: string) {
  const { data, error } = await supabase.rpc("unlock_exam", { p_exam_id: examId, p_passphrase: passphrase });
  return {
    data: (data ?? null) as { ok: boolean; reason?: "wrong_passphrase" | "too_many_attempts" } | null,
    error,
  };
}

/* ------------------------------------------------------------------ */
/*  Result release to students                                         */
/* ------------------------------------------------------------------ */

export interface PublishResultsData {
  ok: boolean;
  already?: boolean;
  count?: number;
  released_at?: string;
  reason?: "wrong_passphrase" | "too_many_attempts";
}

export interface ExamReleaseState {
  results_published: boolean | null;
  results_released_at: string | null;
}

/** Idempotent release; wrong passphrase arrives as a normal { ok:false } value. */
export async function publishResults(examId: string, passphrase: string) {
  const { data, error } = await supabase.rpc("publish_results", {
    p_exam_id: examId,
    p_passphrase: passphrase,
  });
  return { data: (data ?? null) as PublishResultsData | null, error };
}

export async function fetchExamReleaseState(examId: string) {
  const { data, error } = await supabase
    .from("exams")
    .select("results_published, results_released_at")
    .eq("id", examId)
    .maybeSingle();
  return { data: (data ?? null) as ExamReleaseState | null, error };
}
