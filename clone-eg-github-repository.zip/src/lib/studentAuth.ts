import { supabase } from "./supabase";

export interface StudentProfile {
  fullName: string;
  rollNo: string;
  degree: string;
  year: string;
}

/** College ID shape: course letters + 4-digit joining year + "-" + 4–5 digit UID. */
const ID_RE = /^[A-Za-z]{2,10}\d{4}-\d{4,5}$/;

export function validateStudentId(id: string): boolean {
  return ID_RE.test(id.trim());
}

export function studentIdToEmail(id: string): string {
  return `${id.trim().toLowerCase()}@students.chm.local`;
}

const ORDINALS: Record<number, string> = { 1: "1st", 2: "2nd", 3: "3rd", 4: "4th" };

type LoginOutcome =
  | { ok: true; profile: StudentProfile }
  | { ok: false; reason: "format" | "auth" };

export async function loginStudent(id: string, password: string): Promise<LoginOutcome> {
  if (!validateStudentId(id)) return { ok: false, reason: "format" };

  const { error } = await supabase.auth.signInWithPassword({
    email: studentIdToEmail(id),
    password,
  });
  if (error) return { ok: false, reason: "auth" };

  // RLS restricts this read to the signed-in user's own row.
  const { data, error: rowErr } = await supabase.from("profiles").select("*").single();
  if (rowErr || !data || data.role !== "student") {
    // Authenticated but not a provisioned student — drop the session.
    await supabase.auth.signOut();
    return { ok: false, reason: "auth" };
  }

  const yr = Number(data.year);
  return {
    ok: true,
    profile: {
      fullName: data.full_name ?? "",
      rollNo: data.roll_no ?? id.trim().toUpperCase(),
      degree: data.degree ?? "",
      year: `${ORDINALS[yr] ?? yr} Year`,
    },
  };
}

export async function logoutStudent(): Promise<void> {
  await supabase.auth.signOut();
}
