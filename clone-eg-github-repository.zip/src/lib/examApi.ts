import { supabase } from "./supabase";
import type { Exam } from "../data/exams";

/**
 * ExamList view model: the shared Exam shape plus DB-only extras.
 * Additive interface — the shared Exam type in data/exams.ts is untouched,
 * so ExamFlow and the rules screen keep working unchanged.
 */
export interface StudentExam extends Exam {
  /** Server-provided window end (static exams derive it instead). */
  endsAt: number;
  source: "db";
  /** From results.passed — drives the pass/fail badge on completed cards. */
  passed?: boolean;
  /** Submitted, but no graded results row exists yet. */
  pending?: boolean;
}

interface ExamRow {
  id: string;
  title: string;
  course_code: string;
  starts_at: string;
  ends_at: string | null;
  duration_min: number | null;
  pass_pct: number | null;
  status: string;
}

interface AttemptRow {
  id: string;
  exam_id: string;
  submitted_at: string | null;
  status: string;
}

interface ResultRow {
  exam_id: string;
  score_marks: number | null;
  total_marks: number | null;
  passed: boolean | null;
}

/** Published exams visible to this student (RLS filters cohort + status). */
export async function fetchExamsForStudent() {
  const { data, error } = await supabase
    .from("exams")
    .select("id, title, course_code, starts_at, ends_at, duration_min, pass_pct, status")
    .order("starts_at", { ascending: true });
  return { data: (data ?? []) as ExamRow[], error };
}

/** The signed-in student's own attempts (RLS scopes the rows). */
export async function fetchMyAttempts() {
  const { data, error } = await supabase
    .from("attempts")
    .select("id, exam_id, submitted_at, status");
  return { data: (data ?? []) as AttemptRow[], error };
}

/** The student's graded results (RLS scopes the rows). */
export async function fetchMyResults() {
  const { data, error } = await supabase
    .from("results")
    .select("exam_id, score_marks, total_marks, passed");
  return { data: (data ?? []) as ResultRow[], error };
}

const ACCENTS: Exam["accent"][] = ["amber", "violet", "neutral"];
const accentFor = (id: string) =>
  ACCENTS[[...id].reduce((s, c) => s + c.charCodeAt(0), 0) % ACCENTS.length];

const fmtSubmitted = (iso: string) =>
  "Submitted on " +
  new Date(iso).toLocaleString("en-US", {
    month: "long",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
  });

/* ------------------------------------------------------------------ */
/*  Live exam engine: start, questions, server clock, autosave         */
/* ------------------------------------------------------------------ */

export interface DbAttempt {
  id: string;
  exam_id: string;
  started_at: string;
  deadline_at: string;
  status: string;
}

export interface DbQuestion {
  id: string;
  exam_id: string;
  position: number;
  prompt: string;
  options: { id: string; text: string }[];
  marks: number;
}

export interface DbAnswer {
  question_id: string;
  selected_option: string;
}

/** Everything ExamFlow needs to run a server-backed attempt. */
export interface DbExamSession {
  attemptId: string;
  examId: string;
  /** Epoch ms of the hard deadline (server-side). */
  deadlineAt: number;
  /** serverNow - clientNow at fetch time; keeps the countdown honest. */
  clockOffset: number;
  questions: DbQuestion[];
  initialAnswers: Record<string, string>;
}

/** Creates or resumes the student's attempt. RLS + the RPC enforce cohort,
 *  window and single-attempt rules; failures arrive as `error`. */
export async function startAttempt(examId: string) {
  const { data, error } = await supabase.rpc("start_attempt", { p_exam_id: examId });
  return { data: (data ?? null) as DbAttempt | null, error };
}

export async function fetchServerTime() {
  const { data, error } = await supabase.rpc("server_time");
  return { data: (data ?? null) as string | null, error };
}

export interface AttemptClock {
  deadline_at: string;
  status: string;
  server_now: string;
  /** False when this login's approved check-in no longer exists. */
  session_ok: boolean;
  strikes?: number;
  ejected?: boolean;
  reason?: "long_absence" | "strikes" | null;
  rules?: ProctorRules;
}

export interface ProctorLogResult {
  logged: number;
  strikes: number;
  limit: number;
  ejected: boolean;
  reason: "long_absence" | "strikes" | null;
  rules?: ProctorRules;
}

/** Server-owned proctor thresholds — never hardcode these in UI copy. */
export interface ProctorRules {
  strike_ms: number;
  lock_ms: number;
  limit: number;
}

export async function fetchProctorRules() {
  const { data, error } = await supabase.rpc("proctor_rules");
  return { data: (data ?? null) as ProctorRules | null, error };
}

let rulesCache: Promise<ProctorRules | null> | null = null;

/** Fetches once per page load, then serves the cached promise. */
export function getProctorRules(): Promise<ProctorRules | null> {
  if (!rulesCache) {
    rulesCache = fetchProctorRules().then((r) => (r.error ? null : r.data));
  }
  return rulesCache;
}

/** Live deadline + server clock for an open attempt. Returns NULL (with no
 *  error) when the attempt doesn't belong to the caller — RLS enforced. */
export async function fetchAttemptClock(attemptId: string) {
  const { data, error } = await supabase.rpc("attempt_clock", { p_attempt_id: attemptId });
  return { data: (data ?? null) as AttemptClock | null, error };
}

/** Readable only while the student's own attempt is in progress (RLS). */
export async function fetchQuestionsForAttempt(examId: string) {
  const { data, error } = await supabase
    .from("questions")
    .select("id, exam_id, position, prompt, options, marks")
    .eq("exam_id", examId)
    .order("position", { ascending: true });
  return { data: (data ?? []) as DbQuestion[], error };
}

export async function fetchAnswersForAttempt(attemptId: string) {
  const { data, error } = await supabase
    .from("answers")
    .select("question_id, selected_option")
    .eq("attempt_id", attemptId);
  return { data: (data ?? []) as DbAnswer[], error };
}

export interface SubmitAttemptResult {
  attempt_id: string;
  status: string;
  submitted_at: string;
  answered: number;
  total_questions: number;
}

export type ProctorEventKind = "tab_hidden" | "window_shrunk" | "back" | "offline" | "copy" | "paste";

export interface ProctorEventPayload {
  kind: ProctorEventKind;
  duration_ms: number;
  ago_ms: number;
}

/** Live away signal for the invigilator — no strikes, no events. */
export async function setAway(attemptId: string, away: boolean, kind: "tab_hidden" | "window_shrunk") {
  const { error } = await supabase.rpc("set_away", {
    p_attempt_id: attemptId,
    p_away: away,
    p_kind: kind,
  });
  return { error };
}

/** keepalive fetch so a "left" survives tab close / navigation. Never throws. */
export async function sendAwayKeepalive(
  attemptId: string,
  away: boolean,
  kind: "tab_hidden" | "window_shrunk",
  accessToken: string,
): Promise<boolean> {
  try {
    const res = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/rest/v1/rpc/set_away`, {
      method: "POST",
      keepalive: true,
      headers: {
        apikey: import.meta.env.VITE_SUPABASE_ANON_KEY,
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ p_attempt_id: attemptId, p_away: away, p_kind: kind }),
    });
    return res.ok;
  } catch {
    return false;
  }
}

/** Silent proctor telemetry. Server caps batches at 50, attempts at 500,
 *  and reports the running strike tally + ejection flag on every call. */
export async function logProctorEvents(attemptId: string, events: ProctorEventPayload[]) {
  const { data, error } = await supabase.rpc("log_proctor_events", {
    p_attempt_id: attemptId,
    p_events: events,
  });
  return { data: (data ?? null) as ProctorLogResult | null, error };
}

/** Batched save of dirty answers. RLS closes the door when the attempt ends. */
export async function saveAnswers(attemptId: string, answers: Record<string, string>) {
  const { data, error } = await supabase.rpc("save_answers", {
    p_attempt_id: attemptId,
    p_answers: answers,
  });
  return {
    data: (data ?? null) as { saved: number; server_now: string } | null,
    error,
  };
}

/** Server-side grading. Idempotent, never returns the score. Carries the full
 *  local answer map so a final submit never depends on prior syncs. */
export async function submitAttempt(attemptId: string, answers?: Record<string, string>) {
  const { data, error } = await supabase.rpc("submit_attempt", {
    p_attempt_id: attemptId,
    p_answers: answers ?? null,
  });
  return { data: (data ?? null) as SubmitAttemptResult | null, error };
}

/* ------------------------------------------------------------------ */
/*  Invigilator check-in                                               */
/* ------------------------------------------------------------------ */

export interface CheckinRequestResult {
  status: "waiting" | "approved";
  code: number;
}

export interface CheckinRow {
  exam_id: string;
  session_id: string | null;
  code: number | null;
  status: "waiting" | "approved" | string;
}

/** Binds a check-in request to THIS login session (RPC enforces single session). */
export async function requestCheckin(examId: string) {
  const { data, error } = await supabase.rpc("request_checkin", { p_exam_id: examId });
  return { data: (data ?? null) as CheckinRequestResult | null, error };
}

/** The student's own check-in row for an exam (RLS-scoped; null when reset). */
export async function fetchMyCheckin(examId: string) {
  const { data, error } = await supabase
    .from("exam_checkins")
    .select("exam_id, session_id, code, status")
    .eq("exam_id", examId)
    .maybeSingle();
  return { data: (data ?? null) as CheckinRow | null, error };
}

/** Decodes the Supabase access token to read this login's session_id claim. */
export async function getMyAuthSessionId(): Promise<string | null> {
  const { data } = await supabase.auth.getSession();
  const token = data.session?.access_token;
  if (!token) return null;
  try {
    const payload = token.split(".")[1] ?? "";
    const json = atob(payload.replace(/-/g, "+").replace(/_/g, "/"));
    const claims = JSON.parse(json) as { session_id?: string };
    return claims.session_id ?? null;
  } catch {
    return null;
  }
}

export async function upsertAnswer(attemptId: string, questionId: string, selectedOption: string) {
  // updated_at is set server-side by the column default — never trust the client clock.
  const { error } = await supabase.from("answers").upsert(
    {
      attempt_id: attemptId,
      question_id: questionId,
      selected_option: selectedOption,
    },
    { onConflict: "attempt_id,question_id" },
  );
  return { error };
}

/** Merges exams with the student's submitted attempts into display models.
 *  State (live/soon/missed) is derived client-side for display only —
 *  the server enforces the real attempt rules. */
export function mergeForStudent(
  exams: ExamRow[],
  attempts: AttemptRow[],
  results: ResultRow[],
): StudentExam[] {
  const submitted = new Map<string, AttemptRow>();
  for (const a of attempts) {
    if (a.status === "submitted" || a.submitted_at) submitted.set(a.exam_id, a);
  }
  const graded = new Map<string, ResultRow>();
  for (const r of results) graded.set(r.exam_id, r);

  return exams.map((e) => {
    const a = submitted.get(e.id);
    const r = graded.get(e.id);
    const startsAt = new Date(e.starts_at).getTime();
    const endsAt = e.ends_at
      ? new Date(e.ends_at).getTime()
      : startsAt + (e.duration_min ?? 0) * 60_000;
    const passPct = e.pass_pct ?? 40;
    // Graded cards show marks from the results row; ungraded ones hide marks
    // downstream since the client never sees a total before release.
    const total = r?.total_marks ?? 100;

    const model: StudentExam = {
      id: e.id,
      course: e.course_code,
      code: e.course_code,
      accent: accentFor(e.id),
      title: e.title,
      durationMin: e.duration_min ?? 0,
      marks: total,
      passing: r ? Math.round((passPct / 100) * total) : passPct,
      credit: "",
      blurb: "",
      cohortYears: [],
      startsAt,
      endsAt,
      status: a ? "completed" : "available",
      source: "db",
      questions: [],
    };

    if (a) {
      model.submittedLabel = a.submitted_at ? fmtSubmitted(a.submitted_at) : "Submitted";
      if (r) {
        model.score = r.score_marks ?? 0;
        model.passed = Boolean(r.passed);
      } else {
        model.pending = true; // submitted, awaiting faculty grading/release
      }
    }
    return model;
  });
}
