import { supabase } from "./supabase";

export interface CourseOption {
  code: string;
  name: string;
  department: string | null;
}

/** Active courses, alphabetical — RLS scopes the SELECT to signed-in users. */
export async function fetchCourses() {
  const { data, error } = await supabase
    .from("courses")
    .select("code, name, department")
    .eq("active", true)
    .order("name", { ascending: true });
  return { data: (data ?? []) as CourseOption[], error };
}
