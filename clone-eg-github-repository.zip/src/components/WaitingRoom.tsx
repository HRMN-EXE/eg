import { useCallback, useEffect, useRef, useState } from "react";
import {
  ArrowLeft,
  ArrowRight,
  CalendarClock,
  CheckCircle2,
  Hourglass,
  KeyRound,
  RefreshCw,
  ShieldAlert,
  Timer,
} from "lucide-react";
import type { Exam } from "../data/exams";
import {
  fetchMyCheckin,
  fetchServerTime,
  getMyAuthSessionId,
  requestCheckin,
  type CheckinRow,
  type StudentExam,
} from "../lib/examApi";

type Notify = (kind: "success" | "info" | "error", msg: string) => void;

interface WaitingRoomProps {
  exam: Exam;
  /** Runs the existing start_attempt + question-load flow. Resolves false on failure. */
  onStart: () => Promise<boolean>;
  onLeave: () => void;
  onNotify: Notify;
}

const fmtCountdown = (ms: number) => {
  const s = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  return h > 0
    ? `${h}:${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`
    : `${m}:${String(sec).padStart(2, "0")}`;
};

export default function WaitingRoom({ exam, onStart, onLeave, onNotify }: WaitingRoomProps) {
  const [row, setRow] = useState<CheckinRow | null>(null);
  const [missing, setMissing] = useState(false);
  const [takeover, setTakeover] = useState(false);
  const [offset, setOffset] = useState(0);
  const [nowTick, setNowTick] = useState(() => Date.now());
  const [requesting, setRequesting] = useState(false);
  const [starting, setStarting] = useState(false);

  const inFlight = useRef(false);
  const mySid = useRef<string | null | undefined>(undefined);

  /* ---------- one poll tick: check-in row + server clock ---------- */
  const sync = useCallback(async () => {
    if (inFlight.current) return; // never two polls at once
    inFlight.current = true;
    try {
      if (mySid.current === undefined) mySid.current = await getMyAuthSessionId();
      const [rowRes, tRes] = await Promise.all([fetchMyCheckin(exam.id), fetchServerTime()]);
      if (tRes.data) setOffset(new Date(tRes.data).getTime() - Date.now());
      if (rowRes.error) return; // silent: keep last known state, retry next tick
      const r = rowRes.data;
      if (!r) {
        setRow(null);
        setMissing(true);
        return;
      }
      if (mySid.current && r.session_id && r.session_id !== mySid.current) {
        setTakeover(true);
        return; // stop polling for this login
      }
      setMissing(false);
      setTakeover(false);
      setRow(r);
    } finally {
      inFlight.current = false;
    }
  }, [exam.id]);

  /* ---------- poll every 5s + on tab focus + on reconnect ---------- */
  useEffect(() => {
    let alive = true;
    void sync();
    const timer = window.setInterval(() => {
      if (alive) void sync();
    }, 5000);
    const onVisibility = () => {
      if (document.visibilityState === "visible") void sync();
    };
    const onOnline = () => void sync();
    document.addEventListener("visibilitychange", onVisibility);
    window.addEventListener("online", onOnline);
    return () => {
      alive = false;
      window.clearInterval(timer);
      document.removeEventListener("visibilitychange", onVisibility);
      window.removeEventListener("online", onOnline);
    };
  }, [sync]);

  // Local heartbeat so the countdown tracks between polls.
  useEffect(() => {
    const t = window.setInterval(() => setNowTick(Date.now()), 1000);
    return () => window.clearInterval(t);
  }, []);

  const serverNow = nowTick + offset;
  const approved = row?.status === "approved";
  const opensIn = exam.startsAt - serverNow;
  const endsAt = (exam as Partial<StudentExam>).endsAt ?? exam.startsAt + exam.durationMin * 60_000;
  const windowOpen = serverNow >= exam.startsAt && serverNow <= endsAt;

  const requestAgain = async () => {
    if (requesting) return;
    setRequesting(true);
    const { error } = await requestCheckin(exam.id);
    setRequesting(false);
    if (error) {
      onNotify("error", error.message);
      return;
    }
    setMissing(false);
    setTakeover(false);
    mySid.current = undefined; // re-resolve on next poll
    void sync();
  };

  const start = async () => {
    if (starting || !approved || !windowOpen) return;
    setStarting(true);
    const ok = await onStart();
    if (!ok) setStarting(false); // error already surfaced; stay in the room
  };

  const code = row?.code != null ? String(row.code).padStart(4, "0") : "····";

  return (
    <div className="relative z-10 mx-auto flex min-h-dvh w-full max-w-[560px] flex-col justify-center px-5 py-10 sm:px-6">
      {/* ---------- header ---------- */}
      <button
        type="button"
        onClick={onLeave}
        className="animate-rise mx-auto flex items-center gap-2 text-[12.5px] font-extrabold text-neutral-500 transition-colors hover:text-rose-500"
      >
        <ArrowLeft className="h-4 w-4" strokeWidth={2.6} />
        Leave the waiting room
      </button>

      {/* ---------- card ---------- */}
      <section className="animate-rise mt-5 overflow-hidden rounded-[28px] bg-white shadow-[0_28px_60px_-22px_rgba(190,80,115,0.45)]" style={{ animationDelay: "80ms" }}>
        <div className="h-[6px] w-full bg-gradient-to-r from-amber-400 via-rose-400 to-violet-400" />
        <div className="px-6 pb-7 pt-7 text-center sm:px-8">
          <p className="text-[10.5px] font-extrabold tracking-[0.2em] text-fuchsia-600">
            {exam.course} · {exam.code}
          </p>
          <h1 className="mt-2 text-[28px] font-extrabold leading-tight tracking-tight text-neutral-950">
            Waiting for invigilator
          </h1>
          <p className="mt-1 text-[14px] font-extrabold text-neutral-600">{exam.title}</p>

          {/* takeover / reset states */}
          {takeover ? (
            <div className="animate-rise mt-6 flex items-start gap-3 rounded-2xl bg-rose-50 p-4 text-left ring-1 ring-rose-200">
              <ShieldAlert className="mt-0.5 h-5 w-5 shrink-0 text-rose-600" strokeWidth={2.2} />
              <p className="text-[13px] font-bold leading-relaxed text-rose-700">
                Another login took over this check-in. Ask the invigilator to reset you.
              </p>
            </div>
          ) : missing ? (
            <div className="animate-rise mt-6 rounded-2xl bg-amber-50 p-5 ring-1 ring-amber-200">
              <p className="text-[13.5px] font-extrabold text-amber-800">Your check-in was reset.</p>
              <button
                type="button"
                onClick={() => void requestAgain()}
                disabled={requesting}
                className="mt-3 inline-flex items-center gap-2 rounded-full bg-neutral-950 px-5 py-2.5 text-[12.5px] font-extrabold text-white transition-all hover:-translate-y-0.5 hover:bg-neutral-800 active:scale-[0.98] disabled:cursor-default"
              >
                <RefreshCw className={"h-4 w-4 " + (requesting ? "animate-spin" : "")} strokeWidth={2.4} />
                {requesting ? "Requesting…" : "Request check-in again"}
              </button>
            </div>
          ) : (
            <>
              {/* the code */}
              <div className="mt-7 rounded-[22px] bg-[#f3ede7] p-6">
                <span className="flex items-center justify-center gap-2 text-[11px] font-extrabold tracking-[0.14em] text-neutral-500">
                  <KeyRound className="h-3.5 w-3.5 text-fuchsia-600" strokeWidth={2.4} />
                  SHOW THIS CODE TO THE INVIGILATOR
                </span>
                <p className="mt-3 font-mono text-[64px] font-extrabold leading-none tracking-[0.18em] text-neutral-950">
                  {code}
                </p>
              </div>

              {/* live status */}
              {approved ? (
                <div className="animate-rise mt-5 flex flex-col items-center gap-3">
                  <span className="flex items-center gap-2 rounded-full bg-emerald-50 px-4 py-2 text-[12px] font-extrabold text-emerald-700 ring-1 ring-emerald-200">
                    <CheckCircle2 className="h-4 w-4" strokeWidth={2.4} />
                    Approved. Waiting for the exam to open.
                  </span>
                  {!windowOpen && opensIn > 0 && (
                    <span className="flex items-center gap-2 font-mono text-[22px] font-extrabold text-neutral-800">
                      <CalendarClock className="h-5 w-5 text-fuchsia-600" strokeWidth={2.2} />
                      Opens in {fmtCountdown(opensIn)}
                    </span>
                  )}
                </div>
              ) : (
                <span className="mt-5 inline-flex animate-pulse items-center gap-2 rounded-full bg-amber-100 px-4 py-2 text-[12px] font-extrabold text-amber-700 ring-1 ring-amber-200">
                  <Hourglass className="h-4 w-4" strokeWidth={2.4} />
                  Waiting for approval…
                </span>
              )}

              {/* start gate */}
              <button
                type="button"
                onClick={() => void start()}
                disabled={!approved || !windowOpen || starting}
                className={
                  "group mt-6 flex h-[54px] w-full items-center justify-center gap-2.5 rounded-full text-[15px] font-extrabold transition-all duration-300 " +
                  (approved && windowOpen
                    ? "bg-neutral-950 text-white shadow-[0_20px_40px_-16px_rgba(0,0,0,0.6)] hover:-translate-y-0.5 hover:bg-neutral-800 active:scale-[0.99]"
                    : "cursor-not-allowed bg-neutral-200/80 text-neutral-400")
                }
              >
                {starting ? (
                  <>
                    <RefreshCw className="h-4 w-4 animate-spin" strokeWidth={2.4} />
                    Starting…
                  </>
                ) : (
                  <>
                    Start exam
                    <ArrowRight className={"h-4 w-4 " + (approved && windowOpen ? "transition-transform group-hover:translate-x-1" : "")} strokeWidth={2.6} />
                  </>
                )}
              </button>

              {!approved && (
                <p className="mt-3 text-[11px] font-semibold text-neutral-400">
                  The Start button unlocks once the invigilator approves this code.
                </p>
              )}
              {approved && !windowOpen && (
                <p className="mt-3 text-[11px] font-semibold text-neutral-400">
                  The exam window hasn't opened yet — this page updates automatically.
                </p>
              )}
            </>
          )}
        </div>
      </section>

      <p className="animate-rise mt-5 flex items-center justify-center gap-1.5 text-[10.5px] font-bold text-neutral-500" style={{ animationDelay: "160ms" }}>
        <Timer className="h-3 w-3 text-emerald-600" strokeWidth={2.4} />
        Status refreshes every 5 seconds and when you return to this tab.
      </p>
    </div>
  );
}
