import { useEffect, useMemo, useState } from "react";
import {
  AlertTriangle,
  ArrowLeft,
  ArrowRight,
  Award,
  BadgeCheck,
  BookOpen,
  Check,
  ClipboardCheck,
  Hourglass,
  Loader2,
  Lock,
  Save,
  Scale,
  Share2,
  ShieldCheck,
  Target,
  Timer,
  User as UserIcon,
} from "lucide-react";
import { passPctOf, type Exam } from "../data/exams";
import { getProctorRules, type ProctorRules } from "../lib/examApi";
import type { Profile } from "./CandidateProfile";

interface ExamRulesProps {
  exam: Exam;
  profile: Profile | null;
  onBegin: () => void | Promise<void>;
  onReturn: () => void;
  /** True while the attempt is being started server-side. */
  starting?: boolean;
  /** DB exams gate entry behind an invigilator check-in. */
  checkin?: boolean;
  onRequestCheckin?: () => void;
}

const CHECKLIST: { label: string }[] = [
  { label: "Do Not Disturb is ON and alarms are off" },
  { label: "Auto-lock is set to Never" },
  { label: "Battery above 50% or charging" },
  { label: "I will not switch apps or tabs" },
  { label: "Phone assistants are switched off (Gemini, Google Assistant, Siri, Circle to Search)" },
];

/** Number-free wording until the server rules arrive; never invent numbers. */
const SPLIT_RULE = " Using another window, an assistant overlay or split screen counts the same way.";

const tabRuleText = (r: { strike_ms: number; lock_ms: number; limit: number } | null) =>
  r
    ? `Leaving the exam tab or app for ${Math.round(r.strike_ms / 1000)} seconds or more counts as a warning. ${r.limit} warnings, or one absence of ${Math.round(r.lock_ms / 1000)} seconds or more, lock your exam until the invigilator clears you. Every absence is recorded and shown to the invigilator.${SPLIT_RULE}`
    : `Leaving the exam tab or app counts as a warning. Too many warnings, or one long absence, lock your exam until the invigilator clears you. Every absence is recorded and shown to the invigilator.${SPLIT_RULE}`;

const emailFromName = (name: string) =>
  name.trim().toLowerCase().split(/\s+/).filter(Boolean).join(".") + "@university.edu";

const deptFromDegree = (degree: string) => "Department of " + degree.replace(/^[A-Za-z]+\.\s*/, "");

export default function ExamRules({ exam, profile, onBegin, onReturn, starting, checkin, onRequestCheckin }: ExamRulesProps) {
  const [acknowledged, setAcknowledged] = useState(false);
  const [checks, setChecks] = useState<boolean[]>(CHECKLIST.map(() => false));
  const allChecked = checks.every(Boolean);
  const [proctorRules, setProctorRules] = useState<ProctorRules | null>(null);

  useEffect(() => {
    let alive = true;
    void getProctorRules().then((r) => {
      if (alive && r) setProctorRules(r);
    });
    return () => {
      alive = false;
    };
  }, []);

  // Stable per-mount proctor session identifier.
  const sessionId = useMemo(() => "SEC-" + Math.floor(1000 + Math.random() * 9000), []);

  const name = profile?.fullName ?? "Candidate";
  const email = emailFromName(name);
  const department = deptFromDegree(profile?.degree ?? "Computer Science");
  const qCount = exam.questions.length || exam.questionCount || 0;
  // Server-backed exams don't reveal counts or marks before the attempt starts.
  const countsKnown = qCount > 0;
  const marksKnown = exam.questions.length > 0 || Boolean(exam.questionCount);

  const stats = [
    { label: "Duration", value: `${exam.durationMin} Minutes`, icon: Timer, tint: "bg-pink-100 text-pink-600", show: true },
    { label: "Total Questions", value: `${qCount} MCQs`, icon: BookOpen, tint: "bg-violet-100 text-violet-600", show: countsKnown },
    { label: "Passing Mark", value: `${passPctOf(exam)}%`, icon: Target, tint: "bg-amber-100 text-amber-600", show: true },
    { label: "Max Score", value: `${exam.marks} Points`, icon: Award, tint: "bg-fuchsia-100 text-fuchsia-600", show: marksKnown },
  ].filter((s) => s.show);

  const rules = [
    {
      icon: AlertTriangle,
      tint: "text-amber-500",
      title: "Single Attempt Only",
      body: "Once started, this assessment cannot be paused, reset, or retaken.",
    },
    {
      icon: Hourglass,
      tint: "text-orange-500",
      title: "Strict Auto-Submit",
      body: `The test automatically submits the instant the ${exam.durationMin}:00 timer hits zero.`,
    },
    {
      icon: Lock,
      tint: "text-neutral-800",
      title: "Confidential Results",
      body: "In accordance with university policy, grades and answer keys will not be displayed to students upon completion.",
    },
    {
      icon: Save,
      tint: "text-violet-600",
      title: "Instant Autosave",
      body: "Every selected answer is encrypted and synced to the database immediately.",
    },
  ];

  return (
    <div className="relative z-10 mx-auto flex min-h-dvh w-full max-w-[560px] flex-col px-5 pb-10 pt-6 sm:px-6">
      {/* ---------- top bar ---------- */}
      <header className="animate-rise flex items-center gap-3">
        <button
          type="button"
          onClick={onReturn}
          aria-label="Back to exam list"
          className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full text-neutral-800 transition-all hover:-translate-x-0.5 hover:bg-white/70 hover:text-rose-500 active:scale-95"
        >
          <ArrowLeft className="h-5 w-5" strokeWidth={2.6} />
        </button>
        <h1 className="min-w-0 flex-1 truncate text-[19px] font-extrabold tracking-tight text-neutral-900">
          Exam Rules &amp; Confirmation
        </h1>
        <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-violet-600 text-white shadow-[0_8px_18px_-6px_rgba(124,58,237,0.6)]">
          <UserIcon className="h-[17px] w-[17px]" strokeWidth={2.3} />
        </span>
      </header>

      {/* ---------- step + proctored pills ---------- */}
      <div className="animate-rise mt-5 flex flex-wrap items-center gap-2.5" style={{ animationDelay: "60ms" }}>
        <span className="flex min-w-0 flex-1 items-center gap-2 rounded-full bg-yellow-300 px-3.5 py-2 basis-52">
          <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-neutral-900" />
          <span className="truncate text-[9.5px] font-extrabold tracking-[0.1em] text-neutral-900">
            STEP 2 OF 2 • FINAL VERIFICATION
          </span>
        </span>
        <span className="flex shrink-0 items-center gap-1.5 rounded-full bg-violet-200 px-3 py-2 text-[10px] font-extrabold text-violet-700">
          <ShieldCheck className="h-3 w-3" strokeWidth={2.6} />
          Proctored
        </span>
      </div>

      {/* ---------- heading ---------- */}
      <div className="animate-rise mt-5" style={{ animationDelay: "110ms" }}>
        <h2 className="font-serif text-[26px] font-bold leading-tight tracking-tight text-neutral-950 sm:text-[30px]">
          Exam Rules &amp; Confirmation
        </h2>
        <p className="mt-2 max-w-[42ch] text-[13.5px] font-medium leading-relaxed text-neutral-500">
          Verify your candidate information and review exam protocol before initiating the timer.
        </p>
      </div>

      {/* ---------- exam summary card ---------- */}
      <section
        className="animate-rise mt-6 rounded-[24px] bg-gradient-to-br from-amber-200 via-yellow-200 to-amber-100 p-5 shadow-[0_20px_44px_-20px_rgba(217,164,6,0.55)]"
        style={{ animationDelay: "160ms" }}
      >
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <p className="text-[10px] font-extrabold tracking-[0.16em] text-amber-800">MIDTERM ASSESSMENT</p>
            <h3 className="mt-1.5 font-serif text-[22px] font-bold leading-snug tracking-tight text-neutral-950">
              {exam.title}
            </h3>
            <p className="mt-1.5 text-[11.5px] font-bold text-amber-900/70">Code: {exam.code}</p>
          </div>
          <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-yellow-300 text-neutral-800 shadow-inner">
            <Share2 className="h-5 w-5" strokeWidth={2.2} />
          </span>
        </div>

        <div className="mt-4 grid grid-cols-2 gap-2">
          {stats.map((s) => (
            <div key={s.label} className="flex items-center gap-2.5 rounded-xl border border-amber-300/60 bg-white/55 p-3">
              <span className={"flex h-9 w-9 shrink-0 items-center justify-center rounded-full " + s.tint}>
                <s.icon className="h-4 w-4" strokeWidth={2.2} />
              </span>
              <span className="min-w-0">
                <span className="block text-[9.5px] font-extrabold tracking-wide text-neutral-500">{s.label.toUpperCase()}</span>
                <span className="block truncate text-[13px] font-extrabold text-neutral-900">{s.value}</span>
              </span>
            </div>
          ))}
        </div>
      </section>

      {/* ---------- candidate profile confirmation ---------- */}
      <section
        className="animate-rise mt-5 rounded-[24px] bg-white p-5 shadow-[0_20px_44px_-22px_rgba(190,80,115,0.45)]"
        style={{ animationDelay: "210ms" }}
      >
        <div className="flex items-center gap-3">
          <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-pink-100">
            <BadgeCheck className="h-[18px] w-[18px] text-pink-600" strokeWidth={2.2} />
          </span>
          <h3 className="min-w-0 flex-1 font-serif text-[18px] font-bold leading-snug tracking-tight text-neutral-950">
            Candidate Profile Confirmation
          </h3>
          <span className="shrink-0 rounded-full bg-neutral-100 px-3 py-1 text-[10px] font-extrabold text-neutral-500">
            Verified
          </span>
        </div>

        <div className="mt-4 rounded-xl bg-[#f3ede7] px-4 py-3">
          <p className="font-serif text-[16px] font-bold text-neutral-900">{name}</p>
          <p className="mt-0.5 text-[11.5px] font-semibold text-neutral-500">{email}</p>
        </div>

        <div className="mt-2 grid grid-cols-2 gap-2">
          <div className="rounded-xl bg-[#f3ede7] px-4 py-3">
            <p className="text-[9.5px] font-extrabold tracking-wide text-neutral-500">ROLL NUMBER</p>
            <p className="mt-1 truncate text-[13px] font-extrabold text-neutral-900">{profile?.rollNo ?? "—"}</p>
          </div>
          <div className="rounded-xl bg-[#f3ede7] px-4 py-3">
            <p className="text-[9.5px] font-extrabold tracking-wide text-neutral-500">DEGREE PROGRAM</p>
            <p className="mt-1 truncate text-[13px] font-extrabold text-neutral-900">{profile?.degree ?? "—"}</p>
          </div>
        </div>

        <div className="mt-2 rounded-xl bg-[#f3ede7] px-4 py-3">
          <p className="text-[9.5px] font-extrabold tracking-wide text-neutral-500">DEPARTMENT</p>
          <p className="mt-1 text-[13px] font-extrabold text-neutral-900">{department}</p>
        </div>
      </section>

      {/* ---------- regulations ---------- */}
      <section
        className="animate-rise mt-5 rounded-[24px] bg-violet-100/80 p-5 ring-1 ring-violet-200/70"
        style={{ animationDelay: "260ms" }}
      >
        <div className="flex items-center gap-3">
          <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-violet-500 text-white shadow-[0_8px_18px_-6px_rgba(139,92,246,0.7)]">
            <Scale className="h-[18px] w-[18px]" strokeWidth={2.2} />
          </span>
          <div>
            <h3 className="font-serif text-[18px] font-bold leading-tight tracking-tight text-neutral-950">
              Examination Regulations
            </h3>
            <p className="text-[10.5px] font-extrabold text-violet-700 underline underline-offset-2">
              Must read before proceeding
            </p>
          </div>
        </div>

        <div className="mt-4 flex flex-col gap-2.5">
          {rules.map((r) => (
            <div
              key={r.title}
              className="flex items-start gap-3 rounded-xl bg-white p-4 shadow-[0_8px_20px_-12px_rgba(124,58,237,0.35)] transition-transform duration-200 hover:-translate-y-0.5"
            >
              <r.icon className={"mt-0.5 h-[18px] w-[18px] shrink-0 " + r.tint} strokeWidth={2.2} />
              <div>
                <p className="text-[13px] font-extrabold text-neutral-900">{r.title}</p>
                <p className="mt-1 text-[12px] font-medium leading-relaxed text-neutral-600">{r.body}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ---------- acknowledgement ---------- */}
      <button
        type="button"
        onClick={() => setAcknowledged((a) => !a)}
        aria-pressed={acknowledged}
        className={
          "animate-rise mt-5 flex w-full items-start gap-3.5 rounded-[24px] p-5 text-left transition-all duration-200 active:scale-[0.99] " +
          (acknowledged
            ? "bg-violet-300/80 ring-2 ring-violet-500 shadow-[0_18px_40px_-18px_rgba(124,58,237,0.6)]"
            : "bg-violet-200/80 ring-1 ring-violet-200 hover:bg-violet-200")
        }
        style={{ animationDelay: "310ms" }}
      >
        <span
          className={
            "mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-md transition-all duration-200 " +
            (acknowledged ? "bg-violet-600 shadow-[0_5px_12px_-4px_rgba(124,58,237,0.7)]" : "bg-white ring-1 ring-violet-300")
          }
        >
          {acknowledged && <Check className="h-3.5 w-3.5 text-white" strokeWidth={3.4} />}
        </span>
        <span>
          <span className="block text-[13.5px] font-extrabold text-neutral-900">Candidate Acknowledgement</span>
          <span className="mt-1 block text-[12.5px] font-medium leading-relaxed text-neutral-700">
            I have verified my student details, understand all exam regulations, and am ready to start my timed single attempt.
          </span>
        </span>
      </button>

      {/* ---------- pre-exam checklist (check-in flow) ---------- */}
      {checkin && (
        <section
          className={
            "animate-rise mt-5 rounded-[24px] bg-white p-5 shadow-[0_20px_44px_-22px_rgba(190,80,115,0.45)] transition-all duration-300 " +
            (acknowledged ? "" : "pointer-events-none opacity-40")
          }
          style={{ animationDelay: "330ms" }}
        >
          <div className="flex items-center gap-3">
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-amber-100">
              <ClipboardCheck className="h-[18px] w-[18px] text-amber-600" strokeWidth={2.2} />
            </span>
            <div>
              <h3 className="text-[15px] font-extrabold tracking-tight text-neutral-950">Pre-exam checklist</h3>
              <p className="text-[10.5px] font-bold text-neutral-500">Tick all five before requesting check-in</p>
            </div>
            <span
              className={
                "ml-auto rounded-full px-2.5 py-1 text-[10px] font-extrabold " +
                (allChecked ? "bg-emerald-100 text-emerald-700" : "bg-neutral-100 text-neutral-500")
              }
            >
              {checks.filter(Boolean).length}/{CHECKLIST.length}
            </span>
          </div>

          <div className="mt-4 flex flex-col gap-2">
            {CHECKLIST.map((item, i) => {
              const on = checks[i];
              return (
                <button
                  key={item.label}
                  type="button"
                  onClick={() => setChecks((c) => c.map((v, j) => (j === i ? !v : v)))}
                  aria-pressed={on}
                  className={
                    "flex items-start gap-3 rounded-2xl border-2 px-4 py-3 text-left transition-all duration-200 active:scale-[0.99] " +
                    (on ? "border-emerald-300 bg-emerald-50" : "border-neutral-100 bg-neutral-50/60 hover:border-neutral-200")
                  }
                >
                  <span
                    className={
                      "mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-lg transition-all duration-200 " +
                      (on ? "bg-emerald-500 shadow-[0_5px_12px_-4px_rgba(16,185,129,0.6)]" : "bg-white ring-2 ring-neutral-300")
                    }
                  >
                    {on && <Check className="h-3.5 w-3.5 text-white" strokeWidth={3.4} />}
                  </span>
                  <span className="min-w-0">
                    <span className={"block text-[12.5px] font-bold " + (on ? "text-neutral-900" : "text-neutral-600")}>
                      {item.label}
                    </span>
                    {item.label === "I will not switch apps or tabs" && (
                      <span className="mt-1 block text-[10.5px] font-semibold leading-relaxed text-neutral-500">
                        {tabRuleText(proctorRules)}
                      </span>
                    )}
                  </span>
                </button>
              );
            })}
          </div>
        </section>
      )}

      {/* ---------- start / request check-in ---------- */}
      <button
        type="button"
        onClick={() => {
          if (starting) return;
          if (checkin) {
            if (acknowledged && allChecked) onRequestCheckin?.();
          } else if (acknowledged) {
            void onBegin();
          }
        }}
        aria-disabled={starting || !acknowledged || (checkin && !allChecked)}
        className={
          "animate-rise group mt-6 flex h-[56px] w-full items-center justify-center gap-2.5 rounded-full text-[15px] font-extrabold transition-all duration-300 " +
          (starting
            ? "cursor-wait bg-neutral-800 text-white shadow-[0_22px_44px_-16px_rgba(0,0,0,0.6)]"
            : acknowledged && (!checkin || allChecked)
              ? "bg-neutral-950 text-white shadow-[0_22px_44px_-16px_rgba(0,0,0,0.6)] hover:-translate-y-0.5 hover:bg-neutral-800 active:scale-[0.99]"
              : "cursor-not-allowed bg-neutral-400/70 text-white/80 shadow-none")
        }
        style={{ animationDelay: "360ms" }}
      >
        {starting ? (
          <>
            <Loader2 className="h-4 w-4 animate-spin" />
            {checkin ? "Requesting check-in…" : "Starting attempt…"}
          </>
        ) : checkin ? (
          <>
            Request check-in
            <ArrowRight
              className={"h-4 w-4 transition-transform " + (acknowledged && allChecked ? "group-hover:translate-x-1" : "")}
              strokeWidth={2.6}
            />
          </>
        ) : (
          <>
            Start Exam ({exam.durationMin} Mins)
            <ArrowRight
              className={"h-4 w-4 transition-transform " + (acknowledged ? "group-hover:translate-x-1" : "")}
              strokeWidth={2.6}
            />
          </>
        )}
      </button>

      {/* ---------- return ---------- */}
      <button
        type="button"
        onClick={onReturn}
        className="animate-rise mx-auto mt-5 flex items-center gap-2 text-[13px] font-extrabold text-neutral-700 transition-colors hover:text-rose-500"
        style={{ animationDelay: "400ms" }}
      >
        <ArrowLeft className="h-4 w-4" strokeWidth={2.6} />
        Return to Exam List
      </button>

      {/* ---------- session footer ---------- */}
      <div className="animate-rise mt-6 flex justify-center" style={{ animationDelay: "440ms" }}>
        <span className="flex items-center gap-2 rounded-full bg-[#f3ede7] px-4 py-2 text-[10px] font-extrabold tracking-wide text-neutral-600">
          <span className="h-1.5 w-1.5 rounded-full bg-amber-500" />
          Session ID: {sessionId}
        </span>
      </div>
    </div>
  );
}
