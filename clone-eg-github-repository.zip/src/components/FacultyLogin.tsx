import { useState, type FormEvent } from "react";
import {
  AlertCircle,
  ArrowLeft,
  ArrowRight,
  Eye,
  EyeOff,
  ExternalLink,
  GraduationCap,
  HelpCircle,
  Loader2,
  Lock,
  UserRound,
} from "lucide-react";
import { signInFaculty } from "../lib/facultyApi";

type Notify = (kind: "success" | "info" | "error", msg: string) => void;

interface FacultyLoginProps {
  onBack: () => void;
  onSwitchToStudent: () => void;
  onNotify: Notify;
  onSuccess: (name: string) => void;
}

const fieldBase =
  "mt-2 h-12 w-full rounded-full border border-transparent bg-[#f3ede7] pl-12 pr-4 text-[13.5px] font-bold text-neutral-900 outline-none transition-all placeholder:font-medium placeholder:text-neutral-400 focus:border-rose-300 focus:bg-white focus:ring-4 focus:ring-rose-100";

export default function FacultyLogin({ onBack, onSwitchToStudent, onNotify, onSuccess }: FacultyLoginProps) {
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [checking, setChecking] = useState(false);
  const [shake, setShake] = useState(false);

  const fail = (msg: string) => {
    setError(msg);
    setShake(true);
    window.setTimeout(() => setShake(false), 500);
  };

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (checking) return;
    setError(null);

    if (!identifier.trim() || !password) {
      fail("Enter your username and password.");
      return;
    }

    setChecking(true);
    const res = await signInFaculty(identifier, password);
    setChecking(false);
    if (!res.ok) {
      fail(
        res.reason === "network"
          ? "Could not reach the server. Check your connection and try again."
          : "Invalid credentials",
      );
      return;
    }
    onSuccess(res.name);
  };

  const ring = error
    ? "border-rose-300 focus:border-rose-400 focus:ring-rose-100"
    : "border-transparent focus:border-rose-300";

  return (
    <div className="relative z-10 mx-auto flex min-h-dvh w-full max-w-[560px] flex-col px-5 pb-10 pt-6 sm:px-6">
      {/* ---------- top bar ---------- */}
      <header className="animate-rise flex items-center">
        <button
          type="button"
          onClick={onBack}
          aria-label="Back"
          className="group flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-white text-neutral-700 shadow-[0_8px_20px_-8px_rgba(190,80,115,0.4)] transition-all hover:-translate-x-0.5 hover:text-rose-500 active:scale-95"
        >
          <ArrowLeft className="h-[18px] w-[18px]" strokeWidth={2.6} />
        </button>
        <span className="ml-3 text-[15px] font-extrabold tracking-tight text-neutral-900">Faculty Login</span>
      </header>

      {/* ---------- heading (sits above the card from md up) ---------- */}
      <div className="animate-rise mt-8 flex flex-col items-center text-center md:mt-10" style={{ animationDelay: "70ms" }}>
        <span className="flex items-center gap-2 rounded-full bg-yellow-300 px-4 py-2 shadow-[0_10px_24px_-10px_rgba(234,179,8,0.6)]">
          <GraduationCap className="h-3.5 w-3.5 text-neutral-900" strokeWidth={2.6} />
          <span className="text-[10px] font-extrabold tracking-[0.14em] text-neutral-900">FACULTY LOGIN</span>
        </span>
        <h2 className="mt-5 text-[30px] font-extrabold leading-tight tracking-tight text-neutral-950 sm:text-[34px]">
          Faculty Portal
        </h2>
        <p className="mt-2 max-w-[40ch] text-[13.5px] font-medium leading-relaxed text-neutral-500">
          Sign in with your staff account to create and manage exams.
        </p>
      </div>

      {/* ---------- card ---------- */}
      <div className="mt-7 md:mx-auto md:w-full md:max-w-[440px]">
        <section
          className={"animate-rise overflow-hidden rounded-[26px] bg-white shadow-[0_28px_60px_-24px_rgba(190,80,115,0.45)] " + (shake ? "animate-shake" : "")}
          style={{ animationDelay: "130ms" }}
        >
          <div className="h-[6px] w-full bg-gradient-to-r from-amber-400 via-rose-400 to-violet-400" />

          <form onSubmit={submit} className="px-6 pb-7 pt-7" noValidate>
            {/* identifier */}
            <label className="block">
              <span className="text-[12.5px] font-bold text-neutral-700">Staff username or email</span>
              <span className="relative block">
                <UserRound className="pointer-events-none absolute left-4 top-1/2 mt-1 h-4 w-4 -translate-y-1/2 text-neutral-400" strokeWidth={2.2} />
                <input
                  type="text"
                  autoComplete="username"
                  value={identifier}
                  onChange={(e) => setIdentifier(e.target.value)}
                  placeholder="e.g. faculty1"
                  className={fieldBase + " " + ring}
                />
              </span>
            </label>

            {/* password */}
            <label className="mt-4 block">
              <span className="text-[12.5px] font-bold text-neutral-700">Password</span>
              <span className="relative block">
                <Lock className="pointer-events-none absolute left-4 top-1/2 mt-1 h-4 w-4 -translate-y-1/2 text-neutral-400" strokeWidth={2.2} />
                <input
                  type={showPw ? "text" : "password"}
                  autoComplete="current-password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Password"
                  className={fieldBase + " pr-12 " + ring}
                />
                <button
                  type="button"
                  onClick={() => setShowPw((s) => !s)}
                  aria-label={showPw ? "Hide password" : "Show password"}
                  className="absolute right-3 top-1/2 mt-1 flex h-7 w-7 -translate-y-1/2 items-center justify-center rounded-full text-neutral-500 transition-colors hover:bg-neutral-200/60 hover:text-neutral-700"
                >
                  {showPw ? <EyeOff className="h-4 w-4" strokeWidth={2.1} /> : <Eye className="h-4 w-4" strokeWidth={2.1} />}
                </button>
              </span>
            </label>

            {error && (
              <p className="animate-rise mt-3.5 flex items-center gap-1.5 rounded-xl bg-rose-50 px-3.5 py-2.5 text-[12px] font-bold text-rose-500 ring-1 ring-rose-200">
                <AlertCircle className="h-3.5 w-3.5 shrink-0" strokeWidth={2.4} />
                {error}
              </p>
            )}

            <div className="mt-4 flex justify-end">
              <button
                type="button"
                onClick={() => onNotify("info", "Passwords are issued by the Controller of Exams office.")}
                className="flex items-center gap-1 text-[12px] font-extrabold text-fuchsia-600 transition-colors hover:text-fuchsia-500"
              >
                <HelpCircle className="h-3.5 w-3.5" strokeWidth={2.3} />
                Forgot password?
              </button>
            </div>

            {/* submit */}
            <button
              type="submit"
              disabled={checking}
              className="group relative mt-5 flex h-[54px] w-full items-center justify-center gap-2.5 overflow-hidden rounded-full bg-neutral-950 px-5 text-[14px] font-extrabold text-white shadow-[0_20px_40px_-16px_rgba(0,0,0,0.6)] transition-all duration-200 hover:shadow-[0_24px_46px_-16px_rgba(0,0,0,0.65)] active:scale-[0.98] disabled:cursor-default"
            >
              <span className="pointer-events-none absolute inset-y-0 -left-1/2 w-1/3 -skew-x-12 bg-white/10 opacity-0 transition-all duration-700 ease-out group-hover:left-[130%] group-hover:opacity-100" />
              {checking ? (
                <>
                  <Loader2 className="relative h-4 w-4 animate-spin" strokeWidth={2.5} />
                  <span className="relative">Checking…</span>
                </>
              ) : (
                <>
                  <span className="relative">Sign In</span>
                  <span className="relative flex h-7 w-7 items-center justify-center rounded-full bg-white/15 transition-all duration-200 group-hover:translate-x-0.5 group-hover:bg-white/25">
                    <ArrowRight className="h-4 w-4" strokeWidth={2.5} />
                  </span>
                </>
              )}
            </button>
          </form>
        </section>

        {/* ---------- switch to student ---------- */}
        <div
          className="animate-rise mt-4 flex items-center justify-between gap-4 rounded-[22px] bg-[#f3ede7] px-5 py-4"
          style={{ animationDelay: "190ms" }}
        >
          <p className="text-[12.5px] font-semibold leading-snug text-neutral-600">
            Looking for your student examination?
          </p>
          <button
            type="button"
            onClick={onSwitchToStudent}
            className="flex shrink-0 items-center gap-1.5 text-right text-[12px] font-extrabold leading-tight text-fuchsia-600 transition-colors hover:text-fuchsia-500"
          >
            <span>
              Switch to
              <br />
              Student Portal
            </span>
            <ExternalLink className="h-3.5 w-3.5 shrink-0" strokeWidth={2.4} />
          </button>
        </div>
      </div>
    </div>
  );
}
