import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  AlertTriangle,
  Check,
  CheckCircle2,
  Clock,
  DoorOpen,
  Eye,
  Flag,
  Hourglass,
  Loader2,
  LogOut,
  RefreshCw,
  RotateCcw,
  ScanLine,
  Search,
  Send,
  UserCheck,
  Users,
  Volume2,
  VolumeX,
  X,
} from "lucide-react";
import {
  approveCheckin,
  DEFAULT_INV_PROCTOR_RULES,
  fetchAway,
  fetchMyExams,
  fetchRoster,
  fetchStudentEvents,
  finalizeExpired,
  getProctorRulesCached,
  revokeCheckin,
  signOutInvigilator,
  type AwayRow,
  type InvigilatorExam,
  type InvigProctorRules,
  type RosterRow,
  type StudentEventRow,
} from "../lib/invigilatorApi";

type Notify = (kind: "success" | "info" | "error", msg: string) => void;

interface InvigilatorPanelProps {
  invigilatorName: string;
  onSignOut: () => void;
  onNotify: Notify;
}

type Filter = "waiting" | "approved" | "none" | "flagged" | "ejected" | "all";
type RowBusy = "approving" | "resetting" | undefined;
type Confirm =
  | { kind: "reset"; row: RosterRow }
  | { kind: "finalize" }
  | { kind: "repeat"; row: RosterRow }
  | null;

const EVENT_LABELS: Record<string, string> = {
  tab_hidden: "Tab hidden",
  window_shrunk: "Left exam window",
  back: "Back button",
  offline: "Offline",
  copy: "Copy",
  paste: "Paste",
};

const isFlaggedRow = (r: RosterRow) =>
  (r.strikes_total ?? 0) >= 1 || Boolean(r.ejected) || (r.ejections ?? 0) >= 1;

const fmtDur = (ms: number) =>
  ms >= 60_000 ? `${Math.round(ms / 60_000)}m` : `${Math.max(1, Math.round(ms / 1000))}s`;

const hhmm = (iso: string | null) =>
  iso ? new Date(iso).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" }) : "—";

const hhmmss = (d: Date) => d.toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit", second: "2-digit" });

const initialsOf = (name: string) =>
  name.split(/\s+/).filter(Boolean).slice(0, 2).map((p) => p[0]?.toUpperCase()).join("") || "?";

const AVATAR_TINTS = ["bg-pink-200 text-pink-700", "bg-violet-200 text-violet-700", "bg-amber-200 text-amber-700", "bg-emerald-200 text-emerald-700"];
const tintFor = (id: string) =>
  AVATAR_TINTS[[...id].reduce((s, c) => s + c.charCodeAt(0), 0) % AVATAR_TINTS.length];

export default function InvigilatorPanel({ invigilatorName, onSignOut, onNotify }: InvigilatorPanelProps) {
  const [exams, setExams] = useState<InvigilatorExam[]>([]);
  const [examsError, setExamsError] = useState(false);
  const [examId, setExamId] = useState<string>("");

  const [roster, setRoster] = useState<RosterRow[]>([]);
  const [rosterLoading, setRosterLoading] = useState(false);
  const [rosterError, setRosterError] = useState(false);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);

  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<Filter>("waiting");
  /** The code that was on screen when the phone checkbox was ticked. */
  const [phoneChecked, setPhoneChecked] = useState<Record<string, number>>({});
  const [busy, setBusy] = useState<Record<string, RowBusy>>({});
  const [confirm, setConfirm] = useState<Confirm>(null);
  const [finalizing, setFinalizing] = useState(false);
  const [rules, setRules] = useState<InvigProctorRules>(DEFAULT_INV_PROCTOR_RULES);

  /* ---------- live "away now" signals ---------- */
  const [awayRows, setAwayRows] = useState<AwayRow[]>([]);
  const awayOffset = useRef(0);
  const awayInFlight = useRef(false);
  const [, setAwayTick] = useState(0);
  const [soundOn, setSoundOn] = useState(false);
  const soundOnRef = useRef(false);
  soundOnRef.current = soundOn;
  const audioCtxRef = useRef<AudioContext | null>(null);
  const beepedRef = useRef<Set<string>>(new Set());
  const awayJitter = useRef(Math.random() * 1000 - 500); // ±0.5s, once per session

  const syncAway = useCallback(async () => {
    if (!examId || awayInFlight.current) return;
    awayInFlight.current = true;
    const forExam = examId;
    const { data, error } = await fetchAway(forExam);
    awayInFlight.current = false;
    if (forExam !== selectedRef.current) return; // exam switched mid-flight
    if (error) return; // silent: keep last known rows, retry next tick
    if (data.length > 0) {
      awayOffset.current = new Date(data[0].server_now).getTime() - Date.now();
    }
    setAwayRows(data);
  }, [examId]);

  // Separate fast poll — pauses while the tab is hidden.
  useEffect(() => {
    if (!examId) return;
    setAwayRows([]);
    beepedRef.current = new Set();
    let alive = true;
    let timer: number | undefined;

    void syncAway();
    const schedule = () => {
      timer = window.setTimeout(async () => {
        if (!alive) return;
        if (document.visibilityState === "visible") await syncAway();
        if (alive) schedule();
      }, 3000 + awayJitter.current);
    };
    schedule();

    const onVis = () => {
      if (document.visibilityState === "visible") void syncAway();
    };
    const onOnline = () => void syncAway();
    document.addEventListener("visibilitychange", onVis);
    window.addEventListener("online", onOnline);
    return () => {
      alive = false;
      window.clearTimeout(timer);
      document.removeEventListener("visibilitychange", onVis);
      window.removeEventListener("online", onOnline);
    };
  }, [examId, syncAway]);

  // One-second heartbeat drives the live counters — no extra requests.
  useEffect(() => {
    const t = window.setInterval(() => setAwayTick((x) => x + 1), 1000);
    return () => window.clearInterval(t);
  }, []);

  const awaySecondsOf = (r: AwayRow) =>
    Math.max(0, Math.floor((Date.now() + awayOffset.current - new Date(r.away_since).getTime()) / 1000));

  const alerting = awayRows
    .filter((r) => awaySecondsOf(r) >= rules.strike_ms / 1000)
    .sort((a, b) => awaySecondsOf(b) - awaySecondsOf(a));

  const alertingById = new Map(alerting.map((r) => [r.student_id, r]));

  // One beep per absence (student_id + away_since), only while sound is on.
  useEffect(() => {
    if (!soundOn) return;
    const fresh = alerting.filter((r) => !beepedRef.current.has(r.student_id + "|" + r.away_since));
    if (fresh.length === 0) return;
    fresh.forEach((r) => beepedRef.current.add(r.student_id + "|" + r.away_since));
    try {
      const ctx = audioCtxRef.current;
      if (ctx) {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "sine";
        osc.frequency.value = 880;
        gain.gain.setValueAtTime(0.001, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.25, ctx.currentTime + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.2);
        osc.connect(gain).connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.22);
      }
      if (typeof navigator.vibrate === "function") navigator.vibrate(200);
    } catch {
      /* audio unavailable — the visual alert still shows */
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [alerting.length, soundOn, awayRows]);

  // Keep the beep ledger small: drop keys no longer away.
  useEffect(() => {
    const live = new Set(awayRows.map((r) => r.student_id + "|" + r.away_since));
    beepedRef.current.forEach((k) => {
      if (!live.has(k)) beepedRef.current.delete(k);
    });
  }, [awayRows]);

  const toggleSound = () => {
    setSoundOn((s) => {
      const next = !s;
      if (next && !audioCtxRef.current) {
        try {
          const Ctor = window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
          if (Ctor) audioCtxRef.current = new Ctor(); // created on the user tap
        } catch {
          /* no audio — visual alerts only */
        }
      }
      void audioCtxRef.current?.resume();
      return next;
    });
  };

  useEffect(() => {
    return () => {
      void audioCtxRef.current?.close().catch(() => {});
      audioCtxRef.current = null;
    };
  }, []);

  /* ---------- per-student event sheet ---------- */
  const [sheetRow, setSheetRow] = useState<RosterRow | null>(null);
  const [events, setEvents] = useState<StudentEventRow[]>([]);
  const [eventsLoading, setEventsLoading] = useState(false);
  const [eventsError, setEventsError] = useState(false);
  const sheetRef = useRef<RosterRow | null>(null);
  sheetRef.current = sheetRow;
  const eventsInFlight = useRef(false);
  const eventsReloadRef = useRef<() => void>(() => {});

  const rosterInFlight = useRef(false);
  const selectedRef = useRef(examId);
  selectedRef.current = examId;

  /* ---------- exams ---------- */
  const loadExams = useCallback(async () => {
    setExamsError(false);
    const { data, error } = await fetchMyExams();
    if (error || data.length === 0) {
      setExamsError(Boolean(error));
      setExams(data);
      return;
    }
    setExams(data);
    // Default to the exam whose start is closest to now.
    const now = Date.now();
    const nearest = [...data].sort(
      (a, b) => Math.abs(new Date(a.starts_at).getTime() - now) - Math.abs(new Date(b.starts_at).getTime() - now),
    )[0];
    setExamId((cur) => cur || nearest.id);
  }, []);

  useEffect(() => {
    void loadExams();
    let alive = true;
    void getProctorRulesCached().then((r) => {
      if (alive && r) setRules(r);
    });
    return () => {
      alive = false;
    };
  }, [loadExams]);

  /* ---------- roster sync (single in-flight, hidden-tab aware) ---------- */
  const sync = useCallback(
    async (showSpinner: boolean) => {
      if (!examId || rosterInFlight.current) return;
      const forExam = examId;
      rosterInFlight.current = true;
      if (showSpinner) setRosterLoading(true);
      setRosterError(false);
      const { data, error } = await fetchRoster(forExam);
      rosterInFlight.current = false;
      // The picker moved while this was in flight — drop the stale response.
      if (forExam !== selectedRef.current) return;
      if (showSpinner) setRosterLoading(false);
      if (error) {
        setRosterError(true);
        return;
      }
      setRoster(data);
      setLastUpdated(new Date());
      eventsReloadRef.current(); // refresh the open sheet once per roster sync
    },
    [examId],
  );

  const loadEvents = useCallback(
    async (row: RosterRow, showSpinner: boolean) => {
      if (eventsInFlight.current) return; // one request in flight
      eventsInFlight.current = true;
      if (showSpinner) setEventsLoading(true);
      setEventsError(false);
      const { data, error } = await fetchStudentEvents(examId, row.student_id);
      eventsInFlight.current = false;
      if (showSpinner) setEventsLoading(false);
      if (error) {
        setEventsError(true);
        return;
      }
      setEvents(data);
    },
    [examId],
  );

  eventsReloadRef.current = () => {
    if (sheetRef.current) void loadEvents(sheetRef.current, false);
  };

  const openEvents = (row: RosterRow) => {
    setSheetRow(row);
    setEvents([]);
    void loadEvents(row, true);
  };

  // 12s ± 3s polling; paused while hidden; re-sync on focus and reconnect.
  useEffect(() => {
    if (!examId) return;
    rosterInFlight.current = false; // a switched exam must fetch immediately
    let alive = true;
    let timer: number | undefined;

    void sync(true);

    const schedule = () => {
      const jitter = Math.random() * 6000 - 3000;
      timer = window.setTimeout(async () => {
        if (!alive) return;
        if (document.visibilityState === "visible") await sync(false);
        if (alive) schedule();
      }, 12_000 + jitter);
    };
    schedule();

    const onVisibility = () => {
      if (document.visibilityState === "visible") void sync(false);
    };
    const onOnline = () => void sync(false);
    document.addEventListener("visibilitychange", onVisibility);
    window.addEventListener("online", onOnline);

    return () => {
      alive = false;
      window.clearTimeout(timer);
      document.removeEventListener("visibilitychange", onVisibility);
      window.removeEventListener("online", onOnline);
    };
  }, [examId, sync]);

  /* ---------- derived counts (roster only) ---------- */
  const counts = useMemo(() => {
    const c = { total: roster.length, none: 0, waiting: 0, approved: 0, inExam: 0, submitted: 0, flagged: 0, ejected: 0 };
    for (const r of roster) {
      if (r.checkin_status === "waiting") c.waiting += 1;
      else if (r.checkin_status === "approved") c.approved += 1;
      else if (!r.ejected) c.none += 1;
      if (r.attempt_status === "in_progress") c.inExam += 1;
      if (r.attempt_status === "submitted") c.submitted += 1;
      if (isFlaggedRow(r)) c.flagged += 1;
      if (r.ejected) c.ejected += 1;
    }
    return c;
  }, [roster]);

  const shown = useMemo(() => {
    const q = query.trim().toLowerCase();
    const list = roster.filter((r) => {
      const matches = !q || r.full_name.toLowerCase().includes(q) || (r.roll_no ?? "").toLowerCase().includes(q);
      const f =
        filter === "all" ||
        (filter === "waiting" && r.checkin_status === "waiting") ||
        (filter === "approved" && r.checkin_status === "approved") ||
        (filter === "none" && r.checkin_status == null && !r.ejected) ||
        (filter === "flagged" && isFlaggedRow(r)) ||
        (filter === "ejected" && Boolean(r.ejected));
      return matches && f;
    });
    if (filter === "flagged") list.sort((a, b) => (b.strikes_total ?? 0) - (a.strikes_total ?? 0));
    if (filter === "ejected") list.sort((a, b) => (b.ejections ?? 0) - (a.ejections ?? 0));
    if (filter === "all") list.sort((a, b) => Number(Boolean(b.ejected)) - Number(Boolean(a.ejected)));
    return list;
  }, [roster, query, filter]);

  /* ---------- actions (optimistic + rollback) ---------- */
  const approve = async (row: RosterRow) => {
    // Only the code that was on screen at tick time may be submitted.
    const tickedCode = phoneChecked[row.student_id];
    if (!examId || row.code == null || tickedCode !== row.code || busy[row.student_id]) return;
    setBusy((m) => ({ ...m, [row.student_id]: "approving" }));
    const prev = roster;
    setRoster((r) =>
      r.map((x) =>
        x.student_id === row.student_id
          ? { ...x, checkin_status: "approved", approved_at: new Date().toISOString(), phone_checked: true }
          : x,
      ),
    );
    const { error } = await approveCheckin(examId, row.student_id, tickedCode, true);
    setBusy((m) => ({ ...m, [row.student_id]: undefined }));
    if (error) {
      setRoster(prev);
      onNotify("error", error.message);
      if (/changed|missing/i.test(error.message)) void sync(false);
      return;
    }
    setPhoneChecked((m) => {
      const n = { ...m };
      delete n[row.student_id];
      return n;
    });
    onNotify("success", `${row.full_name} checked in`);
    void sync(false);
  };

  const reset = async (row: RosterRow) => {
    if (!examId || busy[row.student_id]) return;
    setConfirm(null);
    setBusy((m) => ({ ...m, [row.student_id]: "resetting" }));
    const prev = roster;
    setRoster((r) =>
      r.map((x) =>
        x.student_id === row.student_id
          ? { ...x, checkin_status: null, code: null, approved_at: null, phone_checked: null }
          : x,
      ),
    );
    const { error } = await revokeCheckin(examId, row.student_id);
    setBusy((m) => ({ ...m, [row.student_id]: undefined }));
    if (error) {
      setRoster(prev);
      onNotify("error", error.message);
      return;
    }
    onNotify("info", `${row.full_name} reset — they must request check-in again`);
    void sync(false);
  };

  const finalize = async () => {
    if (!examId || finalizing) return;
    setConfirm(null);
    setFinalizing(true);
    const { data, error } = await finalizeExpired(examId);
    setFinalizing(false);
    if (error) {
      onNotify("error", error.message);
      return;
    }
    onNotify("success", `Finalized ${data} attempt${data === 1 ? "" : "s"}`);
    void sync(false);
  };

  const signOut = async () => {
    await signOutInvigilator();
    onSignOut();
  };

  const filters: { key: Filter; label: string; count: number }[] = [
    { key: "waiting", label: "Waiting", count: counts.waiting },
    { key: "approved", label: "Approved", count: counts.approved },
    { key: "flagged", label: "Flagged", count: counts.flagged },
    { key: "ejected", label: "Ejected", count: counts.ejected },
    { key: "none", label: "Not checked in", count: counts.none },
    { key: "all", label: "All", count: counts.total },
  ];

  const chips = [
    { label: "Total", value: counts.total, tone: "bg-white text-neutral-800" },
    { label: "Not checked in", value: counts.none, tone: "bg-white text-neutral-500" },
    { label: "Waiting", value: counts.waiting, tone: "bg-amber-100 text-amber-700" },
    { label: "Approved", value: counts.approved, tone: "bg-emerald-100 text-emerald-700" },
    { label: "In exam", value: counts.inExam, tone: "bg-pink-100 text-pink-700" },
    { label: "Submitted", value: counts.submitted, tone: "bg-violet-100 text-violet-700" },
    {
      label: "Flagged",
      value: counts.flagged,
      tone: counts.flagged >= 3 ? "bg-rose-100 text-rose-600" : counts.flagged >= 1 ? "bg-amber-100 text-amber-700" : "bg-white text-neutral-500",
    },
    {
      label: "Ejected",
      value: counts.ejected,
      tone: counts.ejected >= 1 ? "bg-rose-500 text-white" : "bg-white text-neutral-500",
    },
  ];

  return (
    <div className="relative min-h-dvh">
      {/* ================= sticky header ================= */}
      <header className="sticky top-0 z-30 border-b border-rose-100/60 bg-[#fdf0ea]/90 px-4 pb-3 pt-4 backdrop-blur-md sm:px-6">
        <div className="mx-auto w-full max-w-[560px]">
          <div className="flex items-center justify-between gap-3">
            <div className="min-w-0">
              <p className="text-[9.5px] font-extrabold tracking-[0.16em] text-fuchsia-600">INVIGILATOR DESK</p>
              <h1 className="truncate text-[17px] font-extrabold tracking-tight text-neutral-900">{invigilatorName}</h1>
            </div>
            <button
              type="button"
              onClick={toggleSound}
              aria-pressed={soundOn}
              aria-label="Sound alerts"
              className={
                "flex h-11 shrink-0 items-center gap-1.5 rounded-full px-3.5 text-[11px] font-extrabold transition-all hover:-translate-y-0.5 active:scale-95 " +
                (soundOn
                  ? "bg-neutral-900 text-white shadow-[0_10px_22px_-10px_rgba(0,0,0,0.5)]"
                  : "bg-white text-neutral-500 shadow-[0_8px_20px_-10px_rgba(190,80,115,0.4)] hover:text-neutral-700")
              }
            >
              {soundOn ? <Volume2 className="h-4 w-4" strokeWidth={2.4} /> : <VolumeX className="h-4 w-4" strokeWidth={2.4} />}
              <span className="hidden sm:inline">Sound alerts</span>
            </button>
            <button
              type="button"
              onClick={() => void signOut()}
              className="flex h-11 shrink-0 items-center gap-1.5 rounded-full bg-white px-4 text-[12px] font-extrabold text-rose-500 shadow-[0_8px_20px_-10px_rgba(190,80,115,0.4)] transition-all hover:-translate-y-0.5 hover:bg-rose-50 active:scale-95"
            >
              <LogOut className="h-4 w-4 -scale-x-100" strokeWidth={2.4} />
              Sign out
            </button>
          </div>

          {/* exam picker + refresh */}
          <div className="mt-3 flex items-center gap-2">
            <select
              value={examId}
              onChange={(e) => {
                setExamId(e.target.value);
                setRoster([]);
                setLastUpdated(null);
              }}
              aria-label="Select exam"
              className="h-11 min-w-0 flex-1 appearance-none rounded-full border border-transparent bg-white px-4 text-[12.5px] font-extrabold text-neutral-800 shadow-[0_8px_20px_-10px_rgba(190,80,115,0.35)] outline-none transition-all focus:border-fuchsia-300 focus:ring-4 focus:ring-fuchsia-100"
            >
              {exams.length === 0 && <option value="">No exams assigned</option>}
              {exams.map((e) => (
                <option key={e.id} value={e.id}>
                  {e.course_code} · {e.title}
                </option>
              ))}
            </select>
            <button
              type="button"
              aria-label="Refresh roster"
              onClick={() => void sync(true)}
              className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-white text-neutral-600 shadow-[0_8px_20px_-10px_rgba(190,80,115,0.35)] transition-all hover:rotate-90 hover:text-fuchsia-700 active:scale-90"
            >
              <RefreshCw className={"h-[18px] w-[18px] " + (rosterLoading ? "animate-spin" : "")} strokeWidth={2.3} />
            </button>
          </div>

          {/* search */}
          <label className="relative mt-2.5 block">
            <Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-neutral-400" strokeWidth={2.2} />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search roll number or name…"
              className="h-11 w-full rounded-full bg-white pl-11 pr-4 text-[12.5px] font-bold text-neutral-800 shadow-[0_8px_20px_-10px_rgba(190,80,115,0.35)] outline-none transition-all placeholder:font-medium placeholder:text-neutral-400 focus:ring-4 focus:ring-fuchsia-100"
            />
          </label>

          <p className="mt-2 flex items-center gap-1.5 text-[10px] font-bold text-neutral-500">
            <Clock className="h-3 w-3" strokeWidth={2.4} />
            Last updated {lastUpdated ? hhmmss(lastUpdated) : "—"}
          </p>
        </div>
      </header>

      {/* ================= body ================= */}
      <main className="relative z-10 mx-auto w-full max-w-[560px] px-4 pb-32 pt-4 sm:px-6">
        {counts.ejected > 0 && (
          <button
            type="button"
            onClick={() => setFilter("ejected")}
            className="animate-rise mb-4 flex min-h-12 w-full items-center justify-center gap-2 rounded-2xl bg-rose-500 px-4 text-[12.5px] font-extrabold text-white shadow-[0_14px_30px_-12px_rgba(244,63,94,0.6)] transition-all hover:-translate-y-0.5 hover:bg-rose-400 active:scale-[0.99]"
          >
            <AlertTriangle className="h-4 w-4" strokeWidth={2.4} />
            {counts.ejected} student{counts.ejected === 1 ? "" : "s"} locked out
          </button>
        )}

        {alerting.length > 0 && (
          <section className="animate-rise mb-4 overflow-hidden rounded-2xl bg-rose-50 ring-1 ring-rose-300">
            <p className="flex items-center gap-2 border-b border-rose-200 px-4 py-3 text-[12.5px] font-extrabold text-rose-600">
              <span className="relative flex h-2.5 w-2.5">
                <span className="absolute h-full w-full animate-ping rounded-full bg-rose-400 [animation-duration:1.6s]" />
                <span className="relative h-2.5 w-2.5 rounded-full bg-rose-500" />
              </span>
              {alerting.length} student{alerting.length === 1 ? "" : "s"} away
            </p>
            <div className="flex flex-col">
              {alerting.map((r) => {
                const s = awaySecondsOf(r);
                const stale = s >= 120;
                return (
                  <div key={r.student_id + r.away_since} className="flex items-center gap-3 border-b border-rose-100 px-4 py-2.5 last:border-0">
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[12.5px] font-extrabold text-neutral-900">{r.full_name ?? "Student"}</p>
                      <p className="truncate text-[10.5px] font-bold text-neutral-500">{r.roll_no ?? "—"}</p>
                    </div>
                    <span className="shrink-0 rounded-full bg-white px-2.5 py-1 text-[9.5px] font-extrabold text-neutral-600 ring-1 ring-rose-200">
                      {r.away_kind === "window_shrunk" ? "Window" : "Tab or app"}
                    </span>
                    <span className="shrink-0 font-mono text-[12px] font-extrabold text-rose-600">
                      {stale ? `Away since ${hhmm(r.away_since)}, not heard back` : `Away ${s}s`}
                    </span>
                  </div>
                );
              })}
            </div>
            <p className="px-4 py-2.5 text-[10.5px] font-bold text-rose-700/70">
              Could be a call or a notification. Check before acting.
            </p>
          </section>
        )}

        {examsError && (
          <div className="animate-rise mb-4 flex items-center justify-between gap-3 rounded-2xl bg-rose-50 p-4 ring-1 ring-rose-200">
            <p className="text-[12px] font-extrabold text-rose-600">Could not load your exams.</p>
            <button
              type="button"
              onClick={() => void loadExams()}
              className="flex h-10 items-center gap-1.5 rounded-full bg-neutral-950 px-4 text-[11.5px] font-extrabold text-white active:scale-95"
            >
              <RefreshCw className="h-3.5 w-3.5" strokeWidth={2.4} /> Retry
            </button>
          </div>
        )}

        {/* count chips */}
        <div className="flex flex-wrap gap-2">
          {chips.map((c) => (
            <span key={c.label} className={"flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[10.5px] font-extrabold shadow-[0_6px_16px_-8px_rgba(190,80,115,0.3)] " + c.tone}>
              {c.label}
              <span className="rounded-full bg-white/70 px-1.5 text-[10.5px]">{c.value}</span>
            </span>
          ))}
        </div>

        {/* filter tabs */}
        <div className="mt-4 flex flex-wrap gap-2">
          {filters.map((f) => {
            const active = filter === f.key;
            return (
              <button
                key={f.key}
                type="button"
                onClick={() => setFilter(f.key)}
                className={
                  "flex h-11 items-center gap-2 rounded-full px-4 text-[11.5px] font-extrabold transition-all duration-200 active:scale-95 " +
                  (active
                    ? "bg-neutral-900 text-white shadow-[0_10px_22px_-10px_rgba(0,0,0,0.6)]"
                    : "bg-white/80 text-neutral-600 shadow-[0_6px_16px_-8px_rgba(190,80,115,0.3)] hover:bg-white")
                }
              >
                {f.label}
                <span className={"rounded-full px-1.5 text-[10.5px] " + (active ? "bg-white/20" : "bg-neutral-200/80")}>{f.count}</span>
              </button>
            );
          })}
        </div>

        {/* roster */}
        <div className="mt-4 flex flex-col gap-3.5">
          {!examId && !rosterLoading && (
            <div className="animate-rise flex flex-col items-center gap-2 rounded-[22px] bg-white/70 p-8 text-center">
              <Users className="h-7 w-7 text-neutral-300" strokeWidth={2} />
              <p className="text-[13px] font-extrabold text-neutral-600">No exams assigned</p>
              <p className="text-[11.5px] font-medium text-neutral-500">
                Exams assigned to you by the Controller of Exams will appear here.
              </p>
            </div>
          )}

          {examId && rosterLoading &&
            [0, 1, 2].map((n) => (
              <div key={n} className="animate-pulse rounded-[22px] bg-white/70 p-5">
                <div className="flex items-center gap-3">
                  <span className="h-11 w-11 rounded-full bg-neutral-200" />
                  <div className="flex-1">
                    <span className="block h-4 w-2/3 rounded bg-neutral-200" />
                    <span className="mt-2 block h-3 w-1/3 rounded bg-neutral-100" />
                  </div>
                </div>
                <span className="mt-4 block h-11 w-full rounded-full bg-neutral-200" />
              </div>
            ))}

          {examId && !rosterLoading && rosterError && (
            <div className="animate-rise flex flex-col items-center gap-4 rounded-[22px] bg-white p-8 text-center shadow-[0_20px_44px_-22px_rgba(190,80,115,0.45)]">
              <span className="flex h-12 w-12 items-center justify-center rounded-full bg-rose-100">
                <AlertTriangle className="h-6 w-6 text-rose-500" strokeWidth={2.2} />
              </span>
              <p className="text-[13.5px] font-extrabold text-neutral-900">Could not load the roster. Try again.</p>
              <button
                type="button"
                onClick={() => void sync(true)}
                className="flex h-11 items-center gap-2 rounded-full bg-neutral-950 px-5 text-[12.5px] font-extrabold text-white transition-all hover:-translate-y-0.5 hover:bg-neutral-800 active:scale-[0.98]"
              >
                <RefreshCw className="h-4 w-4" strokeWidth={2.4} />
                Retry
              </button>
            </div>
          )}

          {examId && !rosterLoading && !rosterError && shown.length === 0 && (
            <div className="animate-rise flex flex-col items-center gap-2 rounded-[22px] bg-white/70 p-8 text-center">
              <Users className="h-7 w-7 text-neutral-300" strokeWidth={2} />
              <p className="text-[12.5px] font-bold text-neutral-500">
                {roster.length === 0 ? "No students are enrolled on this exam yet." : "Nobody matches this filter right now."}
              </p>
            </div>
          )}

          {examId &&
            !rosterLoading &&
            !rosterError &&
            shown.map((r) => {
              const rowBusy = busy[r.student_id];
              return (
                <article
                  key={r.student_id}
                  className="animate-rise rounded-[22px] bg-white p-4 shadow-[0_16px_36px_-20px_rgba(190,80,115,0.45)] transition-all duration-200"
                >
                  <div className="flex items-center gap-3">
                    <span className={"flex h-11 w-11 shrink-0 items-center justify-center rounded-full text-[12.5px] font-extrabold " + tintFor(r.student_id)}>
                      {initialsOf(r.full_name)}
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[14px] font-extrabold text-neutral-900">{r.full_name}</p>
                      <p className="mt-0.5 truncate text-[11px] font-bold text-neutral-500">
                        {r.roll_no} · {r.course_code}
                        {r.year ? ` · Year ${r.year}` : ""}
                      </p>
                    </div>
                    {rowBusy && <RefreshCw className="h-4 w-4 animate-spin text-neutral-400" strokeWidth={2.4} />}
                  </div>

                  {/* ---- WAITING ---- */}
                  {r.checkin_status === "waiting" && (
                    <div className="mt-3.5">
                      {(r.ejections ?? 0) >= 1 && (
                        <div className="mb-2.5 flex items-center gap-2">
                          <p className="min-w-0 flex-1 rounded-xl bg-amber-50 px-3 py-2 text-[10.5px] font-extrabold leading-snug text-amber-800 ring-1 ring-amber-300">
                            Previously removed {r.ejections} time{(r.ejections ?? 0) === 1 ? "" : "s"}. Approving resets
                            their warnings to 0.
                          </p>
                          {(r.ejections ?? 0) >= 2 && (
                            <span className="shrink-0 rounded-full bg-rose-500 px-2.5 py-1 text-[9.5px] font-extrabold text-white">
                              Repeat ejection
                            </span>
                          )}
                        </div>
                      )}
                      <div className="rounded-2xl bg-[#f3ede7] p-4 text-center">
                        <p className="font-mono text-[44px] font-extrabold leading-none tracking-[0.16em] text-neutral-950">
                          {r.code != null ? String(r.code).padStart(4, "0") : "····"}
                        </p>
                        <p className="mt-1.5 text-[10.5px] font-extrabold tracking-wide text-neutral-500">
                          MATCH THIS CODE WITH THE STUDENT'S PHONE
                        </p>
                      </div>

                      {r.attempt_status === "in_progress" && (
                        <p className="mt-2.5 flex items-center gap-1.5 rounded-xl bg-pink-50 px-3 py-2 text-[11px] font-extrabold text-pink-700 ring-1 ring-pink-200">
                          <Hourglass className="h-3.5 w-3.5" strokeWidth={2.4} />
                          Attempt in progress — approving will resume it
                        </p>
                      )}

                      {phoneChecked[r.student_id] != null && phoneChecked[r.student_id] !== r.code && (
                        <p className="animate-rise mt-2.5 flex items-center gap-1.5 rounded-xl bg-amber-50 px-3 py-2 text-[11px] font-extrabold text-amber-700 ring-1 ring-amber-300">
                          <AlertTriangle className="h-3.5 w-3.5 shrink-0" strokeWidth={2.4} />
                          Code changed — match it again
                        </p>
                      )}

                      <button
                        type="button"
                        onClick={() =>
                          setPhoneChecked((m) => {
                            const n = { ...m };
                            if (n[r.student_id] === r.code) delete n[r.student_id];
                            else if (r.code != null) n[r.student_id] = r.code;
                            return n;
                          })
                        }
                        aria-pressed={phoneChecked[r.student_id] === r.code}
                        disabled={r.code == null}
                        className={
                          "mt-3 flex min-h-12 w-full items-center gap-3 rounded-2xl border-2 px-4 py-2.5 text-left transition-all duration-200 active:scale-[0.99] " +
                          (phoneChecked[r.student_id] === r.code ? "border-emerald-300 bg-emerald-50" : "border-neutral-200 bg-white")
                        }
                      >
                        <span
                          className={
                            "flex h-6 w-6 shrink-0 items-center justify-center rounded-lg transition-all duration-200 " +
                            (phoneChecked[r.student_id] === r.code ? "bg-emerald-500" : "bg-white ring-2 ring-neutral-300")
                          }
                        >
                          {phoneChecked[r.student_id] === r.code && <Check className="h-3.5 w-3.5 text-white" strokeWidth={3.4} />}
                        </span>
                        <span className="text-[11.5px] font-bold leading-snug text-neutral-700">
                          Phone checked: Do Not Disturb on, alarms off, auto-lock Never, battery OK, assistants off
                        </span>
                      </button>

                      <button
                        type="button"
                        disabled={phoneChecked[r.student_id] !== r.code || Boolean(rowBusy)}
                        onClick={() =>
                          (r.ejections ?? 0) >= 1 ? setConfirm({ kind: "repeat", row: r }) : void approve(r)
                        }
                        className={
                          "mt-3 flex h-12 w-full items-center justify-center gap-2 rounded-full text-[13px] font-extrabold transition-all duration-200 " +
                          (phoneChecked[r.student_id] === r.code
                            ? "bg-emerald-600 text-white shadow-[0_14px_30px_-12px_rgba(16,185,129,0.6)] hover:-translate-y-0.5 hover:bg-emerald-500 active:scale-[0.98]"
                            : "cursor-not-allowed bg-neutral-200/80 text-neutral-400")
                        }
                      >
                        {rowBusy === "approving" ? (
                          <RefreshCw className="h-4 w-4 animate-spin" strokeWidth={2.4} />
                        ) : (
                          <UserCheck className="h-4 w-4" strokeWidth={2.4} />
                        )}
                        Approve check-in
                      </button>
                    </div>
                  )}

                  {/* ---- APPROVED ---- */}
                  {r.checkin_status === "approved" && (
                    <div className="mt-3.5">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="flex items-center gap-1.5 rounded-full bg-emerald-50 px-3 py-1.5 text-[10.5px] font-extrabold text-emerald-700 ring-1 ring-emerald-200">
                          <CheckCircle2 className="h-3.5 w-3.5" strokeWidth={2.4} />
                          Approved {hhmm(r.approved_at)}
                        </span>
                        {r.attempt_status === "in_progress" && (
                          <span className="flex items-center gap-1.5 rounded-full bg-pink-50 px-3 py-1.5 text-[10.5px] font-extrabold text-pink-700 ring-1 ring-pink-200">
                            <ScanLine className="h-3.5 w-3.5" strokeWidth={2.4} />
                            In exam · ends {hhmm(r.deadline_at)}
                          </span>
                        )}
                        {alertingById.has(r.student_id) && (() => {
                          const s = awaySecondsOf(alertingById.get(r.student_id)!);
                          return (
                            <span className="flex animate-pulse items-center gap-1.5 rounded-full bg-rose-500 px-3 py-1.5 font-mono text-[10.5px] font-extrabold text-white [animation-duration:2s]">
                              <AlertTriangle className="h-3.5 w-3.5" strokeWidth={2.6} />
                              Away {s}s
                            </span>
                          );
                        })()}
                        {r.attempt_status === "submitted" && (
                          <span className="flex items-center gap-1.5 rounded-full bg-violet-50 px-3 py-1.5 text-[10.5px] font-extrabold text-violet-700 ring-1 ring-violet-200">
                            <Send className="h-3.5 w-3.5" strokeWidth={2.4} />
                            Submitted {hhmm(r.submitted_at)}
                          </span>
                        )}
                        {r.attempt_status == null && (
                          <span className="rounded-full bg-neutral-100 px-3 py-1.5 text-[10.5px] font-extrabold text-neutral-500">
                            Not started
                          </span>
                        )}
                      </div>

                      {r.attempt_status === "in_progress" && (() => {
                        const strikes = r.strikes ?? 0;
                        const limit = rules.limit;
                        const tone =
                          strikes === 0
                            ? "bg-neutral-100 text-neutral-600"
                            : strikes < limit
                              ? "bg-amber-100 text-amber-700 ring-1 ring-amber-300"
                              : "bg-rose-100 text-rose-600 ring-1 ring-rose-300";
                        return (
                          <div className="mt-2.5">
                            <button
                              type="button"
                              onClick={() => openEvents(r)}
                              className={
                                "flex min-h-11 w-full items-center justify-center gap-2 rounded-full px-4 text-[11px] font-extrabold transition-all hover:-translate-y-0.5 active:scale-[0.98] " +
                                tone
                              }
                            >
                              {strikes === 0 ? (
                                <CheckCircle2 className="h-3.5 w-3.5" strokeWidth={2.4} />
                              ) : (
                                <Flag className="h-3.5 w-3.5" fill="currentColor" strokeWidth={0} />
                              )}
                              {strikes === 0 ? "No warnings" : `${strikes}/${limit}`}
                            </button>
                            {r.last_event && r.last_event_at && (
                              <p className="mt-1.5 text-center text-[10.5px] font-bold text-neutral-500">
                                Last: {EVENT_LABELS[r.last_event] ?? r.last_event}, {hhmm(r.last_event_at)}
                              </p>
                            )}
                          </div>
                        );
                      })()}

                      <button
                        type="button"
                        disabled={Boolean(rowBusy)}
                        onClick={() => setConfirm({ kind: "reset", row: r })}
                        className="mt-3 flex h-11 w-full items-center justify-center gap-2 rounded-full bg-white text-[12.5px] font-extrabold text-rose-500 ring-1 ring-rose-200 transition-all hover:bg-rose-50 active:scale-[0.98]"
                      >
                        <RotateCcw className="h-4 w-4" strokeWidth={2.4} />
                        Reset
                      </button>
                    </div>
                  )}

                  {/* ---- EJECTED: locked out right now ---- */}
                  {r.ejected && r.checkin_status == null && (
                    <div className="mt-3.5 rounded-2xl bg-rose-50 p-4 ring-1 ring-rose-300">
                      <p className="flex items-center gap-2 text-[14px] font-extrabold text-rose-600">
                        <AlertTriangle className="h-4 w-4" strokeWidth={2.4} />
                        Locked out
                      </p>
                      <p className="mt-1.5 text-[11.5px] font-bold leading-relaxed text-rose-700">
                        {r.eject_reason === "long_absence"
                          ? `Left the exam for ${Math.round(rules.lock_ms / 1000)} seconds or more`
                          : `Reached ${rules.limit} warnings`}
                      </p>
                      <div className="mt-3 flex items-center gap-2.5">
                        <span className="rounded-full bg-white px-3 py-1.5 text-[10.5px] font-extrabold text-rose-600 ring-1 ring-rose-200">
                          Removed {r.ejections ?? 1} time{(r.ejections ?? 1) === 1 ? "" : "s"}
                        </span>
                        <button
                          type="button"
                          onClick={() => openEvents(r)}
                          className="ml-auto flex min-h-11 items-center gap-1.5 rounded-full bg-white px-4 text-[11.5px] font-extrabold text-neutral-700 ring-1 ring-neutral-200 transition-all hover:-translate-y-0.5 hover:text-fuchsia-700 active:scale-[0.98]"
                        >
                          <Eye className="h-3.5 w-3.5" strokeWidth={2.4} />
                          View log
                        </button>
                      </div>
                    </div>
                  )}

                  {/* ---- NOT CHECKED IN: identity only ---- */}
                </article>
              );
            })}
        </div>
      </main>

      {/* ================= finalize bar ================= */}
      <footer className="fixed inset-x-0 bottom-0 z-20 border-t border-rose-100/60 bg-[#fdf0ea]/90 px-4 py-3 backdrop-blur-md sm:px-6">
        <div className="mx-auto w-full max-w-[560px]">
          <button
            type="button"
            disabled={finalizing || !examId}
            onClick={() => setConfirm({ kind: "finalize" })}
            className="flex h-12 w-full items-center justify-center gap-2 rounded-full bg-fuchsia-800 text-[13px] font-extrabold text-white shadow-[0_16px_32px_-14px_rgba(134,25,143,0.7)] transition-all hover:-translate-y-0.5 hover:bg-fuchsia-700 active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-50"
          >
            {finalizing ? <RefreshCw className="h-4 w-4 animate-spin" strokeWidth={2.4} /> : <DoorOpen className="h-4 w-4" strokeWidth={2.4} />}
            {finalizing ? "Finalizing…" : "Finalize expired attempts"}
          </button>
        </div>
      </footer>

      {/* ================= event timeline sheet ================= */}
      {sheetRow && (
        <div
          className="fixed inset-0 z-40 flex items-end justify-center bg-neutral-950/45 p-0 backdrop-blur-sm sm:items-center sm:p-5"
          onClick={() => setSheetRow(null)}
        >
          <div
            className="animate-pop flex max-h-[85vh] w-full max-w-[460px] flex-col overflow-hidden rounded-t-[28px] bg-white shadow-[0_-20px_60px_-20px_rgba(0,0,0,0.5)] sm:rounded-[28px]"
            onClick={(e) => e.stopPropagation()}
          >
            {/* sheet handle + header */}
            <div className="border-b border-neutral-100 px-5 pb-4 pt-3">
              <span className="mx-auto mb-3 block h-1.5 w-12 rounded-full bg-neutral-200 sm:hidden" />
              <div className="flex items-center gap-3">
                <span className={"flex h-11 w-11 shrink-0 items-center justify-center rounded-full text-[12.5px] font-extrabold " + tintFor(sheetRow.student_id)}>
                  {initialsOf(sheetRow.full_name)}
                </span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[15px] font-extrabold text-neutral-900">{sheetRow.full_name}</p>
                  <p className="truncate text-[11px] font-bold text-neutral-500">
                    {sheetRow.roll_no} · {sheetRow.strikes_total ?? 0} strike{(sheetRow.strikes_total ?? 0) === 1 ? "" : "s"} in total
                  </p>
                </div>
                <button
                  type="button"
                  aria-label="Close"
                  onClick={() => setSheetRow(null)}
                  className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-neutral-100 text-neutral-500 transition-colors hover:bg-neutral-200 hover:text-neutral-800 active:scale-90"
                >
                  <X className="h-4 w-4" strokeWidth={2.6} />
                </button>
              </div>
            </div>

            {/* timeline */}
            <div className="min-h-0 flex-1 overflow-y-auto px-5 py-4">
              {eventsLoading ? (
                <div className="flex flex-col items-center gap-3 py-10">
                  <Loader2 className="h-6 w-6 animate-spin text-neutral-400" strokeWidth={2.4} />
                  <p className="text-[12px] font-bold text-neutral-500">Loading events…</p>
                </div>
              ) : eventsError ? (
                <div className="flex flex-col items-center gap-4 py-8 text-center">
                  <AlertTriangle className="h-7 w-7 text-rose-500" strokeWidth={2.2} />
                  <p className="text-[13px] font-extrabold text-neutral-800">Could not load events.</p>
                  <button
                    type="button"
                    onClick={() => void loadEvents(sheetRow, true)}
                    className="flex h-11 items-center gap-2 rounded-full bg-neutral-950 px-5 text-[12px] font-extrabold text-white transition-all hover:-translate-y-0.5 hover:bg-neutral-800 active:scale-[0.98]"
                  >
                    <RefreshCw className="h-4 w-4" strokeWidth={2.4} />
                    Retry
                  </button>
                </div>
              ) : events.length === 0 ? (
                <div className="flex flex-col items-center gap-2 py-10 text-center">
                  <Clock className="h-7 w-7 text-neutral-300" strokeWidth={2} />
                  <p className="text-[12.5px] font-bold text-neutral-500">No events recorded</p>
                </div>
              ) : (
                <div className="flex flex-col gap-2">
                  {events.map((e, i) => (
                    <div
                      key={i}
                      className={
                        "flex items-center gap-3 rounded-2xl px-4 py-3 " +
                        (e.is_strike ? "bg-rose-50 ring-1 ring-rose-200" : "bg-[#f3ede7]")
                      }
                    >
                      <span className="w-[62px] shrink-0 font-mono text-[11px] font-extrabold text-neutral-500">
                        {new Date(e.occurred_at).toLocaleTimeString("en-GB", { hour12: false })}
                      </span>
                      <span className="min-w-0 flex-1 truncate text-[12.5px] font-extrabold text-neutral-800">
                        {EVENT_LABELS[e.kind] ?? e.kind}
                        {typeof e.duration_ms === "number" && e.duration_ms > 0 ? ` · ${fmtDur(e.duration_ms)}` : ""}
                      </span>
                      {e.is_strike && (
                        <span className="flex shrink-0 items-center gap-1 rounded-full bg-rose-500 px-2.5 py-1 text-[9px] font-extrabold tracking-wide text-white">
                          <Flag className="h-2.5 w-2.5" fill="currentColor" strokeWidth={0} />
                          STRIKE
                        </span>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* honest note */}
            <p className="border-t border-neutral-100 px-5 py-3.5 text-center text-[10.5px] font-bold leading-relaxed text-neutral-500">
              Strikes are signals, not proof. Check with the student before acting.
            </p>
          </div>
        </div>
      )}

      {/* ================= confirm dialog ================= */}
      {confirm && (
        <div className="fixed inset-0 z-40 flex items-end justify-center bg-neutral-950/45 p-5 backdrop-blur-sm sm:items-center" onClick={() => setConfirm(null)}>
          <div className="animate-pop w-full max-w-[400px] rounded-[24px] bg-white p-6 shadow-[0_30px_70px_-20px_rgba(0,0,0,0.5)]" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center gap-3">
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-rose-100">
                <AlertTriangle className="h-5 w-5 text-rose-600" strokeWidth={2.2} />
              </span>
              <h3 className="min-w-0 flex-1 truncate text-[16px] font-extrabold text-neutral-900">
                {confirm.kind === "reset"
                  ? `Reset ${confirm.row.full_name}?`
                  : confirm.kind === "repeat"
                    ? `Approve ${confirm.row.full_name}?`
                    : "Finalize expired attempts?"}
              </h3>
            </div>
            <p className="mt-3 text-[12.5px] font-medium leading-relaxed text-neutral-600">
              {confirm.kind === "reset"
                ? "They must request check-in again. Their answers are kept."
                : confirm.kind === "repeat"
                  ? `${confirm.row.full_name} was removed ${confirm.row.ejections ?? 1} time${(confirm.row.ejections ?? 1) === 1 ? "" : "s"}. Have you looked at the event log?`
                  : "Attempts still in progress long after the deadline will be graded on the server. This cannot be undone."}
            </p>
            {confirm.kind === "repeat" ? (
              <div className="mt-5 flex flex-col gap-2.5">
                <button
                  type="button"
                  onClick={() => {
                    const row = confirm.row;
                    setConfirm(null);
                    openEvents(row);
                  }}
                  className="flex min-h-12 items-center justify-center gap-2 rounded-2xl bg-white text-[13px] font-extrabold text-fuchsia-700 ring-1 ring-fuchsia-200 transition-all hover:bg-fuchsia-50 active:scale-[0.98]"
                >
                  <Eye className="h-4 w-4" strokeWidth={2.4} />
                  View log
                </button>
                <div className="flex gap-3">
                  <button
                    type="button"
                    onClick={() => setConfirm(null)}
                    className="flex-1 rounded-2xl bg-neutral-100 py-3 text-[13px] font-extrabold text-neutral-700 transition-colors hover:bg-neutral-200"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const row = confirm.row;
                      setConfirm(null);
                      void approve(row);
                    }}
                    className="flex-1 rounded-2xl bg-emerald-600 py-3 text-[13px] font-extrabold text-white transition-all hover:bg-emerald-500 active:scale-[0.98]"
                  >
                    Approve anyway
                  </button>
                </div>
              </div>
            ) : (
              <div className="mt-5 flex gap-3">
                <button
                  type="button"
                  onClick={() => setConfirm(null)}
                  className="flex-1 rounded-2xl bg-neutral-100 py-3 text-[13px] font-extrabold text-neutral-700 transition-colors hover:bg-neutral-200"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={() => (confirm.kind === "reset" ? void reset(confirm.row) : void finalize())}
                  className="flex-1 rounded-2xl bg-neutral-950 py-3 text-[13px] font-extrabold text-white transition-all hover:bg-neutral-800 active:scale-[0.98]"
                >
                  {confirm.kind === "reset" ? "Reset" : "Finalize"}
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
