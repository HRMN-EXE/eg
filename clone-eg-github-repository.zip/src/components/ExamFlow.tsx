import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  AlertTriangle,
  ArrowLeft,
  ArrowRight,
  Bookmark,
  Check,
  CheckCheck,
  ChevronDown,
  Cloud,
  Flag,
  GraduationCap,
  Hash,
  LayoutGrid,
  RefreshCw,
  ShieldAlert,
  Star,
  Timer,
  User as UserIcon,
  X,
} from "lucide-react";
import { passPctOf, type Exam, type ExamQuestion, type ExamResult } from "../data/exams";
import {
  fetchAttemptClock,
  getProctorRules,
  logProctorEvents,
  saveAnswers,
  sendAwayKeepalive,
  setAway as rpcSetAway,
  submitAttempt,
  type DbExamSession,
  type ProctorEventKind,
  type ProctorRules,
} from "../lib/examApi";
import { supabase } from "../lib/supabase";

interface ExamFlowProps {
  exam: Exam;
  /** When present, the runner is backed by a live server attempt. */
  session?: DbExamSession | null;
  /** Persist the result so the exam list marks it completed. */
  onSubmitted: (result: ExamResult) => void;
  /** Return to the dashboard without submitting. */
  onExit: () => void;
  /** This login's check-in was revoked mid-exam — return to the waiting room. */
  onSessionLost: () => void;
  onNotify?: (kind: "success" | "info" | "error", msg: string) => void;
}

type SaveStatus = "idle" | "saving" | "saved" | "error";

/** Submit retry backoff in ms (capped at the last entry). */
const RETRY_BACKOFF = [3000, 6000, 10000];

/** Batched sync cadence + backoff. Picks never hit the network directly —
 *  answers land in a local cache and sync on this schedule. */
const SYNC_INTERVAL_MS = 90_000;
const SYNC_JITTER_MS = 20_000;
const FINAL_WINDOW_MS = 20_000;
const SAVE_BACKOFF = [5000, 10000, 20000, 30000];
const AUTO_SUBMIT_JITTER_MS = 3000;

const cacheKeyFor = (attemptId: string) => `exam-answers:${attemptId}`;

/** Fallback thresholds until the server rules arrive; one constant only. */
const DEFAULT_PROCTOR_RULES: ProctorRules = { strike_ms: 3000, lock_ms: 12000, limit: 3 };

/* Away-from-exam detection tuning (touch devices only): one episode covers
   both a shrunk window and a lost-focus window (assistant overlays). */
const SHRINK_RATIO = 0.62;
const SHRINK_CONFIRM_MS = 1000;
const SHRINK_TICK_MS = 500;
const RESIZE_DEBOUNCE_MS = 300;
const FOCUS_CONFIRM_MS = 1000;
const FOCUS_TICK_MS = 500;
/* Back-reconcile cadence while a student is flagged away: ~2s ± 0.3s. */
const RECONCILE_MS = 2000;
const RECONCILE_JITTER_MS = 300;

/* Module-scope shrink test so the back-reconcile loop can reason about
   split-screen without depending on the touch-only episode effect. */
const isWindowShrunk = () => {
  const area = window.innerWidth * window.innerHeight;
  const screenArea = screen.width * screen.height;
  return screenArea > 0 && area / screenArea < SHRINK_RATIO;
};

const fmt = (s: number) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;

// ┌────────────────────────────── DEBUG-STRIP START ──────────────────────────────┐
// TEMPORARY diagnostic overlay. Remove this whole block plus the three sections
// tagged "DEBUG-STRIP AUX" elsewhere in this file. Renders ONLY when the URL has
// ?debug=1 AND the exam runs in DB mode. It is purely observational: no network,
// no storage, no behaviour change. Safe to delete in its entirety.
type DebugLastPing = { dir: "left" | "back"; ok: boolean; t: number } | null;

function debugStamp(d: Date): string {
  const p = (n: number) => String(n).padStart(2, "0");
  return `${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}.${Math.floor(d.getMilliseconds() / 100)}`;
}

function DebugStrip(props: {
  away: boolean;
  awayKind: "shrunk" | "focus";
  awaySentRef: { current: boolean };
  reconcileTimerRef: { current: number | undefined };
  lastPingRef: { current: DebugLastPing };
}) {
  const pRef = useRef(props);
  pRef.current = props; // always read the freshest values without re-subscribing
  const [snap, setSnap] = useState<string[]>([]);
  const [log, setLog] = useState<string[]>([]);
  const prevFocus = useRef<boolean>(document.hasFocus());

  const pushLog = useCallback((name: string) => {
    const line = `${debugStamp(new Date())} ${name} hasFocus=${document.hasFocus()}`;
    setLog((l) => [line, ...l].slice(0, 10)); // newest first, cap at 10
  }, []);

  useEffect(() => {
    const opts: AddEventListenerOptions = { capture: true, passive: true };
    const subs: Array<[EventTarget, string, EventListener]> = [];
    const listen = (target: EventTarget, name: string, label = name) => {
      const h: EventListener = () => pushLog(label);
      target.addEventListener(name, h, opts);
      subs.push([target, name, h]);
    };
    // Passive capture-phase listeners only — never interfere with the app.
    listen(window, "blur", "window.blur");
    listen(window, "focus", "window.focus");
    listen(window, "pageshow", "window.pageshow");
    listen(window, "pagehide", "window.pagehide");
    listen(window, "resume", "window.resume");
    listen(window, "resize", "window.resize");
    listen(document, "visibilitychange", "doc.visibilitychange");
    listen(document, "freeze", "doc.freeze");
    listen(document, "resume", "doc.resume");
    listen(document, "pointerdown", "doc.pointerdown");
    listen(document, "touchstart", "doc.touchstart");
    listen(document, "keydown", "doc.keydown");
    listen(document, "scroll", "doc.scroll");
    const vv = window.visualViewport;
    if (vv) {
      listen(vv, "resize", "vv.resize");
      listen(vv, "scroll", "vv.scroll");
    }

    const iv = window.setInterval(() => {
      // Poll focus separately so a silent focus change still shows up in the log.
      const hf = document.hasFocus();
      if (hf !== prevFocus.current) {
        prevFocus.current = hf;
        pushLog("hasFocus changed");
      }
      const p = pRef.current;
      const lp = p.lastPingRef.current;
      setSnap([
        `vis=${document.visibilityState}   hasFocus=${hf}`,
        `win=${window.innerWidth}x${window.innerHeight}   vv=${vv ? Math.round(vv.width) : 0}x${vv ? Math.round(vv.height) : 0}`,
        `shrunk=${isWindowShrunk()}   episode=${p.away ? p.awayKind : "none"}   awaySent=${p.awaySentRef.current}`,
        `reconcileRunning=${p.reconcileTimerRef.current != null ? "yes" : "no"}`,
        `lastPing=${lp ? `${lp.dir} ${lp.ok ? "ok" : "fail"} @${debugStamp(new Date(lp.t))}` : "none"}`,
      ]);
    }, 500);

    return () => {
      window.clearInterval(iv);
      for (const [t, n, h] of subs) t.removeEventListener(n, h, opts);
    };
  }, [pushLog]);

  return (
    <div
      style={{
        position: "fixed",
        left: 8,
        bottom: 8,
        zIndex: 99999,
        pointerEvents: "none",
        fontFamily: "ui-monospace, SFMono-Regular, Menlo, Consolas, monospace",
        fontSize: 10,
        lineHeight: "13px",
        color: "#a3e635",
        background: "rgba(10, 10, 12, 0.78)",
        border: "1px solid rgba(163, 230, 53, 0.35)",
        borderRadius: 6,
        padding: "6px 8px",
        maxWidth: 360,
        whiteSpace: "pre",
      }}
    >
      <div>{snap.length ? snap.join("\n") : "reading…"}</div>
      <div style={{ marginTop: 4, borderTop: "1px solid rgba(163, 230, 53, 0.25)", paddingTop: 3, color: "#d9f99d" }}>
        {log.length ? log.join("\n") : "(no events yet)"}
      </div>
    </div>
  );
}
// └────────────────────────────── DEBUG-STRIP END ────────────────────────────────┘

export default function ExamFlow({ exam, session, onSubmitted, onExit, onSessionLost }: ExamFlowProps) {
  const dbMode = Boolean(session);

  // DEBUG-STRIP AUX (delete with the block below): gate + last away-ping recorder.
  const debugOn = useMemo(() => {
    try {
      return new URLSearchParams(window.location.search).get("debug") === "1";
    } catch {
      return false;
    }
  }, []);
  const lastAwayPingRef = useRef<{ dir: "left" | "back"; ok: boolean; t: number } | null>(null);
  // DEBUG-STRIP AUX END

  // ----- local answer cache: merge server values with unsynced local picks -----
  const cacheKey = session ? cacheKeyFor(session.attemptId) : "";
  const boot = useMemo(() => {
    if (!session) return { answers: {} as Record<string, string>, dirty: {} as Record<string, string> };
    let cached: { answers?: Record<string, string>; dirty?: string[] } | null = null;
    try {
      cached = JSON.parse(localStorage.getItem(cacheKeyFor(session.attemptId)) ?? "null");
    } catch {
      cached = null;
    }
    const answers = { ...session.initialAnswers };
    const dirty: Record<string, string> = {};
    for (const qid of cached?.dirty ?? []) {
      const local = cached?.answers?.[qid];
      if (local !== undefined) {
        answers[qid] = local; // local pick wins for anything still unsynced
        dirty[qid] = local;
      }
    }
    return { answers, dirty };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const [phase, setPhase] = useState<"running" | "results" | "submitted">("running");
  const [idx, setIdx] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>(boot.answers);
  const answersRef = useRef(answers);
  answersRef.current = answers;
  const [flagged, setFlagged] = useState<Record<string, boolean>>({});
  const [seconds, setSeconds] = useState(exam.durationMin * 60);
  const [confirming, setConfirming] = useState(false);
  const [result, setResult] = useState<ExamResult | null>(null);
  const [dialReady, setDialReady] = useState(false);
  const [saveFlash, setSaveFlash] = useState(false);
  // Navigator starts open on larger screens, folded away on phones.
  const [navOpen, setNavOpen] = useState(() => window.innerWidth >= 640);

  // ----- autosave plumbing (server-backed attempts) -----
  const [saveStatus, setSaveStatus] = useState<SaveStatus>("idle");
  /** Questions whose local value has not yet been confirmed by the server. */
  const pendingRef = useRef<Record<string, string>>(boot.dirty);
  const flushTimer = useRef<number | undefined>(undefined);
  const finalSyncTimer = useRef<number | undefined>(undefined);
  const jitterRef = useRef(Math.random() * 2 * SYNC_JITTER_MS - SYNC_JITTER_MS);
  const attemptClosedRef = useRef(false);
  const retryTimer = useRef<number | undefined>(undefined);
  const retryCount = useRef(0);
  const mountedRef = useRef(true);
  const syncClockRef = useRef<() => void>(() => {});
  const flushInFlight = useRef(false);
  const dirtyRef = useRef(false);
  /** Per-question option id the server has confirmed saved. */
  const [confirmedSaves, setConfirmedSaves] = useState<Record<string, string>>({});

  // ----- server-side submit (DB mode) -----
  const [dbLocked, setDbLocked] = useState(false);
  const [submission, setSubmission] = useState<{ answered: number; total: number; submittedAt: string } | null>(null);
  const [dbSubmit, setDbSubmit] = useState<{ kind: "idle" } | { kind: "busy" } | { kind: "retrying" } | { kind: "error"; msg: string }>({ kind: "idle" });
  const submitInFlight = useRef(false);
  const autoSubmitStarted = useRef(false);
  const submitRetryCount = useRef(0);
  const submitRetryTimer = useRef<number | undefined>(undefined);
  const doDbSubmitRef = useRef<(auto: boolean) => void>(() => {});

  // ----- "this login lost its check-in" -----
  const [sessionLost, setSessionLost] = useState(false);
  const sessionLostRef = useRef(false);
  const sessionCheckQueued = useRef(false);

  /** Away-from-exam overlay is up (shrunk window or lost focus; touch + DB mode). */
  const [away, setAway] = useState(false);
  const [awayKind, setAwayKind] = useState<"shrunk" | "focus">("focus");

  const markSessionLost = useCallback(() => {
    if (sessionLostRef.current) return;
    sessionLostRef.current = true;
    setSessionLost(true);
    // Halt every background loop: save retries, submit retries, clock polling.
    window.clearTimeout(retryTimer.current);
    window.clearTimeout(submitRetryTimer.current);
    window.clearTimeout(flushTimer.current);
    // Writes would fail under RLS now — drop the queue so nothing keeps retrying
    // and the beforeunload prompt stays silent.
    pendingRef.current = {};
    if (mountedRef.current) setSaveStatus("idle");
  }, []);

  // ----- server-synced deadline & clock offset (DB mode) -----
  // Copied into local state so attempt_clock updates flow into the countdown.
  const [deadlineAt, setDeadlineAt] = useState(() => session?.deadlineAt ?? 0);
  const [clockOffset, setClockOffset] = useState(() => session?.clockOffset ?? 0);
  const deadlineRef = useRef(deadlineAt);
  const [deadlineNotice, setDeadlineNotice] = useState(false);
  const [endedByServer, setEndedByServer] = useState(false);
  const endedRef = useRef(false);
  const syncInFlight = useRef(false);

  // ----- questions: server-backed or static -----
  const qs = useMemo<ExamQuestion[]>(
    () =>
      session
        ? session.questions.map((qq) => ({
            id: qq.id,
            topic: "",
            prompt: qq.prompt,
            hint: "",
            options: qq.options,
            correctId: "",
          }))
        : exam.questions,
    [session, exam.questions],
  );

  // ----- server-anchored deadline (tab switches can't pause it) -----
  const [nowTick, setNowTick] = useState(() => Date.now());
  useEffect(() => {
    if (!session) return;
    const t = window.setInterval(() => setNowTick(Date.now()), 1000);
    return () => window.clearInterval(t);
  }, [session]);

  // Stable proctor identifiers for this attempt.
  const sessionId = useMemo(() => "SEC-" + Math.floor(1000 + Math.random() * 9000), []);
  const seed = useMemo(() => "#" + Math.floor(10000 + Math.random() * 90000), []);

  const total = qs.length;
  const q = qs[idx];
  const answeredCount = useMemo(() => qs.filter((qq) => answers[qq.id]).length, [answers, qs]);
  const flaggedCount = useMemo(() => qs.filter((qq) => flagged[qq.id]).length, [flagged, qs]);
  const remaining = total - answeredCount;
  const pct = Math.round((answeredCount / total) * 100);
  const pointsPerQ = Math.max(1, Math.round(exam.marks / Math.max(1, total)));
  // Server questions carry their own per-question marks.
  const pts = session ? session.questions[idx]?.marks ?? 1 : pointsPerQ;

  // Countdown always derives from the (server-synced) deadline timestamp.
  const remainingMs = session ? deadlineAt - (nowTick + clockOffset) : seconds * 1000;
  const timeUp = dbMode ? remainingMs <= 0 : seconds === 0;
  const submitting = dbSubmit.kind === "busy" || dbSubmit.kind === "retrying";
  const locked = dbMode && (timeUp || endedByServer || dbLocked || submitting || sessionLost || away);
  const low = remainingMs <= 60_000;
  // Ref so queueSave always sees the freshest countdown without re-subscribing.
  const remainingMsRef = useRef(remainingMs);
  remainingMsRef.current = remainingMs;

  /* ---------- static countdown: auto-submits when the clock runs out ---------- */
  useEffect(() => {
    if (phase !== "running" || dbMode) return;
    const t = window.setInterval(() => setSeconds((s) => Math.max(0, s - 1)), 1000);
    return () => window.clearInterval(t);
  }, [phase, dbMode]);

  /* ---------- batched sync: serialized, dirty-only, honest status ----------
     At most one request in flight; a sync requested mid-flight sets a re-run
     flag. Dirty entries clear only when the server-confirmed value still
     equals the local one. */
  const persistCache = useCallback(
    (nextAnswers: Record<string, string>) => {
      if (!session) return;
      try {
        localStorage.setItem(
          cacheKey,
          JSON.stringify({ answers: nextAnswers, dirty: Object.keys(pendingRef.current) }),
        );
      } catch {
        /* private mode / quota — the in-memory copy still carries the exam */
      }
    },
    [session, cacheKey],
  );

  const flush = useCallback(async () => {
    if (!session || sessionLostRef.current || attemptClosedRef.current) return;
    if (flushInFlight.current) {
      dirtyRef.current = true;
      return;
    }
    flushInFlight.current = true;
    window.clearTimeout(retryTimer.current);
    retryTimer.current = undefined; // a fresh attempt cancels any pending backoff
    try {
      for (;;) {
        const ids = Object.keys(pendingRef.current);
        if (ids.length === 0) {
          const recovered = retryCount.current > 0;
          retryCount.current = 0;
          sessionCheckQueued.current = false; // failure burst is over
          if (mountedRef.current) setSaveStatus("idle");
          if (recovered) syncClockRef.current(); // re-sync the clock after recovery
          break;
        }
        dirtyRef.current = false;
        const snapshot: Record<string, string> = {};
        ids.forEach((qid) => (snapshot[qid] = pendingRef.current[qid]));
        if (mountedRef.current) setSaveStatus("saving");
        const { error } = await saveAnswers(session.attemptId, snapshot);
        if (!mountedRef.current) break;

        if (error) {
          const msg = error.message ?? "";
          if (msg.includes("check-in is not valid")) {
            markSessionLost();
            break;
          }
          if (msg.includes("attempt is closed")) {
            // Window is over server-side — stop syncing; submit carries all.
            attemptClosedRef.current = true;
            if (mountedRef.current) setSaveStatus("idle");
            break;
          }
          // Back off 5s → 10s → 20s → 30s with ±20% jitter; manual Retry available.
          const base = SAVE_BACKOFF[Math.min(retryCount.current, SAVE_BACKOFF.length - 1)];
          const delay = base * (0.8 + Math.random() * 0.4);
          retryCount.current += 1;
          if (mountedRef.current) setSaveStatus("error");
          retryTimer.current = window.setTimeout(() => {
            retryTimer.current = undefined;
            void flush();
          }, delay);
          // A save failure may mean the check-in was revoked — probe the clock
          // once per burst (its own in-flight guard dedupes concurrent calls).
          if (!sessionCheckQueued.current) {
            sessionCheckQueued.current = true;
            syncClockRef.current();
          }
          break;
        }

        const confirmed: Record<string, string> = {};
        ids.forEach((qid) => {
          if (pendingRef.current[qid] === snapshot[qid]) {
            delete pendingRef.current[qid];
            confirmed[qid] = snapshot[qid];
          }
          // A newer local value arrived mid-flight: stays dirty, unconfirmed.
        });
        if (Object.keys(confirmed).length > 0) {
          setConfirmedSaves((c) => ({ ...c, ...confirmed }));
          persistCache(answersRef.current); // rewrite dirty list without confirmed
        }

        if (!dirtyRef.current && Object.keys(pendingRef.current).length === 0) break;
        // Re-run: fresher picks or a sync requested while this one ran.
      }
    } finally {
      flushInFlight.current = false;
      // Re-run only for a mid-flight request, never to bypass the backoff:
      // if a retry timer is pending the last attempt ended in an error.
      if (dirtyRef.current && retryTimer.current === undefined) void flush();
    }
  }, [session, cacheKey, markSessionLost, persistCache]);

  /** Schedule a sync only when there is something dirty to send. */
  const syncIfDirty = useCallback(() => {
    if (Object.keys(pendingRef.current).length > 0) void flush();
  }, [flush]);

  /** Resolves true once the pending queue drains, or false after timeoutMs. */
  const awaitSaves = useCallback(
    (timeoutMs: number) =>
      new Promise<boolean>((resolve) => {
        void flush();
        const start = Date.now();
        const check = () => {
          if (Object.keys(pendingRef.current).length === 0) return resolve(true);
          if (Date.now() - start > timeoutMs) return resolve(false);
          window.setTimeout(check, 150);
        };
        check();
      }),
    [flush],
  );

  /* ---------- server-side submit (DB mode) ---------- */
  const doDbSubmit = useCallback(
    async (auto: boolean) => {
      if (!session || submitInFlight.current || sessionLostRef.current) return; // double submit impossible
      submitInFlight.current = true;
      setDbSubmit({ kind: "busy" });
      // Best-effort proctor flush; never awaited, never blocks the submit.
      sendProctorRef.current();
      // The full local answer map rides along — submit never depends on syncs.
      const { data, error } = await submitAttempt(session.attemptId, answersRef.current);
      if (error || !data) {
        submitInFlight.current = false;
        const msg = error?.message ?? "";
        if (msg.includes("check-in is not valid")) {
          // The invigilator revoked this login — stop retrying entirely.
          markSessionLost();
          return;
        }
        if (auto) {
          const delay = RETRY_BACKOFF[Math.min(submitRetryCount.current, RETRY_BACKOFF.length - 1)];
          submitRetryCount.current += 1;
          setDbSubmit({ kind: "retrying" });
          submitRetryTimer.current = window.setTimeout(() => doDbSubmitRef.current(true), delay);
        } else {
          setDbSubmit({ kind: "error", msg: msg || "Submission failed. Please retry." });
        }
        return;
      }
      setSubmission({ answered: data.answered, total: data.total_questions, submittedAt: data.submitted_at });
      try {
        localStorage.removeItem(cacheKey); // server now owns the answers
      } catch {
        /* ignore */
      }
      setDbSubmit({ kind: "idle" });
      setPhase("submitted");
    },
    [session, cacheKey],
  );
  doDbSubmitRef.current = (auto) => void doDbSubmit(auto);

  /** Manual confirm: lock and submit — the RPC carries every local answer. */
  const confirmDbSubmit = useCallback(() => {
    setConfirming(false);
    setDbLocked(true);
    void doDbSubmit(false);
  }, [doDbSubmit]);

  // Warn on leave only when unsynced picks AND the last sync failed — the
  // local cache already protects the data, so unmount fires no request.
  // saveStatus is read through a ref so this effect mounts once: its cleanup
  // (which clears every timer) must run only on real unmount.
  const saveStatusRef = useRef(saveStatus);
  saveStatusRef.current = saveStatus;

  useEffect(() => {
    mountedRef.current = true;
    const onBeforeUnload = (e: BeforeUnloadEvent) => {
      if (Object.keys(pendingRef.current).length > 0 && saveStatusRef.current === "error") {
        e.preventDefault();
        e.returnValue = "";
      }
    };
    window.addEventListener("beforeunload", onBeforeUnload);
    return () => {
      mountedRef.current = false;
      window.removeEventListener("beforeunload", onBeforeUnload);
      window.clearTimeout(flushTimer.current);
      window.clearTimeout(retryTimer.current);
      window.clearTimeout(finalSyncTimer.current);
      window.clearTimeout(backTimer.current);
    };
  }, [session]);

  // ----- strike warnings / ejection (server-reported only) -----
  const [rules, setRules] = useState<ProctorRules>(DEFAULT_PROCTOR_RULES);
  const rulesRef = useRef<ProctorRules>(DEFAULT_PROCTOR_RULES);
  const applyRules = useCallback((next: ProctorRules) => {
    rulesRef.current = next;
    setRules(next);
  }, []);
  const [strikes, setStrikes] = useState(0);
  const prevStrikesRef = useRef(0);
  const [warning, setWarning] = useState<{ n: number; limit: number } | null>(null);
  const [ejected, setEjected] = useState(false);
  const [lockReason, setLockReason] = useState<"long_absence" | "strikes" | null>(null);
  const strikeLimit = rules.limit;

  // Load the server thresholds once; every response can refresh them.
  useEffect(() => {
    let alive = true;
    void getProctorRules().then((r) => {
      if (alive && r) applyRules(r);
    });
    return () => {
      alive = false;
    };
  }, [applyRules]);

  /** Absorb strike/ejection metadata from any server response — never invented. */
  const applyProctorMeta = useCallback(
    (
      d: {
        strikes?: number;
        limit?: number;
        ejected?: boolean;
        reason?: "long_absence" | "strikes" | null;
        rules?: ProctorRules;
      } | null | undefined,
    ) => {
      if (!d || sessionLostRef.current) return;
      if (d.rules) {
        applyRules(d.rules);
      } else if (typeof d.limit === "number") {
        applyRules({ ...rulesRef.current, limit: d.limit });
      }
      if (typeof d.strikes === "number") {
        if (d.strikes > prevStrikesRef.current && !d.ejected) {
          setWarning({ n: d.strikes, limit: rulesRef.current.limit });
        }
        prevStrikesRef.current = d.strikes;
        setStrikes(d.strikes);
      }
      if (d.ejected) {
        setLockReason(d.reason ?? "strikes");
        setEjected(true);
        markSessionLost();
      }
    },
    [markSessionLost, applyRules],
  );

  /* ---------- server clock sync (DB mode): deadline + status ---------- */
  const syncClock = useCallback(async () => {
    if (!session || syncInFlight.current || endedRef.current || sessionLostRef.current) return;
    syncInFlight.current = true;
    try {
      const { data, error } = await fetchAttemptClock(session.attemptId);
      if (error || !data) return; // silent: keep last known deadline, retry next tick
      if (data.session_ok === false) {
        // This login's approved check-in is gone — halt everything below.
        markSessionLost();
        return;
      }
      if (data.status !== "in_progress") {
        endedRef.current = true;
        setEndedByServer(true); // the submit effect below takes it from here
        return;
      }
      const newDeadline = new Date(data.deadline_at).getTime();
      if (deadlineRef.current !== newDeadline) setDeadlineNotice(true);
      deadlineRef.current = newDeadline;
      setDeadlineAt(newDeadline);
      setClockOffset(new Date(data.server_now).getTime() - Date.now());
      applyProctorMeta({ strikes: data.strikes, ejected: data.ejected, reason: data.reason, rules: data.rules });
    } finally {
      syncInFlight.current = false;
    }
  }, [session, markSessionLost, applyProctorMeta]);

  syncClockRef.current = () => void syncClock();

  // Poll with jitter; re-sync on tab focus and on reconnect.
  // Stops entirely once the check-in is lost — no point asking the server.
  useEffect(() => {
    if (!session || sessionLost) return;
    let alive = true;
    let timer: number | undefined;

    const schedule = () => {
      const jitter = (Math.random() * 10 - 5) * 1000; // ±5s
      timer = window.setTimeout(() => {
        if (!alive) return;
        void syncClock().finally(() => {
          if (alive) schedule();
        });
      }, 30_000 + jitter);
    };

    const onVisibility = () => {
      if (document.visibilityState === "visible") void syncClock();
    };
    const onOnline = () => void syncClock();
    document.addEventListener("visibilitychange", onVisibility);
    window.addEventListener("online", onOnline);
    schedule();

    return () => {
      alive = false;
      window.clearTimeout(timer);
      document.removeEventListener("visibilitychange", onVisibility);
      window.removeEventListener("online", onOnline);
    };
  }, [session, syncClock, sessionLost]);

  /* ---------- live away pings (left / back) for the invigilator ----------
     One ordered promise chain so "back" can never overtake its "left".
     No UI, never throws, never blocks answering. */
  const tokenRef = useRef<string | null>(null);
  const awayChain = useRef<Promise<void>>(Promise.resolve());
  const awaySent = useRef(false); // a "left" is outstanding for this absence
  const pendingBack = useRef(false);
  const backTries = useRef(0);
  const backTimer = useRef<number | undefined>(undefined);
  const lastLeftAt = useRef(0);
  const lastAwayKind = useRef<"tab_hidden" | "window_shrunk">("tab_hidden");
  /* Back-reconcile loop: recovers a "left" whose return event never fired
     (e.g. an assistant overlay that never hides the page). Refs so the arm/disarm
     helpers stay stable across renders and effect lifetimes. */
  const reconcileTimer = useRef<number | undefined>(undefined);
  const touchArmed = useRef(false);
  const recoverEpisodeRef = useRef<() => void>(() => {});
  const armReconcileRef = useRef<() => void>(() => {});
  const phaseRef = useRef(phase);
  phaseRef.current = phase;
  const examLockedRef = useRef(locked);
  examLockedRef.current = locked;

  const canPing = () =>
    Boolean(session) && !sessionLostRef.current && phaseRef.current === "running" && !examLockedRef.current;

  useEffect(() => {
    if (!session) return;
    let alive = true;
    void supabase.auth.getSession().then(({ data }) => {
      if (alive) tokenRef.current = data.session?.access_token ?? null;
    });
    const { data: sub } = supabase.auth.onAuthStateChange((_event, s) => {
      tokenRef.current = s?.access_token ?? null; // held in memory only, never logged
    });
    return () => {
      alive = false;
      sub.subscription.unsubscribe();
    };
  }, [session]);

  const sendBackRef = useRef<() => void>(() => {});

  const sendBack = useCallback(() => {
    if (!canPing() || !pendingBack.current) return;
    awayChain.current = awayChain.current.then(async () => {
      if (!session || sessionLostRef.current || !pendingBack.current) return;
      const { error } = await rpcSetAway(session.attemptId, false, lastAwayKind.current);
      if (debugOn) lastAwayPingRef.current = { dir: "back", ok: !error, t: Date.now() }; // DEBUG-STRIP AUX
      if (!error) {
        pendingBack.current = false;
        backTries.current = 0;
        return;
      }
      if (/check-in is not valid/i.test(error.message)) {
        pendingBack.current = false;
        markSessionLost();
        return;
      }
      if (backTries.current < 3) {
        const delay = 2000 * 2 ** backTries.current; // 2s, 4s, 8s
        backTries.current += 1;
        window.clearTimeout(backTimer.current);
        backTimer.current = window.setTimeout(() => sendBackRef.current(), delay);
      }
    });
  }, [session, markSessionLost]); // eslint-disable-line react-hooks/exhaustive-deps
  sendBackRef.current = sendBack;

  const sendLeft = useCallback(
    (kind: "tab_hidden" | "window_shrunk", viaKeepalive: boolean) => {
      if (!canPing()) return;
      if (awaySent.current) return; // at most one "left" per absence
      const now = Date.now();
      if (now - lastLeftAt.current < 2000) return; // and never more than one per 2s
      lastLeftAt.current = now;
      awaySent.current = true;
      lastAwayKind.current = kind;
      armReconcileRef.current(); // make sure a return is reconciled even if no event fires
      awayChain.current = awayChain.current.then(async () => {
        if (!session || sessionLostRef.current) return;
        let ok = false;
        let msg = "";
        if (viaKeepalive && tokenRef.current) {
          ok = await sendAwayKeepalive(session.attemptId, true, kind, tokenRef.current);
        } else {
          const r = await rpcSetAway(session.attemptId, true, kind);
          ok = !r.error;
          msg = r.error?.message ?? "";
        }
        if (debugOn) lastAwayPingRef.current = { dir: "left", ok, t: Date.now() }; // DEBUG-STRIP AUX
        // A failed "left" is never retried — the strike event still counts later.
        if (!ok && /check-in is not valid/i.test(msg)) markSessionLost();
      });
    },
    [session, markSessionLost], // eslint-disable-line react-hooks/exhaustive-deps
  );

  const sendBackNow = useCallback(() => {
    if (!session || sessionLostRef.current) return;
    if (!awaySent.current) {
      if (pendingBack.current) sendBackRef.current(); // retry a stale failed back
      return;
    }
    awaySent.current = false;
    pendingBack.current = true;
    backTries.current = 0;
    window.clearTimeout(backTimer.current);
    sendBackRef.current();
  }, [session]);

  /* A "left" whose return never raised an event (assistant overlay that never
     hides the page) is recovered here: end any focus-loss episode through the
     existing logic (hides the overlay and reports 'window_shrunk' with the
     elapsed duration if it qualifies), then make sure set_away(false) rides the
     ordered chain. Runs only while a left is outstanding / a back unconfirmed,
     only while visible, and never when locked/submitted/sessionLost. */
  const reconcileBackRef = useRef<() => void>(() => {});
  const reconcileBack = useCallback(() => {
    if (!canPing()) return;
    if (!(awaySent.current || pendingBack.current)) return; // no absence to close
    if (document.visibilityState !== "visible") return;
    recoverEpisodeRef.current(); // hide overlay + report qualifying event + shrunk-kind back
    sendBackNow(); // ensure a back for any outstanding kind, through the ordered chain
  }, [sendBackNow]); // eslint-disable-line react-hooks/exhaustive-deps
  reconcileBackRef.current = reconcileBack;

  /* ---------- silent proctor event logging (DB mode only) ----------
     In-memory queue, batched sends, no UI, no storage, never blocks. */
  interface ProctorEntry {
    kind: ProctorEventKind;
    duration_ms: number;
    ts: number;
  }
  const proctorQueue = useRef<ProctorEntry[]>([]);
  const proctorInFlight = useRef(false);
  const proctorRetryTimer = useRef<number | undefined>(undefined);
  const proctorRetryCount = useRef(0);
  const proctorJitter = useRef(Math.random() * 30_000 - 15_000); // ±15s, once per session
  const hiddenSince = useRef<number | null>(null);
  const offlineSince = useRef<number | null>(null);
  const proctorActive = useRef(false);
  const sendProctorRef = useRef<() => void>(() => {});
  const strikeSendTimer = useRef<number | undefined>(undefined);

  /** Only a real absence counts: tab/app hidden for ≥ strike_ms. Everything
   *  else is logged but rides the normal 60s batch. */
  const isStrikeEvent = (kind: ProctorEventKind, durationMs: number) =>
    (kind === "tab_hidden" || kind === "window_shrunk") && durationMs >= rulesRef.current.strike_ms;

  const pushProctor = useCallback(
    (kind: ProctorEventKind, durationMs = 0) => {
      if (!session || !proctorActive.current || sessionLostRef.current) return;
      const dur = Math.max(0, Math.round(durationMs));
      proctorQueue.current.push({ kind, duration_ms: dur, ts: Date.now() });
      if (proctorQueue.current.length > 200) proctorQueue.current.splice(0, proctorQueue.current.length - 200);
      // Strike-worthy absences report fast: first land any dirty answers
      // (bounded 3s wait), then send the events. Never throws, never stalls.
      if (isStrikeEvent(kind, dur)) {
        window.clearTimeout(strikeSendTimer.current);
        strikeSendTimer.current = window.setTimeout(() => {
          void (async () => {
            try {
              await awaitSaves(3000);
            } catch {
              /* answers stay in the local cache; reporting proceeds anyway */
            }
            sendProctorRef.current();
          })();
        }, 500);
      }
    },
    [session, awaitSaves],
  );

  const sendProctor = useCallback(async () => {
    if (!session || proctorInFlight.current || sessionLostRef.current) return;
    if (proctorQueue.current.length === 0) return;
    proctorInFlight.current = true;
    window.clearTimeout(proctorRetryTimer.current);
    const batch = proctorQueue.current.slice(0, 50); // server caps a batch at 50
    const now = Date.now();
    const payload = batch.map((e) => ({
      kind: e.kind,
      duration_ms: e.duration_ms,
      ago_ms: Math.max(0, now - e.ts), // relative age only — never absolute times
    }));
    try {
      const { data, error } = await logProctorEvents(session.attemptId, payload);
      if (!mountedRef.current) return;
      if (error) {
        if (/check-in is not valid/i.test(error.message)) {
          proctorQueue.current = [];
          markSessionLost();
          return;
        }
        // Keep the events; back off 10s -> 20s -> 40s -> cap 60s.
        const delay = Math.min(10_000 * 2 ** proctorRetryCount.current, 60_000);
        proctorRetryCount.current += 1;
        proctorRetryTimer.current = window.setTimeout(() => sendProctorRef.current(), delay);
        return;
      }
      // { logged: 0 } (attempt ended) also counts as delivered.
      proctorQueue.current.splice(0, batch.length);
      proctorRetryCount.current = 0;
      applyProctorMeta(data);
    } finally {
      proctorInFlight.current = false;
    }
  }, [session, markSessionLost, applyProctorMeta]);
  sendProctorRef.current = () => void sendProctor();

  useEffect(() => {
    if (!session) return;
    proctorActive.current = true;

    // Back-button guard: one marker entry; popstate logs and re-pushes it.
    history.pushState({ proctorGuard: true }, "");
    const onPop = () => {
      pushProctor("back", 0);
      history.pushState({ proctorGuard: true }, "");
    };
    window.addEventListener("popstate", onPop);

    const onVis = () => {
      if (document.visibilityState === "hidden") {
        hiddenSince.current = Date.now();
        // If a focus/split episode's ping is outstanding, close it first so the
        // chain stays ordered, then report the tab-hidden absence.
        if (awaySent.current && lastAwayKind.current === "window_shrunk") sendBackNow();
        sendLeft("tab_hidden", true); // live "left" ping survives tab close
      } else {
        if (hiddenSince.current != null) {
          const d = Date.now() - hiddenSince.current;
          hiddenSince.current = null;
          if (d >= 1000) pushProctor("tab_hidden", d); // ignore sub-second flickers
        }
        sendBackNow(); // clear any live away alert, even for short absences
        sendProctorRef.current();
      }
    };
    document.addEventListener("visibilitychange", onVis);

    const onOffline = () => {
      offlineSince.current = Date.now();
    };
    const onOnline = () => {
      if (offlineSince.current != null) {
        pushProctor("offline", Date.now() - offlineSince.current);
        offlineSince.current = null;
      }
      sendProctorRef.current();
    };
    window.addEventListener("offline", onOffline);
    window.addEventListener("online", onOnline);

    // copy/cut/paste are observed, never blocked or read.
    const onCopyLike = () => pushProctor("copy", 0);
    const onPaste = () => pushProctor("paste", 0);
    document.addEventListener("copy", onCopyLike);
    document.addEventListener("cut", onCopyLike);
    document.addEventListener("paste", onPaste);

    const timer = window.setInterval(() => {
      sendProctorRef.current();
      sendBackRef.current(); // retry a failed "back" on every batch tick
    }, 60_000 + proctorJitter.current);

    return () => {
      proctorActive.current = false;
      window.clearInterval(timer);
      window.clearTimeout(proctorRetryTimer.current);
      window.clearTimeout(strikeSendTimer.current);
      window.removeEventListener("popstate", onPop);
      document.removeEventListener("visibilitychange", onVis);
      window.removeEventListener("offline", onOffline);
      window.removeEventListener("online", onOnline);
      document.removeEventListener("copy", onCopyLike);
      document.removeEventListener("cut", onCopyLike);
      document.removeEventListener("paste", onPaste);
    };
  }, [session, pushProctor, sendLeft, sendBackNow]);

  /* ---------- away-from-exam detection (shrunk window OR lost focus) ----------
     Touch devices only, DB mode only. One absence → exactly one event; the
     overlay blocks answering while timer, autosave and sync keep running. */
  useEffect(() => {
    if (!session) return;
    if (!window.matchMedia("(pointer: coarse)").matches) return; // phones/tablets only

    let alive = true;
    let awaySince: number | null = null;
    let awayKindLocal: "shrunk" | "focus" = "focus";
    let reported = false;
    let visibleBlockUntil = 0;
    let confirmTimer: number | undefined;
    let tickTimer: number | undefined;
    let resizeTimer: number | undefined;
    let orientTimer: number | undefined;
    let graceTimer: number | undefined;

    const clearEpisodeTimers = () => {
      window.clearTimeout(confirmTimer);
      window.clearInterval(tickTimer);
      confirmTimer = undefined;
      tickTimer = undefined;
    };

    const isShrunkNow = () => {
      const area = window.innerWidth * window.innerHeight;
      const screenArea = screen.width * screen.height;
      return screenArea > 0 && area / screenArea < SHRINK_RATIO;
    };

    // An episode is live while the page is visible and the window is shrunk
    // or another app/window holds focus (e.g. a floating assistant).
    const isAwayNow = () =>
      document.visibilityState === "visible" && (isShrunkNow() || !document.hasFocus());

    const resetEpisode = () => {
      awaySince = null;
      reported = false;
      clearEpisodeTimers();
    };

    const startTick = () => {
      window.clearInterval(tickTimer);
      tickTimer = window.setInterval(() => {
        if (awaySince == null) return;
        // Recovery can arrive between events — poll focus too, not just listeners.
        if (!isShrunkNow() && document.hasFocus()) {
          recover();
          return;
        }
        if (!reported && Date.now() - awaySince >= rulesRef.current.lock_ms) {
          reported = true; // exactly one event per absence
          pushProctor("window_shrunk", rulesRef.current.lock_ms);
        }
      }, awayKindLocal === "shrunk" ? SHRINK_TICK_MS : FOCUS_TICK_MS);
    };

    const recover = () => {
      clearEpisodeTimers();
      setAway(false);
      // Only clear this episode's own ping; a tab-hidden ping owns its own back.
      if (awaySent.current && lastAwayKind.current === "window_shrunk") sendBackNow();
      if (awaySince != null) {
        const elapsed = Date.now() - awaySince;
        if (!reported && elapsed >= 1000) pushProctor("window_shrunk", elapsed);
      }
      resetEpisode();
    };
    recoverEpisodeRef.current = recover; // let the back-reconcile loop end an episode

    // Tab hidden mid-episode: the tab_hidden event covers it — cancel silently.
    const cancelSilently = () => {
      clearEpisodeTimers();
      setAway(false);
      if (awaySent.current && lastAwayKind.current === "window_shrunk") sendBackNow();
      resetEpisode();
    };

    const begin = () => {
      if (awaySince != null) return;
      awaySince = Date.now();
      awayKindLocal = isShrunkNow() ? "shrunk" : "focus";
      reported = false;
      const confirmMs = awayKindLocal === "shrunk" ? SHRINK_CONFIRM_MS : FOCUS_CONFIRM_MS;
      confirmTimer = window.setTimeout(() => {
        if (!alive || awaySince == null) return;
        if (isAwayNow()) {
          setAwayKind(awayKindLocal);
          setAway(true);
          sendLeft("window_shrunk", false); // live ping at overlay confirmation
          startTick();
        } else {
          resetEpisode(); // recovered before confirmation — log nothing
        }
      }, confirmMs);
    };

    const evaluate = () => {
      if (!alive) return;
      if (document.visibilityState === "hidden") return;
      if (Date.now() < visibleBlockUntil) return; // 1s grace after returning
      if (isAwayNow()) begin();
      else if (awaySince != null) recover();
    };

    const onResize = () => {
      window.clearTimeout(resizeTimer);
      resizeTimer = window.setTimeout(evaluate, RESIZE_DEBOUNCE_MS);
    };
    const onOrient = () => {
      window.clearTimeout(orientTimer);
      orientTimer = window.setTimeout(evaluate, 300);
    };
    const onBlur = () => {
      if (document.visibilityState === "hidden") return; // covered by tab_hidden
      if (Date.now() < visibleBlockUntil) return; // focus returns late after a tab switch
      evaluate();
    };
    const onFocus = () => evaluate();
    const onVis = () => {
      if (document.visibilityState === "hidden") {
        if (awaySince != null) cancelSilently();
      } else {
        visibleBlockUntil = Date.now() + 1000;
        window.clearTimeout(graceTimer);
        graceTimer = window.setTimeout(evaluate, 1050);
      }
    };

    window.addEventListener("resize", onResize);
    window.addEventListener("orientationchange", onOrient);
    window.addEventListener("blur", onBlur);
    window.addEventListener("focus", onFocus);
    document.addEventListener("visibilitychange", onVis);
    evaluate();

    return () => {
      alive = false;
      window.removeEventListener("resize", onResize);
      window.removeEventListener("orientationchange", onOrient);
      window.removeEventListener("blur", onBlur);
      window.removeEventListener("focus", onFocus);
      document.removeEventListener("visibilitychange", onVis);
      window.clearTimeout(resizeTimer);
      window.clearTimeout(orientTimer);
      window.clearTimeout(graceTimer);
      clearEpisodeTimers();
      recoverEpisodeRef.current = () => {};
      setAway(false);
    };
  }, [session, pushProctor, sendLeft, sendBackNow]);

  /* ---------- reliable "back" reconcile (DB mode only) ----------
     An assistant overlay (e.g. Gemini-in-Chrome) can hold focus without ever
     hiding the page, so no visibilitychange/focus fires on return and a "back"
     may never be sent — the panel shows the student away forever. While a left
     is outstanding / a back is unconfirmed, poll ~2s ±0.3s; a check says "back"
     when the page has focus. Pauses while hidden, runs one check at once on
     becoming visible, and also reconciles on focus/pageshow/resume/visible. A
     trusted tap counts too — but never inside a split-screen episode. The loop
     stops only once the back is confirmed (existing retry/backoff persists). */
  useEffect(() => {
    if (!dbMode) return; // DB mode only; a static exam sends nothing extra

    const predicate = () => awaySent.current || pendingBack.current;

    let alive = true;

    const detachTouch = () => {
      if (!touchArmed.current) return;
      touchArmed.current = false;
      document.removeEventListener("pointerdown", onTouchBack, true);
      document.removeEventListener("touchstart", onTouchBack, true);
    };

    // Point 3: the first trusted interaction while visible + not shrunk counts
    // as "back". Removed again as soon as there is no absence to close.
    function onTouchBack(ev: Event) {
      if (!ev.isTrusted) return;
      if (!alive || !canPing() || !predicate()) {
        detachTouch();
        return;
      }
      if (document.visibilityState !== "visible") return;
      if (isWindowShrunk()) return; // a split-screen episode is not ended by a tap
      detachTouch();
      reconcileBackRef.current();
    }

    const attachTouch = () => {
      if (touchArmed.current) return;
      touchArmed.current = true;
      document.addEventListener("pointerdown", onTouchBack, true);
      document.addEventListener("touchstart", onTouchBack, true);
    };

    const runCheck = () => {
      if (!alive || !canPing() || !predicate()) return;
      if (document.visibilityState !== "visible") return; // paused while hidden
      if (document.hasFocus()) reconcileBackRef.current(); // point 2: focus == back
    };

    const scheduleNext = () => {
      if (!alive) return;
      window.clearTimeout(reconcileTimer.current);
      const jitter = Math.random() * RECONCILE_JITTER_MS * 2 - RECONCILE_JITTER_MS;
      reconcileTimer.current = window.setTimeout(tick, RECONCILE_MS + jitter);
    };

    function tick() {
      if (!alive) return;
      if (!canPing() || !predicate()) {
        detachTouch(); // confirmed / locked / lost → stop everything
        return;
      }
      if (document.visibilityState === "hidden") return; // paused; onVis re-arms
      attachTouch();
      runCheck();
      scheduleNext(); // keep looping until the back is confirmed
    }

    const arm = () => {
      if (!alive || !canPing() || !predicate()) return; // present students send nothing
      if (document.visibilityState === "visible") {
        attachTouch();
        runCheck(); // one check at once when armed / when we become visible
      }
      scheduleNext();
    };
    armReconcileRef.current = arm;

    const onVis = () => {
      if (document.visibilityState === "visible") arm();
    };
    const onPageShow = (e: PageTransitionEvent) => {
      if (e.persisted) arm(); // restored from bfcache
    };
    const onResume = () => arm(); // Android WebView resume
    const onFocus = () => arm();

    document.addEventListener("visibilitychange", onVis);
    window.addEventListener("pageshow", onPageShow);
    window.addEventListener("focus", onFocus);
    document.addEventListener("resume", onResume);

    if (predicate()) arm(); // already away when this mounts

    return () => {
      alive = false;
      armReconcileRef.current = () => {};
      window.clearTimeout(reconcileTimer.current);
      detachTouch();
      document.removeEventListener("visibilitychange", onVis);
      window.removeEventListener("pageshow", onPageShow);
      window.removeEventListener("focus", onFocus);
      document.removeEventListener("resume", onResume);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dbMode]);

  // Time-up or server-ended → drain saves, then submit via the idempotent RPC,
  // exactly once. (DB mode never uses the local static submit path.)
  // A lost check-in skips this entirely — the server grades what it received.
  useEffect(() => {
    if (!dbMode || phase !== "running" || sessionLost) return;
    if (!(timeUp || endedByServer)) return;
    if (autoSubmitStarted.current) return;
    autoSubmitStarted.current = true;
    setDbLocked(true);
    // Stagger the first auto-submit by 0–3s; the RPC carries all local answers.
    submitRetryTimer.current = window.setTimeout(
      () => doDbSubmitRef.current(true),
      Math.random() * AUTO_SUBMIT_JITTER_MS,
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dbMode, timeUp, endedByServer, phase, sessionLost]);

  // Batched sync cadence: one jittered timer + hidden-tab and reconnect nudges.
  useEffect(() => {
    if (!session || sessionLost) return;
    const timer = window.setInterval(syncIfDirty, SYNC_INTERVAL_MS + jitterRef.current);
    const onVisibility = () => {
      if (document.visibilityState === "hidden") syncIfDirty();
    };
    const onOnline = () => syncIfDirty();
    document.addEventListener("visibilitychange", onVisibility);
    window.addEventListener("online", onOnline);
    return () => {
      window.clearInterval(timer);
      document.removeEventListener("visibilitychange", onVisibility);
      window.removeEventListener("online", onOnline);
    };
  }, [session, syncIfDirty, sessionLost]);

  const submit = useCallback(() => {
    const correct = qs.filter((qq) => answers[qq.id] === qq.correctId).length;
    const r: ExamResult = {
      examId: exam.id,
      answers,
      correct,
      total,
      scorePct: Math.round((correct / total) * 100),
      submittedAt: Date.now(),
    };
    setResult(r);
    setConfirming(false);
    setPhase("results");
    onSubmitted(r);
  }, [answers, qs, exam.id, onSubmitted, total]);

  // Static mode only — server attempts never auto-grade on the client.
  useEffect(() => {
    if (!dbMode && seconds === 0 && phase === "running") submit();
  }, [seconds, phase, submit, dbMode]);

  // Trigger the results-dial sweep on the frame after results mount.
  useEffect(() => {
    if (phase !== "results") return;
    const raf = requestAnimationFrame(() => setDialReady(true));
    return () => cancelAnimationFrame(raf);
  }, [phase]);

  const pick = (qid: string, oid: string) => {
    if (locked) return; // clock ran out or server ended the attempt — locked
    const next = { ...answers, [qid]: oid };
    setAnswers(next);
    if (dbMode) {
      // Local-only: mark dirty and persist synchronously — no network here.
      pendingRef.current[qid] = oid;
      persistCache(next);
      if (remainingMsRef.current <= FINAL_WINDOW_MS) {
        // Final stretch: sync soon (1s debounce) so the server stays warm.
        window.clearTimeout(finalSyncTimer.current);
        finalSyncTimer.current = window.setTimeout(() => syncIfDirty(), 1000);
      }
    } else {
      setSaveFlash(true);
      window.setTimeout(() => setSaveFlash(false), 1100);
    }
  };

  const handleFinish = () => {
    if (dbMode && (timeUp || endedByServer || submitting)) return; // auto path owns it
    setConfirming(true);
  };

  // Refs so the keyboard handler never sees a stale pick()/locked snapshot.
  const pickRef = useRef(pick);
  pickRef.current = pick;
  const lockedRef = useRef(locked);
  lockedRef.current = locked;

  const toggleFlag = useCallback(() => {
    setFlagged((f) => ({ ...f, [q.id]: !f[q.id] }));
  }, [q.id]);

  /* ---------- keyboard: 1–4 select, arrows navigate, F flags ---------- */
  useEffect(() => {
    if (phase !== "running") return;
    const onKey = (e: KeyboardEvent) => {
      if (lockedRef.current) return; // locked answers ignore key input
      const n = Number(e.key);
      if (n >= 1 && n <= q.options.length) {
        pickRef.current(q.id, q.options[n - 1].id);
      } else if (e.key === "ArrowRight") {
        setIdx((i) => Math.min(total - 1, i + 1));
      } else if (e.key === "ArrowLeft") {
        setIdx((i) => Math.max(0, i - 1));
      } else if (e.key.toLowerCase() === "f") {
        toggleFlag();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [phase, q, total, toggleFlag]);

  /* ================================================================== */
  /*  RESULTS VIEW                                                       */
  /* ================================================================== */
  if (phase === "results" && result) {
    const passPct = passPctOf(exam);
    const passed = result.scorePct >= passPct;
    const R = 52;
    const C = 2 * Math.PI * R;
    // Start the dial fully "empty" for one frame, then let CSS animate it in.
    const sweep = dialReady ? C * (1 - result.scorePct / 100) : C;

    return (
      <div className="relative z-10 mx-auto flex min-h-dvh w-full max-w-[640px] flex-col justify-center px-5 py-12">
        <section className="animate-rise overflow-hidden rounded-[26px] bg-white shadow-[0_28px_60px_-22px_rgba(190,80,115,0.4)]">
          <div className={"h-[6px] w-full " + (passed ? "bg-gradient-to-r from-emerald-400 to-teal-400" : "bg-gradient-to-r from-rose-400 to-red-400")} />
          <div className="flex flex-col items-center px-7 pb-7 pt-9 text-center">
            <span className="text-[10.5px] font-bold tracking-[0.22em] text-neutral-400">
              {exam.course} · SUBMITTED
            </span>
            <h2 className="mt-1.5 text-[24px] font-extrabold tracking-tight text-neutral-900">{exam.title}</h2>

            <div className="relative mt-7 h-[140px] w-[140px]">
              <svg viewBox="0 0 120 120" className="h-full w-full -rotate-90">
                <circle cx="60" cy="60" r={R} fill="none" stroke="#f3e8e4" strokeWidth="10" />
                <circle
                  cx="60"
                  cy="60"
                  r={R}
                  fill="none"
                  stroke={passed ? "#10b981" : "#f43f5e"}
                  strokeWidth="10"
                  strokeLinecap="round"
                  strokeDasharray={C}
                  strokeDashoffset={sweep}
                  className="transition-[stroke-dashoffset] duration-[1400ms] ease-out"
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-[34px] font-extrabold leading-none text-neutral-900">{result.scorePct}%</span>
                <span className="mt-1 text-[10.5px] font-bold tracking-[0.14em] text-neutral-400">
                  {result.correct}/{result.total} CORRECT
                </span>
              </div>
            </div>

            {endedByServer ? (
              <span className="mt-5 rounded-full bg-neutral-100 px-4 py-1.5 text-[12px] font-extrabold tracking-wide text-neutral-600">
                This attempt has ended.
              </span>
            ) : (
              <span
                className={
                  "mt-5 rounded-full px-4 py-1.5 text-[12px] font-extrabold tracking-wide " +
                  (passed ? "bg-emerald-50 text-emerald-600" : "bg-rose-50 text-rose-500")
                }
              >
                {passed ? "PASSED — well done" : `BELOW ${passPct}% — review advised`}
              </span>
            )}

            <div className="mt-7 flex flex-wrap justify-center gap-3">
              <button
                type="button"
                onClick={onExit}
                className="flex items-center gap-2 rounded-2xl bg-neutral-950 px-5 py-3 text-[13px] font-extrabold text-white shadow-[0_14px_30px_-12px_rgba(0,0,0,0.55)] transition-all hover:-translate-y-0.5 active:scale-[0.98]"
              >
                <ArrowLeft className="h-4 w-4" strokeWidth={2.5} />
                Back to dashboard
              </button>
            </div>
          </div>
        </section>

        <section className="animate-rise mt-5 flex flex-col gap-3" style={{ animationDelay: "140ms" }}>
          {qs.map((qq, i) => {
            const mine = answers[qq.id];
            const right = mine === qq.correctId;
            return (
              <div key={qq.id} className="rounded-2xl bg-white p-5 shadow-[0_14px_30px_-18px_rgba(190,80,115,0.35)]">
                <div className="flex items-start gap-3">
                  <span
                    className={
                      "mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full " +
                      (right ? "bg-emerald-500" : "bg-rose-500")
                    }
                  >
                    {right ? <Check className="h-3.5 w-3.5 text-white" strokeWidth={3} /> : <X className="h-3.5 w-3.5 text-white" strokeWidth={3} />}
                  </span>
                  <div className="min-w-0">
                    <p className="text-[10.5px] font-bold tracking-[0.14em] text-neutral-400">
                      Q{i + 1} · {qq.topic.toUpperCase()}
                    </p>
                    <p className="mt-1 text-[13.5px] font-bold leading-snug text-neutral-800">{qq.prompt}</p>
                    <p className="mt-2 text-[12.5px] font-medium text-neutral-500">
                      Your answer:{" "}
                      <span className={right ? "font-bold text-emerald-600" : "font-bold text-rose-500"}>
                        {qq.options.find((o) => o.id === mine)?.text ?? "Not answered"}
                      </span>
                      {!right && (
                        <>
                          {"  ·  "}Correct:{" "}
                          <span className="font-bold text-emerald-600">{qq.options.find((o) => o.id === qq.correctId)?.text}</span>
                        </>
                      )}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </section>
      </div>
    );
  }

  /* ================================================================== */
  /*  SUBMITTED VIEW (server attempts — score stays with the faculty)    */
  /* ================================================================== */
  if (phase === "submitted" && session && submission) {
    const refCode = session.attemptId.replace(/-/g, "").slice(0, 8).toUpperCase();
    const submittedOn = new Date(submission.submittedAt).toLocaleString("en-US", {
      month: "long",
      day: "numeric",
      hour: "numeric",
      minute: "2-digit",
      hour12: true,
    });
    return (
      <div className="relative z-10 mx-auto flex min-h-dvh w-full max-w-[560px] flex-col justify-center px-5 py-12">
        <section className="animate-rise overflow-hidden rounded-[26px] bg-white shadow-[0_28px_60px_-22px_rgba(190,80,115,0.4)]">
          <div className="h-[6px] w-full bg-gradient-to-r from-emerald-400 to-teal-400" />
          <div className="flex flex-col items-center px-7 pb-8 pt-9 text-center">
            <span className="flex h-14 w-14 items-center justify-center rounded-full bg-emerald-100">
              <Check className="h-7 w-7 text-emerald-600" strokeWidth={2.6} />
            </span>
            <p className="mt-4 text-[10.5px] font-extrabold tracking-[0.2em] text-neutral-400">
              {exam.course} · {exam.code}
            </p>
            <h2 className="mt-1.5 text-[26px] font-extrabold tracking-tight text-neutral-900">
              Answers submitted
            </h2>
            <p className="mt-2.5 text-[14px] font-extrabold text-neutral-700">
              Answered {submission.answered} of {submission.total}
            </p>
            <p className="mt-1 text-[12px] font-semibold text-neutral-500">Submitted on {submittedOn}</p>
            <span className="mt-5 rounded-full bg-neutral-100 px-4 py-2 font-mono text-[12px] font-extrabold tracking-[0.14em] text-neutral-700">
              REF · {refCode}
            </span>
            <p className="mt-5 max-w-[36ch] text-[12.5px] font-medium leading-relaxed text-neutral-500">
              Results will be released after faculty review.
            </p>
            <button
              type="button"
              onClick={onExit}
              className="mt-7 flex items-center gap-2 rounded-2xl bg-neutral-950 px-6 py-3 text-[13px] font-extrabold text-white shadow-[0_14px_30px_-12px_rgba(0,0,0,0.55)] transition-all hover:-translate-y-0.5 active:scale-[0.98]"
            >
              <ArrowLeft className="h-4 w-4" strokeWidth={2.5} />
              Back to dashboard
            </button>
          </div>
        </section>
      </div>
    );
  }

  /* ================================================================== */
  /*  SESSION-LOST VIEW — the invigilator revoked this login mid-exam     */
  /* ================================================================== */
  if (dbMode && sessionLost) {
    return (
      <div className="relative z-10 mx-auto flex min-h-dvh w-full max-w-[560px] flex-col items-center justify-center px-6 py-12 text-center">
        <span className="animate-rise flex h-16 w-16 items-center justify-center rounded-full bg-rose-100 ring-8 ring-rose-50">
          <ShieldAlert className="h-8 w-8 text-rose-600" strokeWidth={2.1} />
        </span>
        <h2 className="animate-rise mt-6 text-[26px] font-extrabold leading-tight tracking-tight text-neutral-950" style={{ animationDelay: "60ms" }}>
          {ejected ? "You were removed from the exam." : "This login is no longer approved for the exam."}
        </h2>
        <p className="animate-rise mt-3 max-w-[40ch] text-[14px] font-semibold leading-relaxed text-neutral-600" style={{ animationDelay: "120ms" }}>
          {ejected
            ? lockReason === "long_absence"
              ? `You left the exam for ${Math.round(rules.lock_ms / 1000)} seconds or more, so your exam is locked. Call the invigilator to your desk. Your answers are saved and the exam clock keeps running.`
              : `You reached ${strikeLimit} warnings, so your exam is locked. Call the invigilator to your desk. Your answers are saved and the exam clock keeps running.`
            : "Ask the invigilator to check you in again. Your saved answers are kept and the exam clock keeps running."}
        </p>

        {/* server-anchored remaining time — keeps ticking honestly */}
        <div className="animate-rise mt-7 rounded-[22px] bg-white px-8 py-5 shadow-[0_20px_44px_-22px_rgba(190,80,115,0.5)]" style={{ animationDelay: "180ms" }}>
          <p className="text-[10px] font-extrabold tracking-[0.18em] text-neutral-400">EXAM TIME REMAINING</p>
          <p className={"mt-1 font-mono text-[40px] font-extrabold leading-none " + (low ? "text-rose-600" : "text-neutral-900")}>
            {fmt(Math.max(0, Math.floor(remainingMs / 1000)))}
          </p>
        </div>

        <button
          type="button"
          onClick={onSessionLost}
          className="animate-rise group mt-8 flex h-[54px] items-center justify-center gap-2.5 rounded-full bg-neutral-950 px-8 text-[14px] font-extrabold text-white shadow-[0_20px_40px_-16px_rgba(0,0,0,0.6)] transition-all hover:-translate-y-0.5 hover:bg-neutral-800 active:scale-[0.98]"
          style={{ animationDelay: "240ms" }}
        >
          Go to check-in
          <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" strokeWidth={2.6} />
        </button>
      </div>
    );
  }

  /* ================================================================== */
  /*  RUNNING VIEW                                                       */
  /* ================================================================== */
  const currentFlagged = Boolean(flagged[q.id]);
  const pendingCount = Object.keys(pendingRef.current).length;

  return (
    <div className="relative min-h-dvh">
      {/* ================= sticky session header ================= */}
      <header className="animate-rise sticky top-0 z-20 border-b border-rose-100/60 bg-[#fdf0ea]/85 px-4 pb-3 pt-4 backdrop-blur-md sm:px-6">
        <div className="mx-auto w-full max-w-[640px]">
          {/* row 1: identity + timer + avatar */}
          <div className="flex items-center gap-2.5 sm:gap-3">
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-yellow-300 text-neutral-900 shadow-[0_6px_14px_-6px_rgba(234,179,8,0.7)] sm:h-10 sm:w-10">
              <GraduationCap className="h-[18px] w-[18px] sm:h-5 sm:w-5" strokeWidth={2.2} />
            </span>
            <div className="min-w-0 flex-1">
              <p className="truncate text-[12.5px] font-extrabold leading-tight text-neutral-900 sm:text-[13.5px]">{exam.title}</p>
              <p className="mt-0.5 flex items-center gap-1.5 text-[10px] font-bold text-neutral-500 sm:text-[10.5px]">
                <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-pink-500" />
                Active
              </p>
            </div>
            <span
              className={
                "flex shrink-0 items-center gap-1 rounded-full px-2.5 py-1.5 font-mono text-[11px] font-extrabold transition-colors sm:gap-1.5 sm:px-3 sm:text-[12px] " +
                (low ? "animate-pulse bg-rose-500 text-white" : "bg-rose-100 text-rose-600")
              }
            >
              <Timer className="h-3.5 w-3.5" strokeWidth={2.5} />
              {fmt(Math.max(0, Math.floor(remainingMs / 1000)))}
              <span className="hidden sm:inline">Remaining</span>
            </span>
            <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-violet-600 text-white shadow-[0_8px_18px_-6px_rgba(124,58,237,0.6)] sm:h-9 sm:w-9">
              <UserIcon className="h-4 w-4 sm:h-[16px] sm:w-[16px]" strokeWidth={2.3} />
            </span>
          </div>

          {/* row 2: session meta */}
          <div className="mt-2.5 flex items-center justify-between">
            <span className="text-[9.5px] font-extrabold tracking-[0.16em] text-neutral-500">ACTIVE EXAM SESSION</span>
            <span className="text-[11px] font-extrabold text-neutral-700">
              Question {idx + 1} of {total}
            </span>
          </div>

          {/* row 3: code / flagged / autosaved pills */}
          <div className="mt-2 flex flex-wrap items-center gap-2">
            <span className="flex items-center gap-1 rounded-full bg-neutral-200/80 px-3 py-1 text-[10px] font-extrabold tracking-wide text-neutral-600">
              <Hash className="h-3 w-3" strokeWidth={2.6} />
              {exam.code}
            </span>
            <span className="flex items-center gap-1 rounded-full bg-yellow-300 px-3 py-1 text-[10px] font-extrabold text-neutral-800">
              <Bookmark className="h-3 w-3" fill={flaggedCount > 0 ? "currentColor" : "none"} strokeWidth={2.6} />
              {flaggedCount} Flagged
            </span>
            {dbMode ? (
              saveStatus === "error" ? (
                <button
                  type="button"
                  onClick={() => {
                    window.clearTimeout(retryTimer.current);
                    retryTimer.current = undefined;
                    retryCount.current = 0;
                    void flush();
                  }}
                  className="flex items-center gap-1 rounded-full bg-rose-500 px-3 py-1 text-[10px] font-extrabold text-white transition-all hover:bg-rose-400 active:scale-95"
                >
                  <RefreshCw className="h-3 w-3 animate-spin [animation-duration:2.5s]" strokeWidth={2.6} />
                  Not synced · retrying
                </button>
              ) : saveStatus === "saving" ? (
                <span className="flex items-center gap-1 rounded-full bg-yellow-300 px-3 py-1 text-[10px] font-extrabold text-neutral-800">
                  <Cloud className="h-3 w-3 animate-pulse" strokeWidth={2.6} />
                  Syncing…
                </span>
              ) : pendingCount > 0 ? (
                <span className="flex items-center gap-1 rounded-full bg-amber-100 px-3 py-1 text-[10px] font-extrabold text-amber-700 ring-1 ring-amber-300">
                  <Cloud className="h-3 w-3" strokeWidth={2.6} />
                  Saved on this device
                </span>
              ) : (
                <span className="flex items-center gap-1 rounded-full bg-emerald-500 px-3 py-1 text-[10px] font-extrabold text-white transition-all duration-300">
                  <Cloud className="h-3 w-3" strokeWidth={2.6} />
                  Saved
                </span>
              )
            ) : (
              <span
                className={
                  "flex items-center gap-1 rounded-full bg-yellow-300 px-3 py-1 text-[10px] font-extrabold text-neutral-800 transition-transform duration-300 " +
                  (saveFlash ? "scale-110" : "")
                }
              >
                <Cloud className="h-3 w-3" strokeWidth={2.6} />
                Autosaved
              </span>
            )}
            {dbMode && strikes > 0 && (
              <span
                className={
                  "flex items-center gap-1 rounded-full px-3 py-1 text-[10px] font-extrabold ring-1 transition-all duration-300 " +
                  (strikes >= strikeLimit
                    ? "bg-rose-500 text-white ring-rose-500"
                    : "bg-rose-100 text-rose-600 ring-rose-200")
                }
              >
                <AlertTriangle className="h-3 w-3" strokeWidth={2.6} />
                Warnings {strikes}/{strikeLimit}
              </span>
            )}
          </div>

          {/* row 4: progress */}
          <div className="mt-2.5">
            <div className="flex items-center justify-between text-[11px] font-extrabold">
              <span className="text-neutral-800">
                Question {idx + 1} of {total}
              </span>
              <span className="text-pink-500">
                {pct}% Completed ({answeredCount} answered)
              </span>
            </div>
            <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-white/80">
              <div
                className="h-full rounded-full bg-gradient-to-r from-pink-400 to-rose-500 transition-all duration-500 ease-out"
                style={{ width: `${Math.max(4, pct)}%` }}
              />
            </div>
          </div>
        </div>
      </header>

      {/* ================= question + navigator ================= */}
      <main className="relative z-10 mx-auto w-full max-w-[640px] px-4 pb-40 pt-5 sm:px-6">
        {/* server notices (non-blocking) */}
        {dbMode && deadlineNotice && !endedByServer && !timeUp && (
          <div className="animate-rise mb-4 flex items-center gap-2.5 rounded-2xl bg-amber-100 px-4 py-3 ring-1 ring-amber-300">
            <Timer className="h-4 w-4 shrink-0 text-amber-600" strokeWidth={2.4} />
            <p className="text-[12px] font-extrabold text-amber-800">Exam time was updated by the server.</p>
          </div>
        )}
        {dbMode && (timeUp || endedByServer) && (
          <div className="animate-rise mb-4 flex items-center gap-3 rounded-2xl bg-rose-500 p-4 text-white shadow-[0_16px_36px_-14px_rgba(244,63,94,0.7)]">
            <Timer className="h-5 w-5 shrink-0" strokeWidth={2.3} />
            <p className="text-[13px] font-extrabold">
              {endedByServer ? "This attempt has ended." : "Time is up."}
              {submitting &&
                (Object.keys(pendingRef.current).length > 0
                  ? " Saving your last answers…"
                  : dbSubmit.kind === "busy"
                    ? " Submitting…"
                    : " Submitting… retrying")}
            </p>
          </div>
        )}

        {dbMode && dbSubmit.kind === "error" && (
          <div className="animate-rise mb-4 flex flex-wrap items-center gap-3 rounded-2xl bg-rose-100 px-4 py-3 ring-1 ring-rose-300">
            <AlertTriangle className="h-4 w-4 shrink-0 text-rose-600" strokeWidth={2.4} />
            <p className="min-w-0 flex-1 text-[12px] font-extrabold text-rose-700">{dbSubmit.msg}</p>
            <button
              type="button"
              onClick={() => {
                setDbSubmit({ kind: "idle" });
                void doDbSubmit(false);
              }}
              className="shrink-0 rounded-full bg-rose-600 px-3.5 py-1.5 text-[11px] font-extrabold text-white transition-all hover:bg-rose-500 active:scale-95"
            >
              Retry
            </button>
          </div>
        )}

        {/* question card */}
        <section
          key={q.id}
          className={
            "animate-rise rounded-[26px] bg-white p-6 shadow-[0_24px_54px_-24px_rgba(190,80,115,0.5)] sm:p-7 " +
            (locked ? "opacity-70" : "")
          }
        >
          <div className="flex flex-wrap items-center gap-2.5">
            <span className="rounded-full bg-pink-200 px-3.5 py-1.5 text-[10.5px] font-extrabold tracking-wide text-pink-700">
              QUESTION {String(idx + 1).padStart(2, "0")} / {total}
            </span>
            <span className="rounded-full bg-neutral-100 px-3 py-1.5 text-[10.5px] font-extrabold text-neutral-500">
              {pts} Point{pts > 1 ? "s" : ""}
            </span>
            <span className="ml-auto text-[11px] font-bold text-neutral-400">Single Choice</span>
          </div>

          <h2 className="mt-4 text-[22px] font-extrabold leading-snug tracking-tight text-neutral-950">
            {q.prompt}
          </h2>
          {q.hint && <p className="mt-3 text-[13px] font-medium leading-relaxed text-neutral-500">{q.hint}</p>}

          <div className="mt-5 flex flex-col gap-3">
            {q.options.map((opt, i) => {
              const selected = answers[q.id] === opt.id;
              return (
                <button
                  key={opt.id}
                  type="button"
                  disabled={locked}
                  onClick={() => pick(q.id, opt.id)}
                  className={
                    "group flex items-center gap-3.5 rounded-full px-4 py-3 text-left transition-all duration-200 active:scale-[0.99] " +
                    (locked ? "cursor-not-allowed " : "") +
                    (selected
                      ? "bg-violet-200 shadow-[0_12px_26px_-14px_rgba(124,58,237,0.55)] ring-1 ring-violet-300"
                      : "bg-[#f3ede7] " + (locked ? "" : "hover:bg-[#efe6dd]"))
                  }
                >
                  <span
                    className={
                      "flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-[13px] font-extrabold transition-colors " +
                      (selected ? "bg-violet-600 text-white" : "bg-neutral-200 text-neutral-600 group-hover:bg-neutral-300")
                    }
                  >
                    {String.fromCharCode(65 + i)}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className={"block text-[14px] font-bold " + (selected ? "text-violet-900" : "text-neutral-800")}>
                      {opt.text}
                    </span>
                    {selected &&
                      (!dbMode ? saveFlash : confirmedSaves[q.id] === opt.id) && (
                        <span className="animate-rise mt-0.5 flex items-center gap-1 text-[10.5px] font-bold text-violet-600">
                          <Cloud className="h-3 w-3" strokeWidth={2.4} />
                          Autosaved in attempt
                        </span>
                      )}
                  </span>
                  {selected ? (
                    <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-violet-600">
                      <Check className="h-3.5 w-3.5 text-white" strokeWidth={3.2} />
                    </span>
                  ) : (
                    <span className="h-6 w-6 shrink-0 rounded-full border-2 border-neutral-300 transition-colors group-hover:border-neutral-400" />
                  )}
                </button>
              );
            })}
          </div>
        </section>

        {/* quick navigator */}
        <section
          className="animate-rise mt-5 rounded-[26px] bg-white p-6 shadow-[0_24px_54px_-24px_rgba(190,80,115,0.5)]"
          style={{ animationDelay: "80ms" }}
        >
          <button
            type="button"
            onClick={() => setNavOpen((o) => !o)}
            aria-expanded={navOpen}
            className="flex w-full items-center gap-3 text-left"
          >
            <LayoutGrid className="h-5 w-5 shrink-0 text-pink-500" strokeWidth={2.2} />
            <span className="min-w-0 flex-1">
              <span className="block text-[16px] font-extrabold tracking-tight text-neutral-950">Quick Navigator</span>
              <span className="mt-0.5 block text-[10.5px] font-bold text-neutral-500">
                Answered: {answeredCount} • Flagged: {flaggedCount} • Remaining: {remaining}
              </span>
            </span>
            <span
              className={
                "flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-pink-100 text-pink-600 transition-all duration-300 " +
                (navOpen ? "rotate-180" : "")
              }
            >
              <ChevronDown className="h-4 w-4" strokeWidth={2.6} />
            </span>
          </button>

          {/* collapsible body — smooth grid-rows height animation */}
          <div className={"grid transition-[grid-template-rows] duration-500 ease-out " + (navOpen ? "grid-rows-[1fr]" : "grid-rows-[0fr]")}>
            <div className="overflow-hidden">
              {/* legend */}
              <div className="mt-4 flex flex-wrap items-center gap-x-4 gap-y-1.5 text-[10.5px] font-extrabold text-neutral-600">
                <span className="flex items-center gap-1.5">
                  <Check className="h-3 w-3 text-pink-500" strokeWidth={3} /> Answered ({answeredCount})
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="h-2.5 w-2.5 rounded-full bg-neutral-900" /> Current (1)
                </span>
                <span className="flex items-center gap-1.5">
                  <Star className="h-3 w-3 text-yellow-500" fill="currentColor" strokeWidth={0} /> Flagged ({flaggedCount})
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="h-2.5 w-2.5 rounded-full border-2 border-neutral-300" /> Unvisited ({remaining})
                </span>
              </div>

              {/* grid */}
              <div className="mt-5 grid grid-cols-4 gap-2.5 sm:gap-3">
            {qs.map((qq, i) => {
              const isCurrent = i === idx;
              const isAnswered = Boolean(answers[qq.id]);
              const isFlagged = Boolean(flagged[qq.id]);
              const state = isCurrent ? "current" : isFlagged ? "flagged" : isAnswered ? "answered" : "unvisited";
              return (
                <button
                  key={qq.id}
                  type="button"
                  onClick={() => setIdx(i)}
                  aria-label={`Go to question ${i + 1}`}
                  className={
                    "flex h-14 flex-col items-center justify-center gap-0.5 rounded-full text-[12px] font-extrabold transition-all duration-200 hover:-translate-y-0.5 active:scale-95 " +
                    (state === "current"
                      ? "bg-neutral-900 text-white ring-2 ring-pink-500 shadow-[0_10px_22px_-8px_rgba(0,0,0,0.5)]"
                      : state === "flagged"
                        ? "bg-yellow-300 text-neutral-800 shadow-[0_8px_18px_-8px_rgba(234,179,8,0.7)]"
                        : state === "answered"
                          ? "bg-pink-200 text-neutral-800"
                          : "bg-neutral-200/70 text-neutral-600 hover:bg-neutral-200")
                  }
                >
                  Q{i + 1}
                  {state === "current" ? (
                    <span className="h-1 w-1 rounded-full bg-pink-400" />
                  ) : state === "flagged" ? (
                    <Bookmark className="h-2.5 w-2.5" fill="currentColor" strokeWidth={0} />
                  ) : state === "answered" ? (
                    <Check className="h-2.5 w-2.5 text-pink-600" strokeWidth={3.4} />
                  ) : null}
                </button>
              );
            })}
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* ================= sticky bottom bar ================= */}
      <footer className="fixed inset-x-0 bottom-0 z-20 border-t border-rose-100/60 bg-[#fdf0ea]/90 px-4 pb-3 pt-3 backdrop-blur-md sm:px-6">
        <div className="mx-auto w-full max-w-[640px]">
          <div className="flex items-center gap-2 sm:gap-2.5">
            <button
              type="button"
              onClick={toggleFlag}
              aria-label={currentFlagged ? "Remove flag" : "Flag this question"}
              className={
                "flex h-11 w-11 shrink-0 items-center justify-center rounded-full transition-all duration-200 active:scale-90 sm:h-12 sm:w-12 " +
                (currentFlagged
                  ? "bg-yellow-300 text-neutral-800 shadow-[0_10px_22px_-8px_rgba(234,179,8,0.8)]"
                  : "bg-[#f3ede7] text-neutral-500 hover:bg-[#efe6dd] hover:text-neutral-700")
              }
            >
              <Bookmark className="h-5 w-5" fill={currentFlagged ? "currentColor" : "none"} strokeWidth={2.2} />
            </button>

            <button
              type="button"
              onClick={() => setIdx((i) => Math.max(0, i - 1))}
              disabled={idx === 0}
              className="flex h-11 items-center gap-1.5 rounded-full bg-[#f3ede7] px-4 text-[12.5px] font-extrabold text-neutral-700 transition-all hover:bg-[#efe6dd] active:scale-[0.98] disabled:opacity-40 disabled:hover:bg-[#f3ede7] sm:h-12 sm:px-5 sm:text-[13px]"
            >
              <ArrowLeft className="h-4 w-4" strokeWidth={2.5} />
              Prev
            </button>

            <button
              type="button"
              onClick={() => setIdx((i) => Math.min(total - 1, i + 1))}
              disabled={idx === total - 1}
              className="group flex h-11 min-w-0 flex-1 items-center justify-center gap-2 rounded-full bg-neutral-950 text-[12.5px] font-extrabold text-white shadow-[0_14px_30px_-12px_rgba(0,0,0,0.6)] transition-all hover:bg-neutral-800 active:scale-[0.98] disabled:opacity-40 sm:h-12 sm:text-[13px]"
            >
              Next
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" strokeWidth={2.5} />
            </button>

            <button
              type="button"
              onClick={handleFinish}
              className="flex h-11 shrink-0 items-center gap-1.5 rounded-full bg-pink-500 px-4 text-[12.5px] font-extrabold text-white shadow-[0_14px_30px_-10px_rgba(236,72,153,0.6)] transition-all hover:-translate-y-0.5 hover:bg-pink-400 active:scale-[0.98] sm:h-12 sm:px-5 sm:text-[13px]"
            >
              <CheckCheck className="h-4 w-4" strokeWidth={2.6} />
              Finish
            </button>
          </div>

          {!dbMode && (
            <p className="mt-2.5 flex items-center justify-center gap-2 text-[9.5px] font-extrabold tracking-wide text-neutral-500">
              <span className="h-1.5 w-1.5 rounded-full bg-amber-500" />
              Attempt #1 • Session: {sessionId} • Seed: {seed}
            </p>
          )}
        </div>
      </footer>

      {/* ================= strike warning (never blocks timer/autosave) ================= */}
      {warning && !ejected && (
        <div className="fixed inset-0 z-40 flex items-center justify-center bg-neutral-950/50 p-5 backdrop-blur-sm">
          <div className="animate-pop w-full max-w-[400px] overflow-hidden rounded-[24px] bg-white shadow-[0_30px_70px_-20px_rgba(0,0,0,0.55)]">
            <div className="h-1.5 w-full bg-gradient-to-r from-amber-400 to-rose-400" />
            <div className="p-6">
              <div className="flex items-center gap-3">
                <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-amber-100">
                  <AlertTriangle className="h-[22px] w-[22px] text-amber-600" strokeWidth={2.2} />
                </span>
                <h3 className="text-[18px] font-extrabold tracking-tight text-neutral-950">
                  Warning {warning.n} of {warning.limit}
                </h3>
              </div>
              <p className="mt-3 text-[13px] font-medium leading-relaxed text-neutral-600">
                Leaving the exam was recorded and is visible to the invigilator.{" "}
                {warning.limit - warning.n} warning{warning.limit - warning.n === 1 ? "" : "s"} left. After{" "}
                {warning.limit} warnings you will be locked out and the invigilator must come to your desk.
              </p>
              <p className="mt-2 rounded-xl bg-amber-50 px-3.5 py-2.5 text-[12px] font-bold text-amber-800 ring-1 ring-amber-200">
                Leaving for {Math.round(rules.lock_ms / 1000)} seconds or more locks your exam immediately.
              </p>
              <button
                type="button"
                onClick={() => setWarning(null)}
                className="mt-5 flex min-h-12 w-full items-center justify-center rounded-full bg-neutral-950 text-[14px] font-extrabold text-white transition-all hover:-translate-y-0.5 hover:bg-neutral-800 active:scale-[0.98]"
              >
                I understand
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================= submit confirmation ================= */}
      {confirming && (
        <div className="fixed inset-0 z-30 flex items-end justify-center bg-neutral-950/40 p-5 backdrop-blur-sm sm:items-center" onClick={() => setConfirming(false)}>
          <div className="animate-pop w-full max-w-[400px] rounded-[24px] bg-white p-6 shadow-[0_30px_70px_-20px_rgba(0,0,0,0.5)]" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center gap-3">
              <span className="flex h-10 w-10 items-center justify-center rounded-2xl bg-pink-100">
                <Flag className="h-5 w-5 text-pink-600" strokeWidth={2.2} />
              </span>
              <div>
                <h3 className="text-[16px] font-extrabold text-neutral-900">Submit exam?</h3>
                <p className="text-[12px] font-medium text-neutral-500">
                  {remaining > 0
                    ? `${remaining} question${remaining > 1 ? "s" : ""} still unanswered.`
                    : "All questions answered."}{" "}
                  {flaggedCount > 0 && `${flaggedCount} flagged for review.`}
                </p>
              </div>
            </div>
            <div className="mt-5 flex gap-3">
              <button
                type="button"
                onClick={() => setConfirming(false)}
                className="flex-1 rounded-2xl bg-neutral-100 py-3 text-[13px] font-extrabold text-neutral-700 transition-colors hover:bg-neutral-200"
              >
                Keep working
              </button>
              <button
                type="button"
                onClick={() => (dbMode ? void confirmDbSubmit() : submit())}
                className="flex-1 rounded-2xl bg-neutral-950 py-3 text-[13px] font-extrabold text-white transition-all hover:bg-neutral-800 active:scale-[0.98]"
              >
                Submit now
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ---------- away-from-exam overlay (above every modal, unfocusable) ---------- */}
      {dbMode && away && (
        <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-neutral-950/95 px-8 text-center backdrop-blur-sm">
          <span className="animate-rise flex h-16 w-16 items-center justify-center rounded-full bg-rose-500/15 ring-8 ring-rose-500/10">
            <AlertTriangle className="h-8 w-8 text-rose-400" strokeWidth={2.2} />
          </span>
          {awayKind === "shrunk" ? (
            <>
              <h2 className="animate-rise mt-6 text-[26px] font-extrabold tracking-tight text-white" style={{ animationDelay: "60ms" }}>
                Split screen is not allowed
              </h2>
              <p className="animate-rise mt-3 max-w-[36ch] text-[14px] font-semibold leading-relaxed text-neutral-300" style={{ animationDelay: "120ms" }}>
                Close the other window and return to full screen. This was recorded and the invigilator can see it.
              </p>
            </>
          ) : (
            <>
              <h2 className="animate-rise mt-6 text-[26px] font-extrabold tracking-tight text-white" style={{ animationDelay: "60ms" }}>
                Return to the exam
              </h2>
              <p className="animate-rise mt-3 max-w-[36ch] text-[14px] font-semibold leading-relaxed text-neutral-300" style={{ animationDelay: "120ms" }}>
                Another window or app took focus. Close it and tap the exam. This was recorded and the invigilator can see it.
              </p>
            </>
          )}
        </div>
      )}

      {/* ── DEBUG-STRIP USAGE START — delete with the block + AUX lines above ── */}
      {debugOn && dbMode && (
        <DebugStrip
          away={away}
          awayKind={awayKind}
          awaySentRef={awaySent}
          reconcileTimerRef={reconcileTimer}
          lastPingRef={lastAwayPingRef}
        />
      )}
      {/* ── DEBUG-STRIP USAGE END ── */}
    </div>
  );
}
