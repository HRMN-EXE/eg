import { useCallback, useEffect, useMemo, useState } from "react";
import {
  AlertTriangle,
  ArrowLeft,
  Check,
  CheckCircle2,
  Eye,
  EyeOff,
  Hourglass,
  Loader2,
  Lock,
  RefreshCw,
  Search,
  Send,
  User as UserIcon,
  Users,
  XCircle,
} from "lucide-react";
import {
  fetchExamIsOver,
  fetchExamReleaseState,
  fetchFacultyResults,
  publishResults,
  type FacultyResultRow,
} from "../lib/facultyApi";
import type { FacultyResultsTarget } from "./FacultyDashboard";

interface FacultyResultsProps {
  exam: FacultyResultsTarget;
  onBack: () => void;
}

type Phase = "checking" | "locked" | "ready" | "error";

const initialsOf = (name: string | null | undefined) =>
  (name ?? "?").split(/\s+/).filter(Boolean).slice(0, 2).map((p) => p[0]?.toUpperCase()).join("") || "?";

const TINTS = ["bg-pink-200 text-pink-700", "bg-violet-200 text-violet-700", "bg-amber-200 text-amber-700", "bg-emerald-200 text-emerald-700"];
const tintFor = (id: string) => TINTS[[...id].reduce((s, c) => s + c.charCodeAt(0), 0) % TINTS.length];

const fmtReleased = (iso: string) =>
  new Date(iso).toLocaleString("en-GB", {
    day: "numeric",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  });

export default function FacultyResults({ exam, onBack }: FacultyResultsProps) {
  const [phase, setPhase] = useState<Phase>("checking");
  const [rows, setRows] = useState<FacultyResultRow[]>([]);
  const [query, setQuery] = useState("");

  /* ---------- release state ---------- */
  const [release, setRelease] = useState<{ published: boolean; releasedAt: string | null } | null>(null);
  const [releaseStatusError, setReleaseStatusError] = useState(false);
  const [releaseOpen, setReleaseOpen] = useState(false);
  const [releasePass, setReleasePass] = useState("");
  const [releaseShow, setReleaseShow] = useState(false);
  const [releaseBusy, setReleaseBusy] = useState(false);
  const [releaseError, setReleaseError] = useState<string | null>(null);
  const [toast, setToast] = useState<string | null>(null);

  const checkRelease = useCallback(async () => {
    setReleaseStatusError(false);
    const rel = await fetchExamReleaseState(exam.id);
    if (rel.error) {
      setReleaseStatusError(true);
      return;
    }
    setRelease({
      published: Boolean(rel.data?.results_published),
      releasedAt: rel.data?.results_released_at ?? null,
    });
  }, [exam.id]);

  const load = useCallback(async () => {
    setPhase("checking");
    const over = await fetchExamIsOver(exam.id);
    if (over.error) {
      setPhase("error");
      return;
    }
    if (!over.data) {
      // Results stay hidden until every attempt is finalized.
      setPhase("locked");
      return;
    }
    const [res] = await Promise.all([fetchFacultyResults(exam.id), checkRelease()]);
    if (res.error) {
      setPhase("error");
      return;
    }
    setRows(res.data);
    setPhase("ready");
  }, [exam.id, checkRelease]);

  useEffect(() => {
    void load();
  }, [load]);

  const doPublish = async () => {
    if (releaseBusy || !releasePass) return;
    setReleaseBusy(true);
    setReleaseError(null);
    const { data, error } = await publishResults(exam.id, releasePass);
    // Never retain the passphrase after the request completes.
    setReleasePass("");
    setReleaseBusy(false);
    if (error) {
      setReleaseError(error.message);
      return;
    }
    if (!data?.ok) {
      setReleaseError(
        data?.reason === "too_many_attempts"
          ? "Too many wrong attempts. Try again in 15 minutes."
          : "Wrong passphrase.",
      );
      return;
    }
    setRelease({ published: true, releasedAt: data.released_at ?? new Date().toISOString() });
    setReleaseOpen(false);
    setToast("Results released to students");
    window.setTimeout(() => setToast(null), 3200);
  };

  const counts = useMemo(() => {
    const c = { attempts: rows.length, passed: 0, failed: 0 };
    rows.forEach((r) => (r.passed ? (c.passed += 1) : (c.failed += 1)));
    return c;
  }, [rows]);

  const shown = useMemo(() => {
    const q = query.trim().toLowerCase();
    return [...rows]
      .sort((a, b) => (a.profiles?.roll_no ?? "").localeCompare(b.profiles?.roll_no ?? ""))
      .filter((r) => {
        if (!q) return true;
        return (
          (r.profiles?.full_name ?? "").toLowerCase().includes(q) ||
          (r.profiles?.roll_no ?? "").toLowerCase().includes(q)
        );
      });
  }, [rows, query]);

  return (
    <div className="relative z-10 mx-auto flex min-h-dvh w-full max-w-[560px] flex-col px-5 pb-12 pt-6 sm:px-6">
      {/* ---------- header ---------- */}
      <header className="animate-rise relative z-30 flex items-center gap-3">
        <button
          type="button"
          onClick={onBack}
          aria-label="Back to exams"
          className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full text-neutral-800 transition-all hover:-translate-x-0.5 hover:bg-white/70 hover:text-rose-500 active:scale-95"
        >
          <ArrowLeft className="h-5 w-5" strokeWidth={2.6} />
        </button>
        <div className="min-w-0 flex-1">
          <h1 className="truncate text-[19px] font-extrabold tracking-tight text-neutral-900">Results</h1>
          <p className="truncate font-mono text-[10px] font-extrabold tracking-[0.14em] text-neutral-400">{exam.course_code}</p>
        </div>
        <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-violet-600 text-white shadow-[0_8px_18px_-6px_rgba(124,58,237,0.6)]">
          <UserIcon className="h-[17px] w-[17px]" strokeWidth={2.3} />
        </span>
      </header>

      {/* ---------- exam title ---------- */}
      <h2 className="animate-rise mt-5 text-[22px] font-extrabold leading-snug tracking-tight text-neutral-950" style={{ animationDelay: "60ms" }}>
        {exam.title}
      </h2>

      {phase === "checking" && (
        <div className="mt-5 flex flex-col gap-3">
          {[0, 1, 2].map((n) => (
            <div key={n} className="animate-pulse rounded-[22px] bg-white/70 p-5">
              <div className="flex items-center gap-3">
                <span className="h-10 w-10 rounded-full bg-neutral-200" />
                <div className="flex-1">
                  <span className="block h-4 w-2/3 rounded bg-neutral-200" />
                  <span className="mt-2 block h-3 w-1/3 rounded bg-neutral-100" />
                </div>
                <span className="h-6 w-16 rounded-full bg-neutral-100" />
              </div>
            </div>
          ))}
        </div>
      )}

      {phase === "locked" && (
        <section className="animate-rise mt-6 flex flex-1 flex-col items-center justify-center rounded-[26px] bg-white px-7 py-14 text-center shadow-[0_20px_44px_-22px_rgba(190,80,115,0.45)]">
          <span className="relative flex h-16 w-16 items-center justify-center rounded-full bg-[#f3ede7]">
            <span className="absolute inset-0 animate-ping rounded-full bg-amber-200/50 [animation-duration:2.4s]" />
            <Hourglass className="relative h-7 w-7 text-amber-600" strokeWidth={2.1} />
          </span>
          <h3 className="mt-6 text-[18px] font-extrabold tracking-tight text-neutral-950">Results are not available yet</h3>
          <p className="mt-3 max-w-[38ch] text-[13px] font-semibold leading-relaxed text-neutral-600">
            Results are visible only after the exam is over and every attempt is finalized. If some attempts are still in
            progress, ask the invigilator to finalize them.
          </p>
          <button
            type="button"
            onClick={() => void load()}
            className="mt-6 flex h-11 items-center gap-2 rounded-full bg-neutral-950 px-5 text-[12.5px] font-extrabold text-white transition-all hover:-translate-y-0.5 hover:bg-neutral-800 active:scale-[0.98]"
          >
            <RefreshCw className="h-4 w-4" strokeWidth={2.4} />
            Refresh
          </button>
        </section>
      )}

      {phase === "error" && (
        <section className="animate-rise mt-6 flex flex-col items-center gap-4 rounded-[26px] bg-white p-10 text-center shadow-[0_20px_44px_-22px_rgba(190,80,115,0.45)]">
          <span className="flex h-12 w-12 items-center justify-center rounded-full bg-rose-100">
            <AlertTriangle className="h-6 w-6 text-rose-500" strokeWidth={2.2} />
          </span>
          <p className="text-[14px] font-extrabold text-neutral-900">Could not load results. Try again.</p>
          <button
            type="button"
            onClick={() => void load()}
            className="flex h-11 items-center gap-2 rounded-full bg-neutral-950 px-5 text-[12.5px] font-extrabold text-white transition-all hover:-translate-y-0.5 hover:bg-neutral-800 active:scale-[0.98]"
          >
            <RefreshCw className="h-4 w-4" strokeWidth={2.4} />
            Retry
          </button>
        </section>
      )}

      {phase === "ready" && (
        <>
          {/* ---------- release control ---------- */}
          <div className="animate-rise mt-5" style={{ animationDelay: "60ms" }}>
            {releaseStatusError ? (
              <div className="flex items-center justify-between gap-3 rounded-2xl bg-rose-50 px-4 py-3 ring-1 ring-rose-200">
                <p className="text-[12px] font-extrabold text-rose-600">Could not check release status</p>
                <button
                  type="button"
                  onClick={() => void checkRelease()}
                  className="flex h-10 shrink-0 items-center gap-1.5 rounded-full bg-neutral-950 px-4 text-[11px] font-extrabold text-white transition-all hover:-translate-y-0.5 hover:bg-neutral-800 active:scale-95"
                >
                  <RefreshCw className="h-3.5 w-3.5" strokeWidth={2.5} />
                  Retry
                </button>
              </div>
            ) : release?.published ? (
              <span className="inline-flex items-center gap-2 rounded-full bg-emerald-50 px-4 py-2.5 text-[12px] font-extrabold text-emerald-700 ring-1 ring-emerald-200">
                <CheckCircle2 className="h-4 w-4" strokeWidth={2.4} />
                {release.releasedAt ? `Released to students on ${fmtReleased(release.releasedAt)}` : "Released to students"}
              </span>
            ) : (
              <button
                type="button"
                onClick={() => {
                  setReleasePass("");
                  setReleaseError(null);
                  setReleaseOpen(true);
                }}
                className="group flex h-12 w-full items-center justify-center gap-2.5 rounded-full bg-fuchsia-800 text-[13px] font-extrabold text-white shadow-[0_16px_32px_-14px_rgba(134,25,143,0.7)] transition-all hover:-translate-y-0.5 hover:bg-fuchsia-700 active:scale-[0.99]"
              >
                <Send className="h-4 w-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" strokeWidth={2.4} />
                Release results to students
              </button>
            )}
          </div>

          {/* counts */}
          <div className="animate-rise mt-4 grid grid-cols-3 gap-2.5" style={{ animationDelay: "100ms" }}>
            <div className="rounded-[20px] bg-white p-4 text-center shadow-[0_14px_32px_-18px_rgba(190,80,115,0.45)]">
              <Users className="mx-auto h-4 w-4 text-neutral-400" strokeWidth={2.3} />
              <p className="mt-1.5 text-[22px] font-extrabold leading-none text-neutral-900">{counts.attempts}</p>
              <p className="mt-1 text-[9.5px] font-extrabold tracking-[0.12em] text-neutral-400">ATTEMPTS</p>
            </div>
            <div className="rounded-[20px] bg-white p-4 text-center shadow-[0_14px_32px_-18px_rgba(190,80,115,0.45)]">
              <CheckCircle2 className="mx-auto h-4 w-4 text-emerald-500" strokeWidth={2.3} />
              <p className="mt-1.5 text-[22px] font-extrabold leading-none text-emerald-600">{counts.passed}</p>
              <p className="mt-1 text-[9.5px] font-extrabold tracking-[0.12em] text-neutral-400">PASSED</p>
            </div>
            <div className="rounded-[20px] bg-white p-4 text-center shadow-[0_14px_32px_-18px_rgba(190,80,115,0.45)]">
              <XCircle className="mx-auto h-4 w-4 text-rose-500" strokeWidth={2.3} />
              <p className="mt-1.5 text-[22px] font-extrabold leading-none text-rose-600">{counts.failed}</p>
              <p className="mt-1 text-[9.5px] font-extrabold tracking-[0.12em] text-neutral-400">FAILED</p>
            </div>
          </div>

          {/* search */}
          <label className="animate-rise relative mt-4 block" style={{ animationDelay: "140ms" }}>
            <Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-neutral-400" strokeWidth={2.2} />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search name or roll number…"
              className="h-11 w-full rounded-full bg-white pl-11 pr-4 text-[12.5px] font-bold text-neutral-800 shadow-[0_10px_26px_-14px_rgba(190,80,115,0.4)] outline-none transition-all placeholder:font-medium placeholder:text-neutral-400 focus:ring-4 focus:ring-fuchsia-100"
            />
          </label>

          {/* list */}
          <div className="mt-4 flex flex-col gap-2.5">
            {shown.length === 0 && (
              <p className="animate-rise rounded-[22px] bg-white/70 p-8 text-center text-[12.5px] font-semibold text-neutral-500">
                {rows.length === 0 ? "No results yet." : "No students match this search."}
              </p>
            )}
            {shown.map((r, i) => (
              <div
                key={r.attempt_id}
                className="animate-rise flex items-center gap-3 rounded-[20px] bg-white p-4 shadow-[0_14px_32px_-18px_rgba(190,80,115,0.45)] transition-all duration-200 hover:-translate-y-0.5"
                style={{ animationDelay: `${160 + i * 40}ms` }}
              >
                <span className={"flex h-10 w-10 shrink-0 items-center justify-center rounded-full text-[12px] font-extrabold " + tintFor(r.student_id)}>
                  {initialsOf(r.profiles?.full_name)}
                </span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[13.5px] font-extrabold text-neutral-900">{r.profiles?.full_name ?? "Student"}</p>
                  <p className="mt-0.5 truncate text-[11px] font-bold text-neutral-500">{r.profiles?.roll_no ?? "—"}</p>
                </div>
                <div className="shrink-0 text-right">
                  <p className="text-[15px] font-extrabold leading-none text-neutral-900">
                    {r.score_marks ?? 0}
                    <span className="text-[10.5px] font-bold text-neutral-400"> / {r.total_marks ?? "—"}</span>
                  </p>
                  <span
                    className={
                      "mt-1 inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-[9.5px] font-extrabold " +
                      (r.passed ? "bg-emerald-50 text-emerald-600" : "bg-rose-50 text-rose-600")
                    }
                  >
                    {r.passed ? "Passed" : "Failed"}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </>
      )}

      {/* ---------- release dialog ---------- */}
      {releaseOpen && (
        <div
          className="fixed inset-0 z-40 flex items-end justify-center bg-neutral-950/45 p-5 backdrop-blur-sm sm:items-center"
          onClick={() => {
            if (releaseBusy) return;
            setReleaseOpen(false);
            setReleasePass(""); // never keep the passphrase around
          }}
        >
          <div
            className="animate-pop w-full max-w-[400px] rounded-[24px] bg-white p-6 shadow-[0_30px_70px_-20px_rgba(0,0,0,0.55)]"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-3">
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-fuchsia-100">
                <Send className="h-5 w-5 text-fuchsia-700" strokeWidth={2.2} />
              </span>
              <h3 className="text-[16px] font-extrabold text-neutral-900">Release results to students</h3>
            </div>
            <p className="mt-3 text-[12.5px] font-medium leading-relaxed text-neutral-600">
              Students will see their marks immediately. This cannot be undone from the app.
            </p>

            <label className="relative mt-4 block">
              <span className="text-[11px] font-extrabold tracking-[0.12em] text-neutral-500">
                EXAM PASSPHRASE (THE ONE YOU SET WHEN LOCKING)
              </span>
              <input
                type={releaseShow ? "text" : "password"}
                value={releasePass}
                autoFocus
                onChange={(e) => {
                  setReleasePass(e.target.value);
                  setReleaseError(null);
                }}
                placeholder="Passphrase"
                className="mt-2 h-12 w-full rounded-2xl border border-transparent bg-[#f3ede7] pl-11 pr-12 text-[13.5px] font-bold text-neutral-900 outline-none transition-all placeholder:font-medium placeholder:text-neutral-400 focus:border-rose-300 focus:bg-white focus:ring-4 focus:ring-rose-100"
              />
              <Lock className="pointer-events-none absolute bottom-3.5 left-4 h-4 w-4 text-neutral-400" strokeWidth={2.2} />
              <button
                type="button"
                aria-label={releaseShow ? "Hide passphrase" : "Show passphrase"}
                onClick={() => setReleaseShow((s) => !s)}
                className="absolute bottom-2 right-3 flex h-8 w-8 items-center justify-center rounded-full text-neutral-500 transition-colors hover:bg-neutral-200/60"
              >
                {releaseShow ? <EyeOff className="h-4 w-4" strokeWidth={2.1} /> : <Eye className="h-4 w-4" strokeWidth={2.1} />}
              </button>
            </label>

            {releaseError && (
              <p className="animate-rise mt-3 rounded-xl bg-rose-50 px-3.5 py-2.5 text-[12px] font-bold text-rose-600 ring-1 ring-rose-200">
                {releaseError}
              </p>
            )}

            <div className="mt-5 flex gap-3">
              <button
                type="button"
                onClick={() => {
                  setReleaseOpen(false);
                  setReleasePass("");
                }}
                disabled={releaseBusy}
                className="flex-1 rounded-2xl bg-neutral-100 py-3 text-[13px] font-extrabold text-neutral-700 transition-colors hover:bg-neutral-200 disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => void doPublish()}
                disabled={releaseBusy || !releasePass}
                className="flex flex-1 items-center justify-center gap-2 rounded-2xl bg-fuchsia-800 py-3 text-[13px] font-extrabold text-white transition-all hover:bg-fuchsia-700 active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-50"
              >
                {releaseBusy ? <Loader2 className="h-4 w-4 animate-spin" strokeWidth={2.4} /> : <Check className="h-4 w-4" strokeWidth={2.6} />}
                Release
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ---------- local success toast ---------- */}
      {toast && (
        <div
          role="status"
          className="animate-toast fixed bottom-8 left-1/2 z-50 flex max-w-[88%] items-center gap-2 rounded-full bg-neutral-950/95 px-4 py-2.5 shadow-[0_18px_40px_-10px_rgba(0,0,0,0.5)] backdrop-blur"
        >
          <span className="flex h-4 w-4 shrink-0 items-center justify-center rounded-full bg-emerald-500">
            <Check className="h-2.5 w-2.5 text-white" strokeWidth={3} />
          </span>
          <span className="text-[12.5px] font-semibold text-white">{toast}</span>
        </div>
      )}
    </div>
  );
}
