import { useCallback, useEffect, useState } from "react";
import {
  AlertTriangle,
  ArrowRight,
  Bell,
  BookOpen,
  CalendarDays,
  Check,
  CheckCircle2,
  Clock,
  Database,
  FileText,
  GitBranch,
  GraduationCap,
  Lock,
  LogOut,
  RefreshCw,
  ShieldCheck,
  Sigma,
  Star,
  Timer,
  User as UserIcon,
  XCircle,
} from "lucide-react";
import { SOON_WINDOW_MIN, passPctOf, type Exam } from "../data/exams";
import {
  fetchExamsForStudent,
  fetchMyAttempts,
  fetchMyResults,
  mergeForStudent,
  type StudentExam,
} from "../lib/examApi";
import type { Profile } from "./CandidateProfile";

type Notify = (kind: "success" | "info" | "error", msg: string) => void;

interface ExamListProps {
  profile: Profile | null;
  onNotify: Notify;
  onSignOut: () => void;
  onStartExam: (exam: Exam) => void;
}

type Filter = "all" | "available" | "completed";

/** Runtime state of an exam card, derived from its schedule and results. */
type CardState = "live" | "soon" | "missed" | "completed";

const CODE_ICON = { amber: GitBranch, violet: Database, neutral: Sigma } as const;

const cap = (s: string) => s.charAt(0).toUpperCase() + s.slice(1);

/** H:MM:SS when an hour or more remains, MM:SS otherwise. */
const fmtCountdown = (ms: number) => {
  const s = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  const mm = String(m).padStart(2, "0");
  const ss = String(sec).padStart(2, "0");
  return h > 0 ? `${h}:${mm}:${ss}` : `${mm}:${ss}`;
};

const fmtClockTime = (t: number) =>
  new Date(t).toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit", hour12: true });

const yearLabel = (y?: string) => {
  const m = y?.match(/(\d+)/);
  return m ? `Year ${m[1]}` : "Year —";
};

const majorInitials = (degree?: string) =>
  (degree ?? "")
    .replace(/^[A-Za-z]+\.\s*/, "")
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0]?.toUpperCase())
    .join("") || "—";

export default function ExamList({ profile, onNotify, onSignOut, onStartExam }: ExamListProps) {
  const [filter, setFilter] = useState<Filter>("all");
  const [menuOpen, setMenuOpen] = useState(false);
  const [exams, setExams] = useState<StudentExam[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState(false);

  // One-second heartbeat drives every countdown and auto-flips states
  // (Coming Soon → Available → Missed) without a reload.
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const t = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(t);
  }, []);

  const load = useCallback(async () => {
    setLoading(true);
    setLoadError(false);
    const [examsRes, attemptsRes, resultsRes] = await Promise.all([
      fetchExamsForStudent(),
      fetchMyAttempts(),
      fetchMyResults(),
    ]);
    if (examsRes.error || attemptsRes.error || resultsRes.error) {
      setLoadError(true);
      setExams([]);
    } else {
      setExams(mergeForStudent(examsRes.data, attemptsRes.data, resultsRes.data));
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const live = exams;

  const stateOf = (e: StudentExam): CardState => {
    if (e.status === "completed") return "completed";
    const endsAt = e.endsAt ?? e.startsAt + e.durationMin * 60_000;
    if (now > endsAt) return "missed";
    if (now >= e.startsAt) return "live";
    return "soon";
  };

  const withState = live.map((e) => ({ exam: e, state: stateOf(e) }));
  const actionable = withState.filter((x) => x.state === "live" || x.state === "soon");
  const available = actionable;
  const completed = withState.filter((x) => x.state === "completed");
  const shown =
    filter === "all" ? withState : filter === "available" ? actionable : completed;

  const rawName = profile?.fullName.split(" ")[0] ?? "Student";
  const firstName = cap(rawName);
  const shortName = profile?.fullName ?? firstName;

  const accentPill = {
    amber: "bg-amber-300 text-neutral-900",
    violet: "bg-violet-200 text-violet-800",
    neutral: "bg-neutral-200 text-neutral-600",
  } as const;

  const tabs: { key: Filter; label: string; count: number }[] = [
    { key: "all", label: "All", count: withState.length },
    { key: "available", label: "Available", count: available.length },
    { key: "completed", label: "Completed", count: completed.length },
  ];

  return (
    <div className="relative z-10 mx-auto w-full max-w-[560px] px-5 pb-12 pt-6 sm:px-6">
      {/* relative z-30 keeps the account popover above the animated cards below */}
      <header className="animate-rise relative z-30 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <span className="flex h-9 w-9 items-center justify-center rounded-full bg-rose-100">
            <GraduationCap className="h-[18px] w-[18px] text-rose-500" strokeWidth={2.2} />
          </span>
          <h1 className="text-[19px] font-extrabold tracking-tight text-neutral-900">Exam List</h1>
        </div>

        <div className="relative flex items-center gap-2.5">
          <button
            type="button"
            aria-label="Notifications"
            onClick={() => onNotify("info", "You're all caught up — no new notifications")}
            className="flex h-9 w-9 items-center justify-center rounded-full text-neutral-600 transition-all hover:bg-white/70 hover:text-rose-500 active:scale-90"
          >
            <Bell className="h-[19px] w-[19px]" strokeWidth={2.1} />
          </button>
          <button
            type="button"
            aria-label="Account"
            onClick={() => setMenuOpen((o) => !o)}
            className="flex h-9 w-9 items-center justify-center rounded-full bg-violet-600 text-white shadow-[0_8px_18px_-6px_rgba(124,58,237,0.6)] transition-all hover:bg-violet-500 active:scale-90"
          >
            <UserIcon className="h-[17px] w-[17px]" strokeWidth={2.3} />
          </button>

          {menuOpen && (
            <>
              <div className="fixed inset-0 z-20" onClick={() => setMenuOpen(false)} />
              <div className="animate-pop absolute right-0 top-11 z-30 w-56 overflow-hidden rounded-2xl bg-white shadow-[0_24px_50px_-16px_rgba(0,0,0,0.35)] ring-1 ring-neutral-100">
                <div className="flex items-start justify-between gap-3 border-b border-neutral-100 px-4 py-3">
                  <div className="min-w-0">
                    <p className="truncate text-[12.5px] font-extrabold text-neutral-800">{shortName}</p>
                    <p className="truncate text-[11px] font-medium text-neutral-500">Roll {profile?.rollNo ?? "—"}</p>
                  </div>
                  <div className="shrink-0 text-right">
                    <p className="text-[11px] font-extrabold text-neutral-700">{yearLabel(profile?.year)} {majorInitials(profile?.degree)}</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setMenuOpen(false);
                    onSignOut();
                  }}
                  className="flex w-full items-center gap-2 px-4 py-3 text-[12.5px] font-bold text-rose-500 transition-colors hover:bg-rose-50"
                >
                  <LogOut className="h-4 w-4 -scale-x-100" strokeWidth={2.3} />
                  Sign out
                </button>
              </div>
            </>
          )}
        </div>
      </header>

      {/* ---------- greeting ---------- */}
      <section className="animate-rise mt-6" style={{ animationDelay: "60ms" }}>
        <div className="flex items-start justify-between">
          <div>
            <h2 className="font-serif text-[34px] font-bold leading-none tracking-tight text-neutral-950">
              Hi {firstName}
            </h2>
            <p className="mt-2.5 flex items-center gap-2 text-[12.5px] font-semibold text-neutral-600">
              <span className="h-2 w-2 rounded-full bg-amber-400" />
              Enrolled Exams · Spring Semester
            </p>
          </div>
          {/* hidden while the account popover is open so the two never collide */}
          {!menuOpen && (
            <div className="text-right">
              {shortName.toLowerCase() !== firstName.toLowerCase() && (
                <p className="text-[12px] font-extrabold text-neutral-800">{shortName}</p>
              )}
              <p
                className={
                  "text-[10.5px] font-bold text-neutral-500 " +
                  (shortName.toLowerCase() !== firstName.toLowerCase() ? "mt-0.5" : "")
                }
              >
                {yearLabel(profile?.year)} {majorInitials(profile?.degree)}
              </p>
            </div>
          )}
        </div>
      </section>

      {/* ---------- filter tabs ---------- */}
      <div className="animate-rise mt-6 flex flex-wrap gap-2.5" style={{ animationDelay: "120ms" }}>
        {tabs.map((t) => {
          const active = filter === t.key;
          return (
            <button
              key={t.key}
              type="button"
              onClick={() => setFilter(t.key)}
              className={
                "flex items-center gap-2 rounded-full px-4 py-2 text-[12px] font-extrabold transition-all duration-200 active:scale-95 " +
                (active
                  ? "bg-neutral-900 text-white shadow-[0_10px_22px_-10px_rgba(0,0,0,0.6)]"
                  : "bg-white/80 text-neutral-600 shadow-[0_6px_16px_-8px_rgba(190,80,115,0.3)] hover:bg-white")
              }
            >
              {t.label}
              <span
                className={
                  "flex h-5 min-w-5 items-center justify-center rounded-full px-1 text-[10.5px] font-extrabold " +
                  (active
                    ? "bg-white/20 text-white"
                    : t.key === "available"
                      ? "bg-amber-300 text-neutral-900"
                      : "bg-neutral-200 text-neutral-600")
                }
              >
                {t.count}
              </span>
            </button>
          );
        })}
      </div>

      {/* ---------- exam cards ---------- */}
      <div className="mt-5 flex flex-col gap-5">
        {loading &&
          [0, 1, 2].map((n) => (
            <div key={n} className="animate-pulse rounded-[26px] bg-white/70 p-6" style={{ animationDelay: `${n * 120}ms` }}>
              <div className="flex justify-between">
                <span className="h-6 w-28 rounded-full bg-neutral-200" />
                <span className="h-6 w-20 rounded-full bg-neutral-100" />
              </div>
              <span className="mt-4 block h-6 w-3/4 rounded-lg bg-neutral-200" />
              <span className="mt-2 block h-4 w-1/2 rounded-lg bg-neutral-100" />
              <div className="mt-4 flex gap-2">
                <span className="h-7 w-24 rounded-full bg-neutral-100" />
                <span className="h-7 w-24 rounded-full bg-neutral-100" />
              </div>
              <span className="mt-5 block h-12 w-full rounded-[18px] bg-neutral-200" />
            </div>
          ))}

        {!loading && loadError && (
          <div className="animate-rise flex flex-col items-center gap-4 rounded-[26px] bg-white p-8 text-center shadow-[0_20px_44px_-22px_rgba(190,80,115,0.45)]">
            <span className="flex h-12 w-12 items-center justify-center rounded-full bg-rose-100">
              <AlertTriangle className="h-6 w-6 text-rose-500" strokeWidth={2.2} />
            </span>
            <div>
              <p className="text-[14px] font-extrabold text-neutral-900">Could not load exams. Try again.</p>
              <p className="mt-1 text-[12px] font-medium text-neutral-500">Check your connection, then retry.</p>
            </div>
            <button
              type="button"
              onClick={() => void load()}
              className="flex items-center gap-2 rounded-full bg-neutral-950 px-5 py-2.5 text-[12.5px] font-extrabold text-white transition-all hover:-translate-y-0.5 hover:bg-neutral-800 active:scale-[0.98]"
            >
              <RefreshCw className="h-4 w-4" strokeWidth={2.4} />
              Retry
            </button>
          </div>
        )}

        {!loading && !loadError && shown.length === 0 && (
          <p className="animate-rise rounded-3xl bg-white/70 p-8 text-center text-[13px] font-semibold text-neutral-500">
            {exams.length === 0
              ? "No examinations have been released for your cohort yet. Check back soon."
              : `No ${filter === "available" ? "upcoming or live" : "completed"} exams right now.`}
          </p>
        )}

        {!loading && !loadError && shown.map(({ exam: e, state }, i) => {
          const Icon = CODE_ICON[e.accent];
          const qCount = e.questions.length || e.questionCount || 0;
          const lockedCard = state === "completed" || state === "missed";
          const endsAt = e.endsAt ?? e.startsAt + e.durationMin * 60_000;
          // DB exams don't expose marks or question counts before an attempt.
          const marksKnown = state === "completed" || e.source !== "db";
          const startsIn = e.startsAt - now;
          const closesIn = endsAt - now;
          const urgent = state === "soon" && startsIn <= SOON_WINDOW_MIN * 60_000;

          return (
            <article
              key={e.id}
              className={
                "animate-rise rounded-[26px] bg-white p-6 shadow-[0_20px_44px_-22px_rgba(190,80,115,0.45)] transition-all duration-300 " +
                (lockedCard
                  ? "opacity-90"
                  : state === "soon"
                    ? "hover:-translate-y-0.5"
                    : "hover:-translate-y-1 hover:shadow-[0_28px_54px_-22px_rgba(190,80,115,0.55)]")
              }
              style={{ animationDelay: `${160 + i * 70}ms` }}
            >
              {/* code + status pills */}
              <div className="flex items-center justify-between gap-3">
                <span className={"flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[10.5px] font-extrabold tracking-wide " + accentPill[e.accent]}>
                  <Icon className="h-3 w-3" strokeWidth={2.6} />
                  {e.code}
                </span>

                {state === "completed" && (
                  <span className="flex items-center gap-1 rounded-full bg-amber-300 px-3 py-1.5 text-[10.5px] font-extrabold text-neutral-900">
                    <Check className="h-3 w-3" strokeWidth={3.2} />
                    {e.pending ? "Submitted" : "Completed"}
                  </span>
                )}
                {state === "live" && (
                  <span className="flex items-center gap-1.5 rounded-full bg-pink-100 px-3 py-1.5 text-[10.5px] font-extrabold text-pink-600">
                    <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-pink-500" />
                    Live now
                  </span>
                )}
                {state === "soon" && (
                  <span
                    className={
                      "flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[10.5px] font-extrabold " +
                      (urgent ? "animate-pulse bg-amber-300 text-neutral-900" : "bg-neutral-200 text-neutral-600")
                    }
                  >
                    <Clock className="h-3 w-3" strokeWidth={2.6} />
                    {urgent ? "Starts soon" : "Scheduled"}
                  </span>
                )}
                {state === "missed" && (
                  <span className="flex items-center gap-1.5 rounded-full bg-rose-100 px-3 py-1.5 text-[10.5px] font-extrabold text-rose-600">
                    <XCircle className="h-3 w-3" strokeWidth={2.6} />
                    Missed
                  </span>
                )}
              </div>

              <h3 className="mt-3.5 font-serif text-[22px] font-bold leading-snug tracking-tight text-neutral-950">
                {e.title}
              </h3>

              {/* status-specific subline */}
              {state === "completed" && e.submittedLabel ? (
                <p className="mt-2 flex items-center gap-1.5 text-[11.5px] font-semibold text-neutral-500">
                  <CalendarDays className="h-3.5 w-3.5" strokeWidth={2.2} />
                  {e.submittedLabel}
                </p>
              ) : state === "soon" ? (
                <p className="mt-2 flex items-center gap-1.5 text-[11.5px] font-semibold text-neutral-500">
                  <CalendarDays className="h-3.5 w-3.5" strokeWidth={2.2} />
                  Scheduled today at {fmtClockTime(e.startsAt)}
                </p>
              ) : state === "missed" ? (
                <p className="mt-2 flex items-center gap-1.5 text-[11.5px] font-semibold text-rose-500">
                  <XCircle className="h-3.5 w-3.5" strokeWidth={2.2} />
                  Window closed at {fmtClockTime(endsAt)} — not attempted
                </p>
              ) : (
                <div className="mt-2.5 flex items-center gap-2.5">
                  <span className="flex items-center gap-1.5 rounded-full bg-neutral-100 px-3 py-1.5 text-[11px] font-extrabold text-neutral-700">
                    <CheckCircle2 className="h-3.5 w-3.5 text-rose-500" strokeWidth={2.2} />
                    Passing: {passPctOf(e)}%
                  </span>
                  {e.credit && (
                    <span className="text-[10.5px] font-extrabold tracking-wide text-neutral-400">{e.credit.toUpperCase()}</span>
                  )}
                </div>
              )}

              {e.blurb && (
                <p className="mt-3 font-serif text-[14px] leading-relaxed text-neutral-600">{e.blurb}</p>
              )}

              {/* meta chips */}
              <div className="mt-4 flex flex-wrap gap-2">
                {e.durationMin > 0 && (
                  <span className="flex items-center gap-1.5 rounded-full bg-neutral-100/90 px-3 py-1.5 text-[11px] font-extrabold text-neutral-700">
                    <Timer className="h-3.5 w-3.5 text-rose-500" strokeWidth={2.2} />
                    {e.durationMin} Mins
                  </span>
                )}
                {qCount > 0 && (
                  <span className="flex items-center gap-1.5 rounded-full bg-neutral-100/90 px-3 py-1.5 text-[11px] font-extrabold text-neutral-700">
                    {state === "completed" ? (
                      <FileText className="h-3.5 w-3.5 text-amber-500" strokeWidth={2.2} />
                    ) : (
                      <BookOpen className="h-3.5 w-3.5 text-amber-500" strokeWidth={2.2} />
                    )}
                    {qCount} Questions
                  </span>
                )}
                {state === "completed" ? (
                  e.pending ? (
                    <span className="flex items-center gap-1.5 rounded-full bg-amber-50 px-3 py-1.5 text-[11px] font-extrabold text-amber-600">
                      <Clock className="h-3.5 w-3.5" strokeWidth={2.2} />
                      Result pending faculty review
                    </span>
                  ) : (
                    <span
                      className={
                        "flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[11px] font-extrabold " +
                        (e.passed === false
                          ? "bg-rose-50 text-rose-600"
                          : "bg-emerald-50 text-emerald-600")
                      }
                    >
                      <CheckCircle2 className="h-3.5 w-3.5" strokeWidth={2.2} />
                      Score: {e.score} / {e.marks} · {e.passed === false ? "Failed" : "Passed"}
                    </span>
                  )
                ) : state === "live" ? (
                  <span className="flex items-center gap-1.5 rounded-full bg-emerald-50 px-3 py-1.5 text-[11px] font-extrabold text-emerald-600">
                    <Timer className="h-3.5 w-3.5" strokeWidth={2.2} />
                    Closes in {fmtCountdown(closesIn)}
                  </span>
                ) : state === "soon" ? (
                  <span
                    className={
                      "flex items-center gap-1.5 rounded-full px-3 py-1.5 font-mono text-[11px] font-extrabold " +
                      (urgent ? "animate-pulse bg-amber-100 text-amber-700" : "bg-neutral-100/90 text-neutral-700")
                    }
                  >
                    <Clock className="h-3.5 w-3.5" strokeWidth={2.2} />
                    Starts in {fmtCountdown(startsIn)}
                  </span>
                ) : marksKnown ? (
                  <span className="flex items-center gap-1.5 rounded-full bg-neutral-100/90 px-3 py-1.5 text-[11px] font-extrabold text-neutral-700">
                    <Star className="h-3.5 w-3.5 text-violet-500" strokeWidth={2.2} />
                    {e.marks} Total Marks
                  </span>
                ) : null}
              </div>

              {/* action */}
              {state === "completed" && (
                <span className="mt-5 flex h-[52px] w-full cursor-not-allowed items-center justify-center gap-2 rounded-[18px] bg-neutral-200/70 text-[14px] font-extrabold text-neutral-500">
                  <Lock className="h-4 w-4" strokeWidth={2.4} />
                  Completed (Locked)
                </span>
              )}
              {state === "missed" && (
                <span className="mt-5 flex h-[52px] w-full cursor-not-allowed items-center justify-center gap-2 rounded-[18px] bg-neutral-200/70 text-[14px] font-extrabold text-neutral-500">
                  <XCircle className="h-4 w-4" strokeWidth={2.4} />
                  Missed — window closed
                </span>
              )}
              {state === "soon" && (
                <span className="mt-5 flex h-[52px] w-full cursor-not-allowed items-center justify-center gap-2 rounded-[18px] bg-neutral-200/70 font-mono text-[13px] font-extrabold text-neutral-500">
                  <Clock className="h-4 w-4" strokeWidth={2.4} />
                  Unlocks in {fmtCountdown(startsIn)}
                </span>
              )}
              {state === "live" && (
                <button
                  type="button"
                  onClick={() => onStartExam(e)}
                  className="group mt-5 flex h-[52px] w-full items-center justify-center gap-2.5 rounded-[18px] bg-neutral-950 text-[14px] font-extrabold text-white shadow-[0_16px_32px_-14px_rgba(0,0,0,0.6)] transition-all duration-200 hover:bg-neutral-800 hover:shadow-[0_20px_38px_-14px_rgba(0,0,0,0.65)] active:scale-[0.98]"
                >
                  Take Exam
                  <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" strokeWidth={2.6} />
                </button>
              )}
            </article>
          );
        })}
      </div>

      {/* ---------- enrollment footer ---------- */}
      <div className="animate-rise mt-7 flex items-start gap-3 rounded-[22px] bg-rose-100/60 p-4 ring-1 ring-rose-200/70" style={{ animationDelay: "380ms" }}>
        <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-rose-200/80">
          <ShieldCheck className="h-[18px] w-[18px] text-rose-600" strokeWidth={2.2} />
        </span>
        <p className="font-serif text-[12px] font-semibold leading-relaxed text-neutral-700">
          Enrolled as <span className="font-extrabold text-neutral-900">{profile?.rollNo ?? "—"}</span> · Single attempt
          policy strictly enforced. Proctor logs will sync automatically upon commencement.
        </p>
      </div>
      <p className="animate-rise mt-3 flex items-center justify-center gap-1.5 text-[10.5px] font-bold text-neutral-500" style={{ animationDelay: "420ms" }}>
        <ShieldCheck className="h-3 w-3 text-emerald-600" strokeWidth={2.4} />
        Showing examinations released for your {profile?.year ?? "cohort"} by the Controller of Exams.
      </p>
    </div>
  );
}
