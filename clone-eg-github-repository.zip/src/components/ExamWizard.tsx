import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  AlertCircle,
  ArrowLeft,
  ArrowRight,
  Bookmark,
  CalendarDays,
  Check,
  ChevronDown,
  Copy,
  Clock,
  Eye,
  EyeOff,
  Hourglass,
  Loader2,
  Lock,
  Plus,
  RefreshCw,
  Save,
  Trash2,
  UserCheck,
  Users,
  X,
} from "lucide-react";
import { fetchCourses, type CourseOption } from "../lib/courseApi";
import {
  examProblems,
  fetchFacultyServerTime,
  getDraft,
  listInvigilators,
  lockExam,
  saveDraft,
  setInvigilators,
  type InvigilatorOption,
} from "../lib/facultyApi";

type Notify = (kind: "success" | "info" | "error", msg: string) => void;

interface ExamWizardProps {
  examId: string | null;
  onExit: () => void;
  onNotify: Notify;
}

interface WQ {
  key: string;
  prompt: string;
  options: string[];
  correct: number | null;
  marks: number;
}

const YEARS = [1, 2, 3, 4];
const NEG_FRACTIONS = [0.25, 0.33, 0.5, 1];
const LATE_OPTIONS = [0, 5, 10, 15, 30];
const DUR_CHIPS = [30, 45, 60, 90, 120];

const card = "rounded-[24px] bg-white p-5 shadow-[0_18px_40px_-22px_rgba(190,80,115,0.45)] sm:p-6";
const inputBase =
  "h-12 w-full rounded-2xl border border-transparent bg-[#f3ede7] px-4 text-[13.5px] font-bold text-neutral-900 outline-none transition-all placeholder:font-medium placeholder:text-neutral-400 focus:border-rose-300 focus:bg-white focus:ring-4 focus:ring-rose-100";
const label = "text-[11px] font-extrabold tracking-[0.12em] text-neutral-500";

const newKey = () => "q-" + Math.random().toString(36).slice(2, 9);
const blankQ = (): WQ => ({ key: newKey(), prompt: "", options: ["", ""], correct: null, marks: 1 });

const hhmm = (d: Date) => d.toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" });
const fmtOpens = (d: Date) =>
  d.toLocaleDateString("en-GB", { weekday: "long", day: "numeric", month: "short" }) + ", " + hhmm(d);

const pad2 = (n: number) => String(n).padStart(2, "0");

/** Map a server problem string to the step that fixes it. */
const stepForProblem = (p: string): 1 | 2 | 3 => {
  const s = p.toLowerCase();
  if (/question|option|answer|prompt/.test(s)) return 3;
  if (/date|start|duration|window|invigilator|late|schedule|opens|closes/.test(s)) return 2;
  return 1; // title, code, years, pass mark, negative marking…
};

export default function ExamWizard({ examId, onExit, onNotify }: ExamWizardProps) {
  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);

  /* ---- step 4: review & lock ---- */
  const [problems, setProblems] = useState<string[] | null>(null);
  const [problemsError, setProblemsError] = useState<string | null>(null);
  const [checkingProblems, setCheckingProblems] = useState(false);
  const [lockPass, setLockPass] = useState("");
  const [lockConfirm, setLockConfirm] = useState("");
  const [showLockPw, setShowLockPw] = useState(false);
  const [lockAck, setLockAck] = useState(false);
  const [locking, setLocking] = useState(false);
  const [lockError, setLockError] = useState<string | null>(null);
  const [lockedInfo, setLockedInfo] = useState<{ title: string; opens: string } | null>(null);

  /* ---- step 1: basics ---- */
  const [title, setTitle] = useState("");
  const [subjectCode, setSubjectCode] = useState("");
  const [courseCode, setCourseCode] = useState("");
  const [years, setYears] = useState<number[]>([]);
  const [passPct, setPassPct] = useState(40);
  const [negOn, setNegOn] = useState(false);
  const [negFraction, setNegFraction] = useState(0.25);

  /* ---- step 2: schedule ---- */
  const [dateStr, setDateStr] = useState("");
  const [timeStr, setTimeStr] = useState("");
  const [duration, setDuration] = useState(60);
  const [lateOptions, setLateOptions] = useState<number[]>(LATE_OPTIONS);
  const [lateMin, setLateMin] = useState(10);
  const [invigilators, setInvigilatorsList] = useState<InvigilatorOption[]>([]);
  const [invLoading, setInvLoading] = useState(true);
  const [invError, setInvError] = useState(false);
  const [selectedInv, setSelectedInv] = useState<string[]>([]);

  /* ---- step 3: questions ---- */
  const [questions, setQuestions] = useState<WQ[]>([blankQ()]);
  const [deleteQ, setDeleteQ] = useState<number | null>(null);

  /* ---- shared ---- */
  const [courses, setCourses] = useState<CourseOption[]>([]);
  const [coursesLoading, setCoursesLoading] = useState(true);
  const [coursesError, setCoursesError] = useState(false);
  const [serverId, setServerId] = useState<string | null>(examId);
  const [loadingDraft, setLoadingDraft] = useState(Boolean(examId));
  const [dirty, setDirty] = useState(false);
  const [saving, setSaving] = useState(false);
  const [savedAt, setSavedAt] = useState<Date | null>(null);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [offset, setOffset] = useState(0);
  const [confirmLeave, setConfirmLeave] = useState<"back" | "exit" | null>(null);
  const dirtyRef = useRef(false);
  dirtyRef.current = dirty;

  const touch = () => {
    setDirty(true);
    setSavedAt(null);
  };

  const selectedCourse = courses.find((c) => c.code === courseCode) ?? null;

  /* ---------- loads ---------- */
  const loadCourses = useCallback(async () => {
    setCoursesLoading(true);
    setCoursesError(false);
    const { data, error } = await fetchCourses();
    if (error) setCoursesError(true);
    else setCourses(data);
    setCoursesLoading(false);
  }, []);

  const loadInvigilators = useCallback(async () => {
    setInvLoading(true);
    setInvError(false);
    const { data, error } = await listInvigilators();
    if (error) setInvError(true);
    else setInvigilatorsList(data);
    setInvLoading(false);
  }, []);

  useEffect(() => {
    void loadCourses();
    void loadInvigilators();
    void fetchFacultyServerTime().then((r) => {
      if (r.data) setOffset(new Date(r.data).getTime() - Date.now());
    });
  }, [loadCourses, loadInvigilators]);

  /* ---------- load existing draft ---------- */
  useEffect(() => {
    if (!examId) return;
    let alive = true;
    void (async () => {
      const { data, error } = await getDraft(examId);
      if (!alive) return;
      setLoadingDraft(false);
      if (error) {
        onNotify("error", error.message);
        if (/locked/i.test(error.message)) onExit();
        return;
      }
      if (!data) return;
      const e = data.exam;
      setTitle(e.title ?? "");
      setSubjectCode(e.course_code ?? "");
      setPassPct(e.pass_pct ?? 40);
      if ((e.negative_fraction ?? 0) > 0) {
        setNegOn(true);
        setNegFraction(NEG_FRACTIONS.includes(e.negative_fraction) ? e.negative_fraction : 0.25);
      }
      setYears((data.cohorts ?? []).map((c) => c.year).filter((y, i, a) => a.indexOf(y) === i));
      setQuestions(
        (data.questions ?? []).map((q) => ({
          key: newKey(),
          prompt: q.prompt ?? "",
          options: q.options?.length >= 2 ? [...q.options] : ["", ""],
          correct: q.correct ?? null,
          marks: q.marks ?? 1,
        })),
      );
      setSelectedInv(data.invigilator_ids ?? []);
      if (e.starts_at) {
        const s = new Date(e.starts_at);
        setDateStr(`${s.getFullYear()}-${pad2(s.getMonth() + 1)}-${pad2(s.getDate())}`);
        setTimeStr(`${pad2(s.getHours())}:${pad2(s.getMinutes())}`);
        setDuration(e.duration_min ?? 60);
        if (e.ends_at) {
          const late = Math.round((new Date(e.ends_at).getTime() - s.getTime()) / 60000) - (e.duration_min ?? 0);
          if (late >= 0 && !LATE_OPTIONS.includes(late)) setLateOptions((o) => [...o, late].sort((a, b) => a - b));
          if (late >= 0) setLateMin(late);
        }
      }
    })();
    return () => {
      alive = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [examId]);

  // Resolve the course select from the loaded course_code when courses arrive.
  useEffect(() => {
    if (courseCode || !subjectCode || courses.length === 0) return;
    const match = courses.find((c) => c.code === subjectCode || c.name === subjectCode);
    if (match) setCourseCode(match.code);
  }, [courses, courseCode, subjectCode]);

  /* ---------- derived schedule ---------- */
  const startsAt = useMemo(() => (dateStr && timeStr ? new Date(`${dateStr}T${timeStr}`) : null), [dateStr, timeStr]);
  const serverNow = Date.now() + offset;
  const startTooSoon = Boolean(startsAt && startsAt.getTime() < serverNow + 10 * 60000);
  // Server rule: entry is open from start until start + late entry; every student
  // then gets the full duration. Window end = start + late entry + duration.
  const entryClosesAt = startsAt ? new Date(startsAt.getTime() + lateMin * 60000) : null;
  const endsAt = startsAt ? new Date(startsAt.getTime() + (duration + lateMin) * 60000) : null;

  /* ---------- saving (returns the draft id on success) ---------- */
  const doSave = useCallback(async (): Promise<string | null> => {
    if (saving) return null;
    setSaving(true);
    setSaveError(null);
    const cohorts = years.map((y) => ({ year: y, department: selectedCourse?.department ?? null }));
    const qPayload = questions.map((q) => ({
      prompt: q.prompt.trim(),
      options: q.options.map((o) => o.trim()),
      correct: q.correct,
      marks: q.marks,
    }));
    const { data: id, error } = await saveDraft(
      serverId,
      {
        title: title.trim(),
        course_code: subjectCode.trim(),
        starts_at: startsAt ? startsAt.toISOString() : null,
        ends_at: endsAt ? endsAt.toISOString() : null,
        duration_min: duration,
        pass_pct: passPct,
        negative_fraction: negOn ? negFraction : 0,
      },
      cohorts,
      qPayload,
    );
    if (error || !id) {
      setSaveError(error?.message ?? "The draft could not be saved.");
      setSaving(false);
      return null;
    }
    setServerId(id);
    const inv = await setInvigilators(id, selectedInv);
    if (inv.error) {
      setSaveError(inv.error.message);
      setSaving(false);
      return null;
    }
    setSavedAt(new Date());
    setDirty(false);
    setSaving(false);
    return id;
  }, [saving, serverId, title, subjectCode, startsAt, endsAt, duration, passPct, negOn, negFraction, years, selectedCourse, questions, selectedInv]);

  /* ---------- review & lock ---------- */
  const refreshProblems = useCallback(async (id: string) => {
    setCheckingProblems(true);
    setProblemsError(null);
    const { data, error } = await examProblems(id);
    setCheckingProblems(false);
    if (error) {
      setProblemsError(error.message);
      setProblems(null);
      return;
    }
    setProblems(data ?? []);
  }, []);

  const enterReview = async () => {
    const id = await doSave();
    if (!id) return;
    onNotify("success", "Draft saved");
    setStep(4);
    void refreshProblems(id);
  };

  const recheck = async () => {
    const id = await doSave();
    if (!id) return;
    void refreshProblems(id);
  };

  const lockValid = lockPass.length >= 8 && lockPass === lockConfirm && lockAck;

  const doLock = async () => {
    if (locking || !serverId || !lockValid) return;
    setLocking(true);
    setLockError(null);
    const { error } = await lockExam(serverId, lockPass);
    // Never retain the passphrase after the request completes.
    setLockPass("");
    setLockConfirm("");
    setLocking(false);
    if (error) {
      setLockError(error.message);
      return;
    }
    setLockedInfo({ title: title.trim(), opens: startsAt ? fmtOpens(startsAt) : "—" });
  };

  /* ---------- navigation ---------- */
  const basicsOk = title.trim().length > 0 && subjectCode.trim().length > 0 && Boolean(courseCode) && years.length > 0;
  const scheduleOk = Boolean(startsAt) && !startTooSoon && duration >= 5 && duration <= 360;

  const next = async () => {
    if (step === 1 && !basicsOk) {
      onNotify("error", "Add a title, subject code, course and at least one year.");
      return;
    }
    if (step === 2 && !scheduleOk) {
      onNotify("error", startTooSoon ? "The start must be at least 10 minutes from now." : "Set a valid date, time and duration.");
      return;
    }
    if (step === 3) {
      await enterReview(); // saves the draft, then loads the problem list
      return;
    }
    const id = await doSave();
    if (id) {
      onNotify("success", "Draft saved");
      setStep((s) => Math.min(3, s + 1) as 1 | 2 | 3);
    }
  };

  const back = () => {
    if (step > 1) {
      setStep((s) => (s - 1) as 1 | 2 | 3 | 4);
      return;
    }
    if (dirty) setConfirmLeave("back");
    else onExit();
  };

  const exit = () => {
    if (dirty) setConfirmLeave("exit");
    else onExit();
  };

  /* ---------- beforeunload ---------- */
  useEffect(() => {
    const h = (e: BeforeUnloadEvent) => {
      if (dirtyRef.current) {
        e.preventDefault();
        e.returnValue = "";
      }
    };
    window.addEventListener("beforeunload", h);
    return () => window.removeEventListener("beforeunload", h);
  }, []);

  /* ---------- question helpers ---------- */
  const patchQ = (i: number, p: Partial<WQ>) => {
    setQuestions((list) => list.map((q, j) => (j === i ? { ...q, ...p } : q)));
    touch();
  };
  const totalMarks = questions.reduce((s, q) => s + q.marks, 0);

  const steps: { n: 1 | 2 | 3 | 4; label: string }[] = [
    { n: 1, label: "Basics" },
    { n: 2, label: "Schedule" },
    { n: 3, label: "Questions" },
    { n: 4, label: "Review & lock" },
  ];

  const saveStatus = saving ? (
    <span className="flex items-center gap-1.5 text-[11px] font-extrabold text-neutral-500">
      <Loader2 className="h-3.5 w-3.5 animate-spin" strokeWidth={2.4} /> Saving…
    </span>
  ) : saveError ? (
    <span className="flex items-center gap-1.5 text-[11px] font-extrabold text-rose-500">
      <AlertCircle className="h-3.5 w-3.5" strokeWidth={2.4} /> {saveError}
    </span>
  ) : savedAt ? (
    <span className="flex items-center gap-1.5 text-[11px] font-extrabold text-emerald-600">
      <Check className="h-3.5 w-3.5" strokeWidth={3} /> Saved {hhmm(savedAt)}
    </span>
  ) : null;

  if (loadingDraft) {
    return (
      <div className="flex min-h-dvh items-center justify-center">
        <span className="flex items-center gap-2 text-[13px] font-extrabold text-neutral-500">
          <Loader2 className="h-5 w-5 animate-spin" strokeWidth={2.4} /> Loading draft…
        </span>
      </div>
    );
  }

  /* ---------- locked confirmation ---------- */
  if (lockedInfo) {
    return (
      <div className="relative z-10 mx-auto flex min-h-dvh w-full max-w-[560px] flex-col items-center justify-center px-6 py-12 text-center">
        <span className="animate-rise relative flex h-20 w-20 items-center justify-center rounded-full bg-emerald-100 ring-8 ring-emerald-50">
          <Lock className="h-9 w-9 text-emerald-600" strokeWidth={2.2} />
        </span>
        <h2 className="animate-rise mt-6 text-[30px] font-extrabold tracking-tight text-neutral-950" style={{ animationDelay: "70ms" }}>
          Exam locked
        </h2>
        <p className="animate-rise mt-2 text-[15px] font-extrabold text-neutral-700" style={{ animationDelay: "120ms" }}>
          {lockedInfo.title}
        </p>
        <p className="animate-rise mt-1 text-[13px] font-semibold text-neutral-500" style={{ animationDelay: "160ms" }}>
          Opens {lockedInfo.opens}
        </p>
        <button
          type="button"
          onClick={onExit}
          className="animate-rise group mt-8 flex h-[54px] items-center justify-center gap-2.5 rounded-full bg-neutral-950 px-8 text-[14px] font-extrabold text-white shadow-[0_20px_40px_-16px_rgba(0,0,0,0.6)] transition-all hover:-translate-y-0.5 hover:bg-neutral-800 active:scale-[0.99]"
          style={{ animationDelay: "220ms" }}
        >
          Back to dashboard
          <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" strokeWidth={2.6} />
        </button>
      </div>
    );
  }

  return (
    <div className="relative min-h-dvh pb-28">
      {/* ---------- top bar ---------- */}
      <header className="animate-rise sticky top-0 z-30 border-b border-rose-100/60 bg-[#fdf0ea]/90 px-4 py-3.5 backdrop-blur-md sm:px-6">
        <div className="mx-auto flex w-full max-w-[1000px] items-center gap-3">
          <button
            type="button"
            onClick={exit}
            aria-label="Exit builder"
            className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-white text-neutral-700 shadow-[0_8px_20px_-8px_rgba(190,80,115,0.4)] transition-all hover:-translate-x-0.5 hover:text-rose-500 active:scale-95"
          >
            <ArrowLeft className="h-[18px] w-[18px]" strokeWidth={2.6} />
          </button>
          <div className="min-w-0 flex-1">
            <h1 className="truncate text-[17px] font-extrabold tracking-tight text-neutral-900">
              {serverId ? "Edit exam" : "Exam builder"}
            </h1>
            <p className="truncate text-[10.5px] font-bold text-neutral-500">
              {subjectCode.trim() || "New draft"} · {title.trim() || "Untitled"}
            </p>
          </div>
          {saveStatus}
        </div>
      </header>

      {/* ---------- mobile stepper ---------- */}
      <div className="mx-auto mt-4 flex w-full max-w-[1000px] items-center gap-1.5 px-4 lg:hidden">
        {steps.map((s, i) => {
          const active = s.n === step;
          const done = s.n < step;
          const disabled = s.n === 4 && step !== 4;
          return (
            <span key={s.n} className="flex min-w-0 flex-1 items-center gap-1.5">
              <button
                type="button"
                disabled={disabled || s.n > step}
                onClick={() => !disabled && s.n <= step && setStep(s.n as 1 | 2 | 3 | 4)}
                className={
                  "flex min-h-11 flex-1 items-center justify-center gap-1.5 rounded-full px-2 text-[10.5px] font-extrabold transition-all " +
                  (active
                    ? "bg-neutral-900 text-white shadow-[0_10px_22px_-10px_rgba(0,0,0,0.6)]"
                    : done
                      ? "bg-yellow-300 text-neutral-900"
                      : disabled
                        ? "bg-neutral-200/70 text-neutral-400"
                        : "bg-white/80 text-neutral-500")
                }
              >
                {done ? <Check className="h-3 w-3" strokeWidth={3.2} /> : <span>{s.n}</span>}
                <span className="hidden min-w-0 truncate sm:inline">{s.label}</span>
              </button>
              {i < steps.length - 1 && <span className="h-px w-2 shrink-0 bg-neutral-300" />}
            </span>
          );
        })}
      </div>

      {/* ---------- body ---------- */}
      <div className="mx-auto mt-5 flex w-full max-w-[1000px] gap-6 px-4 sm:px-6 lg:mt-8">
        {/* desktop stepper */}
        <aside className="hidden w-[240px] shrink-0 lg:block">
          <div className="sticky top-24 flex flex-col gap-2">
            {steps.map((s) => {
              const active = s.n === step;
              const done = s.n < step;
              const disabled = s.n === 4 && step !== 4;
              return (
                <button
                  key={s.n}
                  type="button"
                  disabled={disabled || s.n > step}
                  onClick={() => !disabled && s.n <= step && setStep(s.n as 1 | 2 | 3 | 4)}
                  className={
                    "flex min-h-12 items-center gap-3 rounded-2xl px-4 text-left text-[13px] font-extrabold transition-all duration-200 " +
                    (active
                      ? "bg-neutral-900 text-white shadow-[0_14px_30px_-12px_rgba(0,0,0,0.6)]"
                      : done
                        ? "bg-yellow-300 text-neutral-900 hover:-translate-y-0.5"
                        : disabled
                          ? "cursor-not-allowed bg-white/60 text-neutral-400"
                          : "bg-white/80 text-neutral-600 hover:bg-white")
                  }
                >
                  <span
                    className={
                      "flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-[12px] " +
                      (active ? "bg-white/20" : done ? "bg-neutral-900/10" : "bg-neutral-200/80")
                    }
                  >
                    {done ? <Check className="h-3.5 w-3.5" strokeWidth={3.2} /> : s.n}
                  </span>
                  {s.label}
                </button>
              );
            })}
            <div className="mt-3 flex justify-center">{saveStatus}</div>
          </div>
        </aside>

        {/* content */}
        <section className="min-w-0 flex-1 lg:max-w-[720px]">
          {/* ================= STEP 1: BASICS ================= */}
          {step === 1 && (
            <div className={card + " animate-rise"}>
              <h2 className="text-[18px] font-extrabold tracking-tight text-neutral-950">Basics</h2>

              <label className="mt-5 block">
                <span className={label}>TITLE</span>
                <input
                  type="text"
                  maxLength={200}
                  value={title}
                  onChange={(e) => {
                    setTitle(e.target.value);
                    touch();
                  }}
                  placeholder="e.g. Midterm — Data Structures"
                  className={inputBase + " mt-2"}
                />
              </label>

              <div className="mt-4 grid gap-4 sm:grid-cols-2">
                <label className="block">
                  <span className={label}>SUBJECT CODE</span>
                  <input
                    type="text"
                    maxLength={40}
                    value={subjectCode}
                    onChange={(e) => {
                      setSubjectCode(e.target.value.toUpperCase());
                      touch();
                    }}
                    placeholder="e.g. BSCIT101"
                    className={inputBase + " mt-2 font-mono"}
                  />
                </label>

                <label className="relative block">
                  <span className={label}>COURSE</span>
                  {coursesError ? (
                    <span className="mt-2 flex h-12 items-center justify-between gap-2 rounded-2xl bg-rose-50 px-4 ring-1 ring-rose-200">
                      <span className="text-[12px] font-bold text-rose-500">Could not load courses</span>
                      <button
                        type="button"
                        onClick={() => void loadCourses()}
                        className="flex h-8 items-center gap-1.5 rounded-full bg-neutral-950 px-3 text-[10.5px] font-extrabold text-white active:scale-95"
                      >
                        <RefreshCw className="h-3 w-3" strokeWidth={2.6} /> Retry
                      </button>
                    </span>
                  ) : (
                    <>
                      <select
                        value={courseCode}
                        disabled={coursesLoading || courses.length === 0}
                        onChange={(e) => {
                          const code = e.target.value;
                          setCourseCode(code);
                          const c = courses.find((x) => x.code === code);
                          if (c && !subjectCode.trim()) setSubjectCode(c.code);
                          touch();
                        }}
                        className={
                          inputBase +
                          " mt-2 appearance-none pr-10 " +
                          (courseCode === "" ? "font-medium text-neutral-400" : "")
                        }
                      >
                        <option value="" disabled>
                          {coursesLoading ? "Loading courses…" : courses.length === 0 ? "No courses available" : "Select course"}
                        </option>
                        {courses.map((c) => (
                          <option key={c.code} value={c.code} className="font-bold text-neutral-900">
                            {c.name}
                          </option>
                        ))}
                      </select>
                      <ChevronDown className="pointer-events-none absolute bottom-3.5 right-4 h-4 w-4 text-neutral-500" strokeWidth={2.4} />
                    </>
                  )}
                </label>
              </div>

              {/* years */}
              <div className="mt-5">
                <span className={label}>YEARS</span>
                <div className="mt-2 flex flex-wrap gap-2">
                  {YEARS.map((y) => {
                    const on = years.includes(y);
                    return (
                      <button
                        key={y}
                        type="button"
                        onClick={() => {
                          setYears((list) => (on ? list.filter((x) => x !== y) : [...list, y].sort()));
                          touch();
                        }}
                        aria-pressed={on}
                        className={
                          "flex min-h-11 items-center gap-2 rounded-full px-5 text-[12.5px] font-extrabold transition-all duration-200 active:scale-95 " +
                          (on
                            ? "bg-yellow-300 text-neutral-900 shadow-[0_10px_22px_-10px_rgba(234,179,8,0.7)]"
                            : "bg-[#f3ede7] text-neutral-600 hover:bg-[#efe6dd]")
                        }
                      >
                        {on && <Check className="h-3.5 w-3.5" strokeWidth={3.2} />}
                        Year {y}
                      </button>
                    );
                  })}
                </div>
                {selectedCourse && (
                  <p className="mt-2 flex items-center gap-1.5 text-[11px] font-bold text-neutral-500">
                    <Users className="h-3.5 w-3.5 text-violet-600" strokeWidth={2.3} />
                    Cohort: {years.length ? years.map((y) => `Year ${y}`).join(", ") : "—"} ·{" "}
                    {selectedCourse.department ?? "All departments"}
                  </p>
                )}
              </div>

              {/* pass + negative */}
              <div className="mt-5 grid gap-4 sm:grid-cols-2">
                <label className="block">
                  <span className={label}>PASS MARK %</span>
                  <input
                    type="number"
                    min={1}
                    max={100}
                    value={passPct}
                    onChange={(e) => {
                      setPassPct(Math.min(100, Math.max(1, Number(e.target.value) || 1)));
                      touch();
                    }}
                    className={inputBase + " mt-2"}
                  />
                </label>
                <div>
                  <span className={label}>NEGATIVE MARKING</span>
                  <div className="mt-2 flex min-h-12 items-center gap-3 rounded-2xl bg-[#f3ede7] px-4">
                    <span className="flex-1 text-[12.5px] font-bold text-neutral-700">Penalty for wrong answers</span>
                    <button
                      type="button"
                      role="switch"
                      aria-checked={negOn}
                      aria-label="Negative marking"
                      onClick={() => {
                        setNegOn((v) => !v);
                        touch();
                      }}
                      className={"relative h-7 w-12 shrink-0 rounded-full transition-colors duration-300 " + (negOn ? "bg-fuchsia-700" : "bg-neutral-300")}
                    >
                      <span className={"absolute top-0.5 h-6 w-6 rounded-full bg-white shadow transition-all duration-300 " + (negOn ? "left-[22px]" : "left-0.5")} />
                    </button>
                  </div>
                  {negOn && (
                    <div className="mt-2 flex items-center gap-2">
                      <select
                        value={negFraction}
                        onChange={(e) => {
                          setNegFraction(Number(e.target.value));
                          touch();
                        }}
                        className={inputBase + " appearance-none pr-8"}
                        aria-label="Penalty fraction"
                      >
                        {NEG_FRACTIONS.map((f) => (
                          <option key={f} value={f}>
                            {f}
                          </option>
                        ))}
                      </select>
                    </div>
                  )}
                  <p className="mt-2 text-[11px] font-bold text-neutral-500">
                    {negOn
                      ? `Each wrong answer loses ${negFraction} × the question's marks`
                      : "Wrong answers cost nothing"}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* ================= STEP 2: SCHEDULE ================= */}
          {step === 2 && (
            <div className={card + " animate-rise"}>
              <h2 className="text-[18px] font-extrabold tracking-tight text-neutral-950">Schedule</h2>

              <div className="mt-5 grid gap-4 sm:grid-cols-2">
                <label className="block">
                  <span className={label}>DATE</span>
                  <input
                    type="date"
                    value={dateStr}
                    onChange={(e) => {
                      setDateStr(e.target.value);
                      touch();
                    }}
                    className={inputBase + " mt-2"}
                  />
                </label>
                <label className="block">
                  <span className={label}>START TIME</span>
                  <input
                    type="time"
                    value={timeStr}
                    onChange={(e) => {
                      setTimeStr(e.target.value);
                      touch();
                    }}
                    className={inputBase + " mt-2"}
                  />
                </label>
              </div>

              <div className="mt-4">
                <span className={label}>DURATION (MINUTES)</span>
                <div className="mt-2 flex flex-wrap items-center gap-2">
                  <input
                    type="number"
                    min={5}
                    max={360}
                    value={duration}
                    onChange={(e) => {
                      setDuration(Math.min(360, Math.max(5, Number(e.target.value) || 5)));
                      touch();
                    }}
                    className={inputBase + " w-28"}
                  />
                  {DUR_CHIPS.map((d) => (
                    <button
                      key={d}
                      type="button"
                      onClick={() => {
                        setDuration(d);
                        touch();
                      }}
                      className={
                        "flex min-h-11 items-center rounded-full px-4 text-[11.5px] font-extrabold transition-all active:scale-95 " +
                        (duration === d ? "bg-neutral-900 text-white" : "bg-[#f3ede7] text-neutral-600 hover:bg-[#efe6dd]")
                      }
                    >
                      {d}
                    </button>
                  ))}
                </div>
              </div>

              <label className="relative mt-4 block sm:max-w-[260px]">
                <span className={label}>LATE ENTRY ALLOWED</span>
                <select
                  value={lateMin}
                  onChange={(e) => {
                    setLateMin(Number(e.target.value));
                    touch();
                  }}
                  className={inputBase + " mt-2 appearance-none pr-10"}
                >
                  {lateOptions.map((m) => (
                    <option key={m} value={m}>
                      {m} minutes
                    </option>
                  ))}
                </select>
                <ChevronDown className="pointer-events-none absolute bottom-3.5 right-4 h-4 w-4 text-neutral-500" strokeWidth={2.4} />
              </label>

              {/* honest derived lines */}
              <div className="mt-5 flex flex-col gap-2 rounded-2xl bg-[#f3ede7] p-4 text-[12px] font-bold text-neutral-700">
                <span className="flex items-center gap-2">
                  <CalendarDays className="h-4 w-4 shrink-0 text-pink-500" strokeWidth={2.3} />
                  {startsAt ? `Opens: ${fmtOpens(startsAt)}` : "Opens: not set"}
                </span>
                <span className="flex items-center gap-2">
                  <Lock className="h-4 w-4 shrink-0 text-pink-500" strokeWidth={2.3} />
                  {entryClosesAt ? `Entry closes: ${hhmm(entryClosesAt)}` : "Entry closes: not set"}
                </span>
                <span className="flex items-center gap-2">
                  <Clock className="h-4 w-4 shrink-0 text-pink-500" strokeWidth={2.3} />
                  Each student gets {duration} minutes from the moment they start
                </span>
                <span className="flex items-center gap-2">
                  <Hourglass className="h-4 w-4 shrink-0 text-pink-500" strokeWidth={2.3} />
                  {endsAt ? `Exam window ends: ${hhmm(endsAt)}` : "Exam window ends: not set"}
                </span>
                {startTooSoon && (
                  <span className="mt-1 flex items-center gap-2 rounded-xl bg-rose-50 px-3 py-2 text-[11.5px] font-extrabold text-rose-600 ring-1 ring-rose-200">
                    <AlertCircle className="h-3.5 w-3.5 shrink-0" strokeWidth={2.4} />
                    The start must be at least 10 minutes from now.
                  </span>
                )}
              </div>

              {/* invigilators */}
              <div className="mt-6">
                <span className="flex items-center gap-2 text-[13px] font-extrabold text-neutral-800">
                  <UserCheck className="h-4 w-4 text-violet-600" strokeWidth={2.3} />
                  Invigilators
                </span>
                {invLoading ? (
                  <p className="mt-3 flex items-center gap-2 text-[12px] font-bold text-neutral-500">
                    <Loader2 className="h-4 w-4 animate-spin" strokeWidth={2.4} /> Loading invigilators…
                  </p>
                ) : invError ? (
                  <div className="mt-3 flex items-center justify-between gap-3 rounded-2xl bg-rose-50 p-3.5 ring-1 ring-rose-200">
                    <span className="text-[12px] font-bold text-rose-500">Could not load invigilators</span>
                    <button
                      type="button"
                      onClick={() => void loadInvigilators()}
                      className="flex h-9 items-center gap-1.5 rounded-full bg-neutral-950 px-3 text-[10.5px] font-extrabold text-white active:scale-95"
                    >
                      <RefreshCw className="h-3 w-3" strokeWidth={2.6} /> Retry
                    </button>
                  </div>
                ) : invigilators.length === 0 ? (
                  <p className="mt-3 rounded-2xl bg-[#f3ede7] p-4 text-[12px] font-bold text-neutral-500">
                    No invigilator accounts exist. Ask the Controller of Exams.
                  </p>
                ) : (
                  <div className="mt-3 flex flex-col gap-2">
                    {invigilators.map((inv) => {
                      const on = selectedInv.includes(inv.id);
                      return (
                        <button
                          key={inv.id}
                          type="button"
                          onClick={() => {
                            setSelectedInv((list) => (on ? list.filter((x) => x !== inv.id) : [...list, inv.id]));
                            touch();
                          }}
                          aria-pressed={on}
                          className={
                            "flex min-h-12 items-center gap-3 rounded-2xl border-2 px-4 text-left transition-all duration-200 active:scale-[0.99] " +
                            (on ? "border-violet-300 bg-violet-50" : "border-neutral-100 bg-[#f3ede7]/60 hover:border-neutral-200")
                          }
                        >
                          <span
                            className={
                              "flex h-6 w-6 shrink-0 items-center justify-center rounded-lg transition-all " +
                              (on ? "bg-violet-600" : "bg-white ring-2 ring-neutral-300")
                            }
                          >
                            {on && <Check className="h-3.5 w-3.5 text-white" strokeWidth={3.4} />}
                          </span>
                          <span className="text-[13px] font-bold text-neutral-800">{inv.full_name ?? "Invigilator"}</span>
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ================= STEP 3: QUESTIONS ================= */}
          {step === 3 && (
            <div className="flex flex-col gap-4">
              <div className="sticky top-[68px] z-20 flex items-center justify-between rounded-full bg-neutral-950/95 px-5 py-3 text-[12px] font-extrabold text-white shadow-[0_14px_30px_-12px_rgba(0,0,0,0.6)] backdrop-blur">
                <span>
                  {questions.length} question{questions.length === 1 ? "" : "s"}
                </span>
                <span className="text-amber-300">{totalMarks} total marks</span>
              </div>

              {questions.map((q, i) => {
                const promptEmpty = q.prompt.trim().length === 0;
                const hasEmptyOpt = q.options.some((o) => o.trim().length === 0);
                return (
                  <div key={q.key} className={card + " animate-rise"}>
                    <div className="flex items-center justify-between gap-3">
                      <span className="flex h-9 w-9 items-center justify-center rounded-full bg-pink-200 text-[13px] font-extrabold text-pink-700">
                        {i + 1}
                      </span>
                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          aria-label="Move up"
                          disabled={i === 0}
                          onClick={() => {
                            setQuestions((l) => l.map((x, j) => (j === i ? l[i - 1] : j === i - 1 ? l[i] : x)));
                            touch();
                          }}
                          className="flex h-11 w-11 items-center justify-center rounded-full text-neutral-500 transition-colors hover:bg-[#f3ede7] disabled:opacity-30"
                        >
                          <ChevronDown className="h-4 w-4 rotate-180" strokeWidth={2.6} />
                        </button>
                        <button
                          type="button"
                          aria-label="Move down"
                          disabled={i === questions.length - 1}
                          onClick={() => {
                            setQuestions((l) => l.map((x, j) => (j === i ? l[i + 1] : j === i + 1 ? l[i] : x)));
                            touch();
                          }}
                          className="flex h-11 w-11 items-center justify-center rounded-full text-neutral-500 transition-colors hover:bg-[#f3ede7] disabled:opacity-30"
                        >
                          <ChevronDown className="h-4 w-4" strokeWidth={2.6} />
                        </button>
                        <button
                          type="button"
                          aria-label="Duplicate question"
                          onClick={() => {
                            setQuestions((l) => [...l.slice(0, i + 1), { ...q, key: newKey(), options: [...q.options] }, ...l.slice(i + 1)]);
                            touch();
                          }}
                          className="flex h-11 w-11 items-center justify-center rounded-full text-neutral-500 transition-colors hover:bg-[#f3ede7]"
                        >
                          <Copy className="h-4 w-4" strokeWidth={2.3} />
                        </button>
                        <button
                          type="button"
                          aria-label="Delete question"
                          onClick={() => setDeleteQ(i)}
                          className="flex h-11 w-11 items-center justify-center rounded-full text-rose-500 transition-colors hover:bg-rose-50"
                        >
                          <Trash2 className="h-4 w-4" strokeWidth={2.3} />
                        </button>
                      </div>
                    </div>

                    <textarea
                      value={q.prompt}
                      maxLength={2000}
                      onChange={(e) => patchQ(i, { prompt: e.target.value })}
                      placeholder="Question prompt…"
                      rows={2}
                      className="mt-3 w-full resize-none rounded-2xl bg-[#f3ede7] px-4 py-3 text-[13.5px] font-semibold leading-relaxed text-neutral-900 outline-none transition-all placeholder:font-medium placeholder:text-neutral-400 focus:bg-white focus:ring-4 focus:ring-rose-100"
                    />
                    {promptEmpty && <p className="mt-1 text-[10.5px] font-extrabold text-rose-500">Add a prompt</p>}

                    <div className="mt-3 flex flex-col gap-2">
                      {q.options.map((opt, oi) => (
                        <div key={oi} className="flex items-center gap-2.5">
                          <button
                            type="button"
                            aria-label={`Mark option ${oi + 1} correct`}
                            onClick={() => patchQ(i, { correct: oi })}
                            className={
                              "flex h-8 w-8 shrink-0 items-center justify-center rounded-full border-2 text-[11.5px] font-extrabold transition-all " +
                              (q.correct === oi
                                ? "border-emerald-500 bg-emerald-500 text-white"
                                : "border-neutral-300 text-neutral-500 hover:border-emerald-400")
                            }
                          >
                            {q.correct === oi ? <Check className="h-3.5 w-3.5" strokeWidth={3.2} /> : String.fromCharCode(65 + oi)}
                          </button>
                          <input
                            type="text"
                            value={opt}
                            onChange={(e) =>
                              patchQ(i, { options: q.options.map((o, j) => (j === oi ? e.target.value : o)) })
                            }
                            placeholder={`Option ${String.fromCharCode(65 + oi)}`}
                            className="h-11 min-w-0 flex-1 rounded-2xl bg-[#f3ede7] px-4 text-[13px] font-bold text-neutral-800 outline-none transition-all placeholder:font-medium placeholder:text-neutral-400 focus:bg-white focus:ring-4 focus:ring-rose-100"
                          />
                          {q.options.length > 2 && (
                            <button
                              type="button"
                              aria-label="Remove option"
                              onClick={() => {
                                const opts = q.options.filter((_, j) => j !== oi);
                                let corr = q.correct;
                                if (corr === oi) corr = null;
                                else if (corr !== null && corr > oi) corr -= 1;
                                patchQ(i, { options: opts, correct: corr });
                              }}
                              className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-neutral-400 transition-colors hover:bg-rose-50 hover:text-rose-500"
                            >
                              <X className="h-3.5 w-3.5" strokeWidth={2.6} />
                            </button>
                          )}
                        </div>
                      ))}
                      {hasEmptyOpt && <p className="text-[10.5px] font-extrabold text-rose-500">An option is empty</p>}
                      {q.correct === null && <p className="text-[10.5px] font-extrabold text-rose-500">Mark the correct answer</p>}
                    </div>

                    <div className="mt-3 flex items-center gap-3">
                      {q.options.length < 6 && (
                        <button
                          type="button"
                          onClick={() => patchQ(i, { options: [...q.options, ""] })}
                          className="flex min-h-11 items-center gap-1.5 rounded-full bg-[#f3ede7] px-4 text-[11.5px] font-extrabold text-neutral-700 transition-all hover:bg-[#efe6dd] active:scale-95"
                        >
                          <Plus className="h-3.5 w-3.5" strokeWidth={3} /> Add option
                        </button>
                      )}
                      <label className="ml-auto flex items-center gap-2 text-[11px] font-extrabold text-neutral-500">
                        MARKS
                        <input
                          type="number"
                          min={1}
                          value={q.marks}
                          onChange={(e) => patchQ(i, { marks: Math.max(1, Number(e.target.value) || 1) })}
                          className="h-10 w-20 rounded-2xl bg-[#f3ede7] px-3 text-center text-[13px] font-extrabold text-neutral-900 outline-none focus:bg-white focus:ring-4 focus:ring-rose-100"
                        />
                      </label>
                    </div>
                  </div>
                );
              })}

              <button
                type="button"
                onClick={() => {
                  setQuestions((l) => [...l, blankQ()]);
                  touch();
                }}
                className="flex min-h-12 items-center justify-center gap-2 rounded-full bg-white text-[13px] font-extrabold text-neutral-800 shadow-[0_12px_28px_-14px_rgba(190,80,115,0.45)] transition-all hover:-translate-y-0.5 active:scale-[0.98]"
              >
                <Plus className="h-4 w-4 text-pink-600" strokeWidth={3} />
                Add question
              </button>
            </div>
          )}

          {/* ================= STEP 4: REVIEW & LOCK ================= */}
          {step === 4 && (
            <div className="flex flex-col gap-4">
              {/* review card */}
              <div className={card + " animate-rise"}>
                <h2 className="text-[18px] font-extrabold tracking-tight text-neutral-950">Review &amp; lock</h2>
                <div className="mt-4 flex flex-col gap-2.5">
                  {(
                    [
                      ["Title", title.trim() || "—"],
                      ["Subject code", subjectCode.trim() || "—"],
                      ["Course", selectedCourse ? `${selectedCourse.name} (${selectedCourse.department ?? "All departments"})` : "—"],
                      ["Years", years.length ? years.map((y) => `Year ${y}`).join(", ") : "—"],
                      ["Opens", startsAt ? fmtOpens(startsAt) : "Not scheduled"],
                      ["Entry closes", entryClosesAt ? hhmm(entryClosesAt) : "—"],
                      ["Each student gets", `${duration} minutes from the moment they start`],
                      ["Exam window ends", endsAt ? hhmm(endsAt) : "—"],
                      ["Pass mark", `${passPct}%`],
                      [
                        "Negative marking",
                        negOn ? `On — ${negFraction} × marks per wrong answer` : "Off — wrong answers cost nothing",
                      ],
                      [
                        "Invigilators",
                        selectedInv.length
                          ? invigilators.filter((v) => selectedInv.includes(v.id)).map((v) => v.full_name ?? "Invigilator").join(", ")
                          : "None assigned",
                      ],
                      ["Questions", `${questions.length} questions · ${totalMarks} total marks`],
                    ] as [string, string][]
                  ).map(([k, v]) => (
                    <div key={k} className="flex items-start justify-between gap-4 rounded-xl bg-[#f3ede7] px-4 py-2.5">
                      <span className="shrink-0 text-[10.5px] font-extrabold tracking-[0.12em] text-neutral-500">{k.toUpperCase()}</span>
                      <span className="text-right text-[12.5px] font-extrabold text-neutral-800">{v}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* problems / lock */}
              {checkingProblems ? (
                <div className={card + " animate-rise flex items-center justify-center gap-2 py-10 text-[13px] font-extrabold text-neutral-500"}>
                  <Loader2 className="h-5 w-5 animate-spin" strokeWidth={2.4} /> Checking for problems…
                </div>
              ) : problemsError ? (
                <div className={card + " animate-rise flex flex-col items-center gap-3 py-8 text-center"}>
                  <p className="text-[13px] font-extrabold text-rose-500">{problemsError}</p>
                  <button
                    type="button"
                    onClick={() => void recheck()}
                    className="flex h-11 items-center gap-2 rounded-full bg-neutral-950 px-5 text-[12.5px] font-extrabold text-white active:scale-[0.98]"
                  >
                    <RefreshCw className="h-4 w-4" strokeWidth={2.4} /> Re-check
                  </button>
                </div>
              ) : problems && problems.length > 0 ? (
                <div className={card + " animate-rise"}>
                  <div className="flex items-center gap-2.5">
                    <span className="flex h-9 w-9 items-center justify-center rounded-full bg-amber-100">
                      <AlertCircle className="h-[18px] w-[18px] text-amber-600" strokeWidth={2.2} />
                    </span>
                    <h3 className="text-[15px] font-extrabold text-neutral-950">Fix these before locking</h3>
                  </div>
                  <div className="mt-4 flex flex-col gap-2">
                    {problems.map((p, i) => (
                      <div key={i} className="flex items-center justify-between gap-3 rounded-xl bg-amber-50 px-4 py-3 ring-1 ring-amber-200">
                        <p className="min-w-0 text-[12.5px] font-bold leading-snug text-amber-800">{p}</p>
                        <button
                          type="button"
                          onClick={() => setStep(stepForProblem(p))}
                          className="flex h-10 shrink-0 items-center rounded-full bg-neutral-950 px-4 text-[11.5px] font-extrabold text-white transition-all hover:bg-neutral-800 active:scale-95"
                        >
                          Fix
                        </button>
                      </div>
                    ))}
                  </div>
                  <button
                    type="button"
                    onClick={() => void recheck()}
                    className="mt-4 flex min-h-12 w-full items-center justify-center gap-2 rounded-full bg-white text-[13px] font-extrabold text-neutral-700 shadow-[0_12px_28px_-14px_rgba(190,80,115,0.45)] transition-all hover:-translate-y-0.5 active:scale-[0.98]"
                  >
                    <RefreshCw className="h-4 w-4" strokeWidth={2.4} />
                    Re-check
                  </button>
                </div>
              ) : (
                <div className={card + " animate-rise"}>
                  <div className="flex items-center gap-2.5">
                    <span className="flex h-9 w-9 items-center justify-center rounded-full bg-emerald-100">
                      <Check className="h-[18px] w-[18px] text-emerald-600" strokeWidth={2.6} />
                    </span>
                    <h3 className="text-[15px] font-extrabold text-neutral-950">Ready to lock</h3>
                  </div>

                  <div className="mt-5 grid gap-4 sm:grid-cols-2">
                    <label className="relative block">
                      <span className={label}>PASSPHRASE</span>
                      <input
                        type={showLockPw ? "text" : "password"}
                        value={lockPass}
                        autoComplete="new-password"
                        onChange={(e) => {
                          setLockPass(e.target.value);
                          setLockError(null);
                        }}
                        placeholder="At least 8 characters"
                        className={inputBase + " mt-2 pr-12"}
                      />
                      <button
                        type="button"
                        aria-label={showLockPw ? "Hide passphrase" : "Show passphrase"}
                        onClick={() => setShowLockPw((s) => !s)}
                        className="absolute bottom-2.5 right-3 flex h-8 w-8 items-center justify-center rounded-full text-neutral-500 transition-colors hover:bg-neutral-200/60"
                      >
                        {showLockPw ? <EyeOff className="h-4 w-4" strokeWidth={2.1} /> : <Eye className="h-4 w-4" strokeWidth={2.1} />}
                      </button>
                      {lockPass.length > 0 && lockPass.length < 8 && (
                        <span className="mt-1.5 block text-[10.5px] font-extrabold text-rose-500">Minimum 8 characters</span>
                      )}
                    </label>
                    <label className="relative block">
                      <span className={label}>CONFIRM PASSPHRASE</span>
                      <input
                        type={showLockPw ? "text" : "password"}
                        value={lockConfirm}
                        autoComplete="new-password"
                        onChange={(e) => {
                          setLockConfirm(e.target.value);
                          setLockError(null);
                        }}
                        placeholder="Repeat it"
                        className={inputBase + " mt-2"}
                      />
                      {lockConfirm.length > 0 && lockPass !== lockConfirm && (
                        <span className="mt-1.5 block text-[10.5px] font-extrabold text-rose-500">Passphrases do not match</span>
                      )}
                    </label>
                  </div>

                  <button
                    type="button"
                    onClick={() => setLockAck((a) => !a)}
                    aria-pressed={lockAck}
                    className={
                      "mt-4 flex min-h-12 w-full items-start gap-3 rounded-2xl border-2 p-4 text-left transition-all duration-200 active:scale-[0.99] " +
                      (lockAck ? "border-emerald-300 bg-emerald-50" : "border-neutral-200 bg-white hover:border-neutral-300")
                    }
                  >
                    <span
                      className={
                        "mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-lg transition-all duration-200 " +
                        (lockAck ? "bg-emerald-500" : "bg-white ring-2 ring-neutral-300")
                      }
                    >
                      {lockAck && <Check className="h-3.5 w-3.5 text-white" strokeWidth={3.4} />}
                    </span>
                    <span className="text-[12px] font-bold leading-relaxed text-neutral-700">
                      I understand: once locked this exam cannot be edited. To unlock I need this passphrase, and unlocking is
                      possible only until 5 minutes before the start and before any student checks in.
                    </span>
                  </button>

                  {lockError && (
                    <p className="animate-rise mt-3 rounded-xl bg-rose-50 px-4 py-3 text-[12px] font-bold text-rose-600 ring-1 ring-rose-200">
                      {lockError}
                    </p>
                  )}

                  <button
                    type="button"
                    disabled={!lockValid || locking}
                    onClick={() => void doLock()}
                    className={
                      "mt-4 flex min-h-[52px] w-full items-center justify-center gap-2.5 rounded-full text-[14px] font-extrabold transition-all duration-300 " +
                      (lockValid && !locking
                        ? "bg-neutral-950 text-white shadow-[0_18px_36px_-14px_rgba(0,0,0,0.6)] hover:-translate-y-0.5 hover:bg-neutral-800 active:scale-[0.99]"
                        : "cursor-not-allowed bg-neutral-200/80 text-neutral-400")
                    }
                  >
                    {locking ? <Loader2 className="h-4 w-4 animate-spin" strokeWidth={2.5} /> : <Lock className="h-4 w-4" strokeWidth={2.5} />}
                    {locking ? "Locking…" : "Lock exam"}
                  </button>
                  <p className="mt-3 text-center text-[11px] font-semibold text-neutral-400">
                    If you forget the passphrase, contact the Controller of Exams.
                  </p>
                </div>
              )}
            </div>
          )}
        </section>
      </div>

      {/* ---------- sticky bottom bar ---------- */}
      <footer className="fixed inset-x-0 bottom-0 z-30 border-t border-rose-100/60 bg-[#fdf0ea]/92 px-4 py-3 backdrop-blur-md sm:px-6">
        <div className="mx-auto flex w-full max-w-[1000px] items-center gap-2.5">
          <button
            type="button"
            onClick={back}
            className="flex h-12 items-center gap-1.5 rounded-full bg-white px-5 text-[12.5px] font-extrabold text-neutral-700 shadow-[0_10px_24px_-12px_rgba(190,80,115,0.4)] transition-all hover:-translate-y-0.5 active:scale-[0.98]"
          >
            <ArrowLeft className="h-4 w-4" strokeWidth={2.6} />
            Back
          </button>
          {step < 4 && (
            <>
              <button
                type="button"
                disabled={saving}
                onClick={() => void doSave().then((ok) => ok && onNotify("success", "Draft saved"))}
                className="flex h-12 items-center gap-2 rounded-full bg-white px-5 text-[12.5px] font-extrabold text-neutral-700 shadow-[0_10px_24px_-12px_rgba(190,80,115,0.4)] transition-all hover:-translate-y-0.5 active:scale-[0.98] disabled:opacity-60"
              >
                {saving ? <Loader2 className="h-4 w-4 animate-spin" strokeWidth={2.4} /> : <Save className="h-4 w-4" strokeWidth={2.4} />}
                Save draft
              </button>
              <button
                type="button"
                disabled={saving}
                onClick={() => void next()}
                className="group ml-auto flex h-12 min-w-0 flex-1 items-center justify-center gap-2 rounded-full bg-neutral-950 px-5 text-[13px] font-extrabold text-white shadow-[0_16px_32px_-14px_rgba(0,0,0,0.6)] transition-all hover:bg-neutral-800 active:scale-[0.98] disabled:opacity-60 sm:flex-none sm:px-8"
              >
                {saving ? "Saving…" : step === 3 ? "Review & lock" : "Next"}
                {!saving && <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" strokeWidth={2.6} />}
              </button>
            </>
          )}
        </div>
      </footer>

      {/* ---------- confirm leave ---------- */}
      {confirmLeave && (
        <div className="fixed inset-0 z-40 flex items-end justify-center bg-neutral-950/45 p-5 backdrop-blur-sm sm:items-center" onClick={() => setConfirmLeave(null)}>
          <div className="animate-pop w-full max-w-[400px] rounded-[24px] bg-white p-6 shadow-[0_30px_70px_-20px_rgba(0,0,0,0.5)]" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center gap-3">
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-amber-100">
                <Bookmark className="h-5 w-5 text-amber-600" strokeWidth={2.2} />
              </span>
              <h3 className="text-[16px] font-extrabold text-neutral-900">Leave without saving?</h3>
            </div>
            <p className="mt-3 text-[12.5px] font-medium leading-relaxed text-neutral-600">
              You have unsaved changes. If you leave now they will be lost.
            </p>
            <div className="mt-5 flex gap-3">
              <button
                type="button"
                onClick={() => setConfirmLeave(null)}
                className="flex-1 rounded-2xl bg-neutral-100 py-3 text-[13px] font-extrabold text-neutral-700 transition-colors hover:bg-neutral-200"
              >
                Keep editing
              </button>
              <button
                type="button"
                onClick={() => {
                  setConfirmLeave(null);
                  onExit();
                }}
                className="flex-1 rounded-2xl bg-neutral-950 py-3 text-[13px] font-extrabold text-white transition-all hover:bg-neutral-800 active:scale-[0.98]"
              >
                Leave
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ---------- confirm delete question ---------- */}
      {deleteQ !== null && (
        <div className="fixed inset-0 z-40 flex items-end justify-center bg-neutral-950/45 p-5 backdrop-blur-sm sm:items-center" onClick={() => setDeleteQ(null)}>
          <div className="animate-pop w-full max-w-[380px] rounded-[24px] bg-white p-6 shadow-[0_30px_70px_-20px_rgba(0,0,0,0.5)]" onClick={(e) => e.stopPropagation()}>
            <h3 className="text-[16px] font-extrabold text-neutral-900">Delete question {deleteQ + 1}?</h3>
            <p className="mt-2 text-[12.5px] font-medium text-neutral-600">This only affects the draft until you save.</p>
            <div className="mt-5 flex gap-3">
              <button
                type="button"
                onClick={() => setDeleteQ(null)}
                className="flex-1 rounded-2xl bg-neutral-100 py-3 text-[13px] font-extrabold text-neutral-700 hover:bg-neutral-200"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  setQuestions((l) => l.filter((_, j) => j !== deleteQ));
                  setDeleteQ(null);
                  touch();
                }}
                className="flex-1 rounded-2xl bg-rose-600 py-3 text-[13px] font-extrabold text-white hover:bg-rose-500 active:scale-[0.98]"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
