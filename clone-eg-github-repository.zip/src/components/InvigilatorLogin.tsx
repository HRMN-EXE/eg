import { useState, type FormEvent } from "react";
import {
  AlertCircle,
  ArrowLeft,
  ArrowRight,
  Eye,
  EyeOff,
  Loader2,
  Lock,
  UserRound,
} from "lucide-react";
import { supabase } from "../lib/supabase";

interface InvigilatorLoginProps {
  onBack: () => void;
  onAuthenticated: (name: string) => void;
}

const fieldBase =
  "h-12 w-full rounded-xl border bg-neutral-50 pl-11 pr-4 text-[14px] font-bold text-neutral-900 outline-none transition-all placeholder:font-medium placeholder:text-neutral-400 focus:bg-white focus:ring-4";

export default function InvigilatorLogin({ onBack, onAuthenticated }: InvigilatorLoginProps) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [checking, setChecking] = useState(false);
  const [shake, setShake] = useState(false);

  const fail = (msg: string) => {
    setError(msg);
    setShake(true);
    window.setTimeout(() => setShake(false), 500);
  };

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (checking) return;
    setError(null);

    if (!username.trim() || !password) {
      fail("Enter your username and password.");
      return;
    }

    setChecking(true);
    const email = `${username.trim().toLowerCase()}@staff.chm.local`;
    const { error: authErr } = await supabase.auth.signInWithPassword({ email, password });
    if (authErr) {
      setChecking(false);
      fail("Invalid username or password");
      return;
    }

    // Must be an invigilator account — anything else is bounced identically.
    const { data: session } = await supabase.auth.getSession();
    const uid = session.session?.user.id;
    const { data: profile, error: profErr } = await supabase
      .from("profiles")
      .select("full_name, role")
      .eq("id", uid ?? "")
      .maybeSingle();

    if (profErr || !profile || profile.role !== "invigilator") {
      await supabase.auth.signOut();
      setChecking(false);
      fail("Invalid username or password");
      return;
    }

    onAuthenticated(profile.full_name ?? username.trim());
  };

  const ring = error
    ? "border-rose-300 focus:border-rose-400 focus:ring-rose-100"
    : "border-neutral-200 focus:border-rose-300 focus:ring-rose-100";

  return (
    <div className="relative z-10 mx-auto flex min-h-dvh w-full max-w-[560px] flex-col justify-center px-5 py-10 sm:px-6">
      <button
        type="button"
        onClick={onBack}
        className="animate-rise mx-auto mb-6 flex items-center gap-2 text-[12.5px] font-extrabold text-neutral-500 transition-colors hover:text-rose-500"
      >
        <ArrowLeft className="h-4 w-4" strokeWidth={2.6} />
        Back to portal
      </button>

      <section className="animate-rise overflow-hidden rounded-[26px] bg-white shadow-[0_28px_60px_-22px_rgba(190,80,115,0.4)]" style={{ animationDelay: "60ms" }}>
        <div className="h-[6px] w-full bg-gradient-to-r from-amber-400 via-rose-400 to-violet-400" />

        <div className="px-6 pb-7 pt-7 lg:px-7">
          <div className="flex items-center gap-4">
            <span className="h-px flex-1 bg-neutral-200/90" />
            <span className="text-[10px] font-bold tracking-[0.24em] text-neutral-400">EXAM HALL STAFF</span>
            <span className="h-px flex-1 bg-neutral-200/90" />
          </div>

          <h1 className="mt-5 text-center text-[26px] font-extrabold tracking-tight text-neutral-950">
            Invigilator Login
          </h1>
          <p className="mt-1.5 text-center text-[12.5px] font-medium text-neutral-500">
            Approve check-ins and monitor your assigned exam rooms.
          </p>

          <form onSubmit={submit} className={shake ? "animate-shake mt-6" : "mt-6"} noValidate>
            <label className="relative block">
              <span className="sr-only">Username</span>
              <UserRound className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-neutral-400" strokeWidth={2.2} />
              <input
                type="text"
                autoComplete="username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Username · e.g. inv1"
                className={fieldBase + " " + ring}
              />
            </label>

            <label className="relative mt-3 block">
              <span className="sr-only">Password</span>
              <Lock className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-neutral-400" strokeWidth={2.2} />
              <input
                type={showPw ? "text" : "password"}
                autoComplete="current-password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Password"
                className={fieldBase + " pr-12 " + ring}
              />
              <button
                type="button"
                onClick={() => setShowPw((s) => !s)}
                aria-label={showPw ? "Hide password" : "Show password"}
                className="absolute right-3 top-1/2 flex h-7 w-7 -translate-y-1/2 items-center justify-center rounded-lg text-neutral-400 transition-colors hover:bg-neutral-100 hover:text-neutral-600"
              >
                {showPw ? <EyeOff className="h-4 w-4" strokeWidth={2.2} /> : <Eye className="h-4 w-4" strokeWidth={2.2} />}
              </button>
            </label>

            {error && (
              <p className="animate-rise mt-3 flex items-center gap-1.5 text-[12px] font-bold text-rose-500">
                <AlertCircle className="h-3.5 w-3.5 shrink-0" strokeWidth={2.4} />
                {error}
              </p>
            )}

            <button
              type="submit"
              disabled={checking}
              className="group relative mt-5 flex h-14 w-full items-center justify-center gap-2.5 overflow-hidden rounded-2xl bg-neutral-950 px-5 text-white shadow-[0_16px_32px_-12px_rgba(0,0,0,0.55)] transition-all duration-200 hover:shadow-[0_20px_38px_-12px_rgba(0,0,0,0.65)] active:scale-[0.98] disabled:cursor-default"
            >
              <span className="pointer-events-none absolute inset-y-0 -left-1/2 w-1/3 -skew-x-12 bg-white/10 opacity-0 transition-all duration-700 ease-out group-hover:left-[130%] group-hover:opacity-100" />
              <span className="relative truncate text-[15px] font-semibold tracking-tight">
                {checking ? "Checking…" : "Invigilator Login"}
              </span>
              <span className="relative flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-white/15 transition-all duration-200 group-hover:translate-x-0.5 group-hover:bg-white/25">
                {checking ? <Loader2 className="h-4 w-4 animate-spin" /> : <ArrowRight className="h-4 w-4" strokeWidth={2.5} />}
              </span>
            </button>
          </form>

          <p className="mt-5 text-center text-[11px] font-medium leading-relaxed text-neutral-500">
            Accounts are issued by the Controller of Exams. Contact the office if you cannot sign in.
          </p>
        </div>
      </section>
    </div>
  );
}
