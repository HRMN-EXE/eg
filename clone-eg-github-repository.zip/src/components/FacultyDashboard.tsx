import { useCallback, useEffect, useMemo, useState } from "react";
import {
  AlertTriangle,
  ArrowRight,
  CalendarDays,
  CheckCircle2,
  Clock,
  Eye,
  EyeOff,
  Hourglass,
  Loader2,
  Lock,
  LogOut,
  Pencil,
  Plus,
  RefreshCw,
  Search,
  Timer,
  Trash2,
  Users,
} from "lucide-react";
import {
  deleteDraftExam,
  fetchFacultyExams,
  fetchFacultyServerTime,
  unlockExam,
  type FacultyExam,
} from "../lib/facultyApi";

type Notify = (kind: "success" | "info" | "error", msg: string) => void;

export interface FacultyResultsTarget {
  id: string;
  title: string;
  course_code: string;
}

interface FacultyDashboardProps {
  fullName: string;
  onCreate: () => void;
  onSignOut: () => void;
  onViewResults: (exam: FacultyResultsTarget) => void;
  onEdit: (examId: string) => void;
  onNotify: Notify;
}

type ExamState = "draft" | "scheduled" | "live" | "over";
type Filter = "all" | ExamState;

const STATE_META: Record<ExamState, { label: string; pill: string }> = {
  draft: { label: "Draft", pill: "bg-pink-200 text-pink-700" },
  scheduled: { label: "Scheduled", pill: "bg-amber-100 text-amber-700" },
  live: { label: "Live", pill: "bg-emerald-100 text-emerald-700" },
  over: { label: "Over", pill: "bg-neutral-200 text-neutral-600" },
};

const card = "rounded-[24px] bg-white p-5 shadow-[0_18px_40px_-22px_rgba(190,80,115,0.45)]";

const fmtWindow = (e: FacultyExam) => {
  const d = new Date(e.starts_at);
  const day = d.toLocaleDateString("en-GB", { weekday: "short", day: "numeric", month: "short" });
  const t = (dt: Date) => dt.toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" });
  const end = e.ends_at ? new Date(e.ends_at) : new Date(d.getTime() + (e.duration_min ?? 0) * 60_000);
  return `${day}, ${t(d)}–${t(end)}`;
};

export default function FacultyDashboard({ fullName, onCreate, onSignOut, onViewResults, onEdit, onNotify }: FacultyDashboardProps) {
  const [exams, setExams] = useState<FacultyExam[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState(false);
  const [offset, setOffset] = useState(0);
  const [, setTick] = useState(0);
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<Filter>("all");
  const [confirmDelete, setConfirmDelete] = useState<FacultyExam | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [deleteError, setDeleteError] = useState<string | null>(null);
  const [unlockTarget, setUnlockTarget] = useState<FacultyExam | null>(null);
  const [unlockPass, setUnlockPass] = useState("");
  const [unlockShow, setUnlockShow] = useState(false);
  const [unlockBusy, setUnlockBusy] = useState(false);
  const [unlockError, setUnlockError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setLoadError(false);
    const [examsRes, timeRes] = await Promise.all([fetchFacultyExams(), fetchFacultyServerTime()]);
    if (examsRes.error) {
      setLoadError(true);
      setExams([]);
    } else {
      setExams(examsRes.data);
      if (timeRes.data) setOffset(new Date(timeRes.data).getTime() - Date.now());
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  // Re-derive live/scheduled/over every 30s against the server clock.
  useEffect(() => {
    const t = window.setInterval(() => setTick((x) => x + 1), 30_000);
    return () => window.clearInterval(t);
  }, []);

  const now = Date.now() + offset;

  const stateOf = (e: FacultyExam): ExamState => {
    if (e.status === "draft") return "draft";
    const s = new Date(e.starts_at).getTime();
    const en = e.ends_at ? new Date(e.ends_at).getTime() : s + (e.duration_min ?? 0) * 60_000;
    if (now < s) return "scheduled";
    if (now <= en) return "live";
    return "over";
  };

  const counts = useMemo(() => {
    const c: Record<Filter, number> = { all: exams.length, draft: 0, scheduled: 0, live: 0, over: 0 };
    exams.forEach((e) => (c[stateOf(e)] += 1));
    return c;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [exams, now]);

  const shown = useMemo(() => {
    const q = query.trim().toLowerCase();
    return exams.filter((e) => {
      const match = !q || e.title.toLowerCase().includes(q) || e.course_code.toLowerCase().includes(q);
      return match && (filter === "all" || stateOf(e) === filter);
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [exams, query, filter, now]);

  const doUnlock = async () => {
    if (!unlockTarget || unlockBusy || !unlockPass) return;
    setUnlockBusy(true);
    setUnlockError(null);
    const { data, error } = await unlockExam(unlockTarget.id, unlockPass);
    setUnlockBusy(false);
    setUnlockPass(""); // never retain the passphrase
    if (error) {
      setUnlockError(error.message);
      return;
    }
    if (!data?.ok) {
      setUnlockError(
        data?.reason === "too_many_attempts"
          ? "Too many wrong attempts. Try again in 15 minutes."
          : "Wrong passphrase.",
      );
      return;
    }
    setUnlockTarget(null);
    onNotify("success", "Exam unlocked. It is a draft again.");
    void load();
  };

  const doDelete = async () => {
    if (!confirmDelete || deleting) return;
    setDeleting(true);
    setDeleteError(null);
    const { error } = await deleteDraftExam(confirmDelete.id);
    setDeleting(false);
    if (error) {
      setDeleteError(error.message);
      return;
    }
    onNotify("success", `Draft "${confirmDelete.course_code}" deleted`);
    setExams((list) => list.filter((x) => x.id !== confirmDelete.id));
    setConfirmDelete(null);
  };

  const filters: { key: Filter; label: string }[] = [
    { key: "all", label: "All" },
    { key: "draft", label: "Draft" },
    { key: "scheduled", label: "Scheduled" },
    { key: "live", label: "Live" },
    { key: "over", label: "Over" },
  ];

  return (
    <div className="relative z-10 mx-auto w-full max-w-[1040px] px-4 pb-28 pt-6 sm:px-6">
      {/* ---------- top bar ---------- */}
      <header className="animate-rise mx-auto flex w-full max-w-[1040px] items-center gap-3">
        <div className="min-w-0 flex-1">
          <h1 className="text-[28px] font-extrabold leading-none tracking-tight text-neutral-950 sm:text-[32px]">Exams</h1>
          <p className="mt-1.5 truncate text-[12px] font-semibold text-neutral-600">Signed in as {fullName}</p>
        </div>
        <button
          type="button"
          onClick={onSignOut}
          className="flex h-11 shrink-0 items-center gap-1.5 rounded-full bg-white px-4 text-[12.5px] font-extrabold text-rose-500 shadow-[0_8px_20px_-10px_rgba(190,80,115,0.4)] transition-all hover:-translate-y-0.5 hover:bg-rose-50 active:scale-[0.98]"
        >
          <LogOut className="h-4 w-4 -scale-x-100" strokeWidth={2.4} />
          <span className="hidden sm:inline">Sign out</span>
        </button>
      </header>

      {/* ---------- search + filters ---------- */}
      <div className="animate-rise mt-5" style={{ animationDelay: "60ms" }}>
        <label className="relative block">
          <Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-neutral-400" strokeWidth={2.2} />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search by title or course code…"
            className="h-12 w-full rounded-full bg-white pl-11 pr-4 text-[13px] font-bold text-neutral-800 shadow-[0_10px_26px_-14px_rgba(190,80,115,0.4)] outline-none transition-all placeholder:font-medium placeholder:text-neutral-400 focus:ring-4 focus:ring-fuchsia-100"
          />
        </label>
        <div className="mt-3 flex flex-wrap gap-2">
          {filters.map((f) => {
            const active = filter === f.key;
            return (
              <button
                key={f.key}
                type="button"
                onClick={() => setFilter(f.key)}
                className={
                  "flex min-h-11 items-center gap-2 rounded-full px-4 text-[12px] font-extrabold transition-all duration-200 active:scale-95 " +
                  (active
                    ? "bg-neutral-900 text-white shadow-[0_10px_22px_-10px_rgba(0,0,0,0.6)]"
                    : "bg-white/80 text-neutral-600 shadow-[0_6px_16px_-8px_rgba(190,80,115,0.3)] hover:bg-white")
                }
              >
                {f.label}
                <span className={"rounded-full px-1.5 text-[10.5px] " + (active ? "bg-white/20" : "bg-neutral-200/80")}>
                  {counts[f.key]}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* ---------- list ---------- */}
      <div className="mt-5 grid grid-cols-1 gap-4 lg:grid-cols-2">
        {loading &&
          [0, 1, 2, 3].map((n) => (
            <div key={n} className="animate-pulse rounded-[24px] bg-white/70 p-5">
              <div className="flex justify-between">
                <span className="h-6 w-24 rounded-full bg-neutral-200" />
                <span className="h-6 w-16 rounded-full bg-neutral-100" />
              </div>
              <span className="mt-4 block h-5 w-3/4 rounded-lg bg-neutral-200" />
              <span className="mt-2 block h-4 w-1/2 rounded-lg bg-neutral-100" />
              <div className="mt-4 flex gap-2">
                <span className="h-7 w-20 rounded-full bg-neutral-100" />
                <span className="h-7 w-20 rounded-full bg-neutral-100" />
              </div>
            </div>
          ))}

        {!loading && loadError && (
          <div className="col-span-full animate-rise flex flex-col items-center gap-4 rounded-[24px] bg-white p-10 text-center shadow-[0_20px_44px_-22px_rgba(190,80,115,0.45)]">
            <span className="flex h-12 w-12 items-center justify-center rounded-full bg-rose-100">
              <AlertTriangle className="h-6 w-6 text-rose-500" strokeWidth={2.2} />
            </span>
            <p className="text-[14px] font-extrabold text-neutral-900">Could not load your exams. Try again.</p>
            <button
              type="button"
              onClick={() => void load()}
              className="flex h-11 items-center gap-2 rounded-full bg-neutral-950 px-5 text-[12.5px] font-extrabold text-white transition-all hover:-translate-y-0.5 hover:bg-neutral-800 active:scale-[0.98]"
            >
              <RefreshCw className="h-4 w-4" strokeWidth={2.4} />
              Retry
            </button>
          </div>
        )}

        {!loading && !loadError && exams.length === 0 && (
          <div className="col-span-full animate-rise flex flex-col items-center gap-4 rounded-[24px] bg-white/70 p-10 text-center">
            <p className="text-[14px] font-extrabold text-neutral-700">You have no exams yet</p>
            <button
              type="button"
              onClick={onCreate}
              className="flex h-11 items-center gap-2 rounded-full bg-neutral-950 px-5 text-[12.5px] font-extrabold text-white transition-all hover:-translate-y-0.5 hover:bg-neutral-800 active:scale-[0.98]"
            >
              <Plus className="h-4 w-4" strokeWidth={2.6} />
              Create your first exam
            </button>
          </div>
        )}

        {!loading && !loadError && exams.length > 0 && shown.length === 0 && (
          <p className="col-span-full animate-rise rounded-[24px] bg-white/70 p-8 text-center text-[13px] font-semibold text-neutral-500">
            No exams match.
          </p>
        )}

        {!loading &&
          !loadError &&
          shown.map((e, i) => {
            const st = stateOf(e);
            const meta = STATE_META[st];
            const qCount = e.questions?.[0]?.count ?? null;
            const cohorts = e.exam_cohorts ?? [];
            return (
              <article
                key={e.id}
                className={card + " animate-rise flex flex-col transition-all duration-300 hover:-translate-y-1 hover:shadow-[0_26px_52px_-22px_rgba(190,80,115,0.55)]"}
                style={{ animationDelay: `${80 + i * 50}ms` }}
              >
                <div className="flex items-center justify-between gap-3">
                  <span className="flex min-w-0 items-center gap-2">
                    <span className={"shrink-0 rounded-full px-3 py-1.5 text-[10.5px] font-extrabold tracking-wide " + meta.pill}>
                      {meta.label.toUpperCase()}
                    </span>
                    {st === "over" && (
                      <span
                        className={
                          "shrink-0 rounded-full px-2.5 py-1.5 text-[10px] font-extrabold tracking-wide " +
                          (e.results_published
                            ? "bg-emerald-50 text-emerald-600 ring-1 ring-emerald-200"
                            : "bg-amber-100 text-amber-700 ring-1 ring-amber-200")
                        }
                      >
                        {e.results_published ? "Released" : "Not released"}
                      </span>
                    )}
                  </span>
                  <span className="rounded-full bg-neutral-100 px-3 py-1.5 text-[10.5px] font-extrabold tracking-wide text-neutral-500">
                    {e.course_code}
                  </span>
                </div>

                <h3 className="mt-3 text-[17px] font-extrabold leading-snug tracking-tight text-neutral-950">{e.title}</h3>

                <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1.5 text-[11.5px] font-bold text-neutral-600">
                  <span className="flex items-center gap-1.5">
                    <CalendarDays className="h-3.5 w-3.5 text-neutral-400" strokeWidth={2.3} />
                    {e.starts_at ? fmtWindow(e) : "Not scheduled yet"}
                  </span>
                  <span className="flex items-center gap-1.5">
                    <Timer className="h-3.5 w-3.5 text-neutral-400" strokeWidth={2.3} />
                    {e.duration_min ?? "—"} min
                  </span>
                  {qCount != null && (
                    <span className="flex items-center gap-1.5">
                      <CheckCircle2 className="h-3.5 w-3.5 text-neutral-400" strokeWidth={2.3} />
                      {qCount} question{qCount === 1 ? "" : "s"}
                    </span>
                  )}
                </div>

                {cohorts.length > 0 && (
                  <div className="mt-3 flex flex-wrap gap-1.5">
                    {cohorts.map((c, ci) => (
                      <span
                        key={ci}
                        className="flex items-center gap-1 rounded-full bg-violet-100 px-2.5 py-1 text-[10px] font-extrabold text-violet-700"
                      >
                        <Users className="h-3 w-3" strokeWidth={2.4} />
                        Year {c.year ?? "—"} - {c.department ?? "all departments"}
                      </span>
                    ))}
                  </div>
                )}

                <div className="mt-4 border-t border-neutral-100 pt-4">
                  {st === "draft" && (
                    <div className="flex items-center gap-2.5">
                      <button
                        type="button"
                        onClick={() => onEdit(e.id)}
                        className="flex h-11 flex-1 items-center justify-center gap-2 rounded-full bg-[#f3ede7] text-[12.5px] font-extrabold text-neutral-700 transition-all hover:-translate-y-0.5 hover:bg-[#efe6dd] active:scale-[0.98]"
                      >
                        <Pencil className="h-4 w-4" strokeWidth={2.3} />
                        Edit
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setDeleteError(null);
                          setConfirmDelete(e);
                        }}
                        className="flex h-11 items-center justify-center gap-2 rounded-full bg-white px-4 text-[12.5px] font-extrabold text-rose-500 ring-1 ring-rose-200 transition-all hover:bg-rose-50 active:scale-[0.98]"
                      >
                        <Trash2 className="h-4 w-4" strokeWidth={2.3} />
                        Delete draft
                      </button>
                    </div>
                  )}
                  {st === "scheduled" && (() => {
                    const startMs = new Date(e.starts_at).getTime();
                    const unlockable = startMs - now > 5 * 60_000;
                    return (
                      <div>
                        <div className="flex items-center gap-2.5">
                          <span className="flex items-center gap-2 text-[11.5px] font-bold text-neutral-500">
                            <Hourglass className="h-4 w-4 text-amber-500" strokeWidth={2.3} />
                            Locked.
                          </span>
                          <button
                            type="button"
                            disabled={!unlockable}
                            onClick={() => {
                              setUnlockPass("");
                              setUnlockError(null);
                              setUnlockTarget(e);
                            }}
                            className={
                              "ml-auto flex h-11 items-center gap-1.5 rounded-full px-4 text-[12px] font-extrabold transition-all " +
                              (unlockable
                                ? "bg-white text-fuchsia-700 ring-1 ring-fuchsia-200 hover:-translate-y-0.5 hover:bg-fuchsia-50 active:scale-[0.98]"
                                : "cursor-not-allowed bg-neutral-100 text-neutral-400")
                            }
                          >
                            <Lock className="h-3.5 w-3.5" strokeWidth={2.4} />
                            Unlock
                          </button>
                        </div>
                        {!unlockable && (
                          <p className="mt-1.5 text-[10.5px] font-semibold text-neutral-400">
                            Too close to the start time to unlock
                          </p>
                        )}
                      </div>
                    );
                  })()}
                  {st === "live" && (
                    <p className="flex items-center gap-2 text-[11.5px] font-bold text-emerald-700">
                      <Clock className="h-4 w-4" strokeWidth={2.3} />
                      Exam in progress. Results stay hidden until the exam is over.
                    </p>
                  )}
                  {st === "over" && (
                    <button
                      type="button"
                      onClick={() => onViewResults({ id: e.id, title: e.title, course_code: e.course_code })}
                      className="group flex h-12 w-full items-center justify-center gap-2 rounded-full bg-fuchsia-800 text-[13px] font-extrabold text-white shadow-[0_14px_30px_-12px_rgba(134,25,143,0.65)] transition-all hover:-translate-y-0.5 hover:bg-fuchsia-700 active:scale-[0.98]"
                    >
                      View results
                      <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" strokeWidth={2.6} />
                    </button>
                  )}
                </div>
              </article>
            );
          })}
      </div>

      {/* ---------- delete confirm ---------- */}
      {confirmDelete && (
        <div className="fixed inset-0 z-40 flex items-end justify-center bg-neutral-950/45 p-5 backdrop-blur-sm sm:items-center" onClick={() => !deleting && setConfirmDelete(null)}>
          <div className="animate-pop w-full max-w-[400px] rounded-[24px] bg-white p-6 shadow-[0_30px_70px_-20px_rgba(0,0,0,0.55)]" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center gap-3">
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-rose-100">
                <Trash2 className="h-5 w-5 text-rose-600" strokeWidth={2.2} />
              </span>
              <h3 className="text-[16px] font-extrabold text-neutral-900">Delete this draft?</h3>
            </div>
            <p className="mt-3 text-[12.5px] font-medium leading-relaxed text-neutral-600">
              <span className="font-extrabold text-neutral-800">{confirmDelete.title}</span> ({confirmDelete.course_code}) will be
              permanently removed. This cannot be undone.
            </p>
            {deleteError && (
              <p className="animate-rise mt-3 rounded-xl bg-rose-50 px-3.5 py-2.5 text-[12px] font-bold text-rose-600 ring-1 ring-rose-200">
                {deleteError}
              </p>
            )}
            <div className="mt-5 flex gap-3">
              <button
                type="button"
                onClick={() => setConfirmDelete(null)}
                disabled={deleting}
                className="flex-1 rounded-2xl bg-neutral-100 py-3 text-[13px] font-extrabold text-neutral-700 transition-colors hover:bg-neutral-200 disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => void doDelete()}
                disabled={deleting}
                className="flex flex-1 items-center justify-center gap-2 rounded-2xl bg-rose-600 py-3 text-[13px] font-extrabold text-white transition-all hover:bg-rose-500 active:scale-[0.98] disabled:opacity-60"
              >
                {deleting && <RefreshCw className="h-4 w-4 animate-spin" strokeWidth={2.4} />}
                Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ---------- unlock dialog ---------- */}
      {unlockTarget && (
        <div
          className="fixed inset-0 z-40 flex items-end justify-center bg-neutral-950/45 p-5 backdrop-blur-sm sm:items-center"
          onClick={() => !unlockBusy && setUnlockTarget(null)}
        >
          <div
            className="animate-pop w-full max-w-[400px] rounded-[24px] bg-white p-6 shadow-[0_30px_70px_-20px_rgba(0,0,0,0.55)]"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-3">
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-violet-100">
                <Lock className="h-5 w-5 text-violet-700" strokeWidth={2.2} />
              </span>
              <h3 className="min-w-0 flex-1 truncate text-[16px] font-extrabold text-neutral-900">
                Unlock {unlockTarget.course_code}?
              </h3>
            </div>
            <p className="mt-3 text-[12.5px] font-medium leading-relaxed text-neutral-600">
              Unlocking returns this exam to draft. It is only possible before any student has checked in.
            </p>

            <label className="relative mt-4 block">
              <span className="text-[11px] font-extrabold tracking-[0.12em] text-neutral-500">PASSPHRASE</span>
              <input
                type={unlockShow ? "text" : "password"}
                value={unlockPass}
                autoFocus
                onChange={(e) => {
                  setUnlockPass(e.target.value);
                  setUnlockError(null);
                }}
                placeholder="Enter the lock passphrase"
                className="mt-2 h-12 w-full rounded-2xl border border-transparent bg-[#f3ede7] pl-4 pr-12 text-[13.5px] font-bold text-neutral-900 outline-none transition-all placeholder:font-medium placeholder:text-neutral-400 focus:border-rose-300 focus:bg-white focus:ring-4 focus:ring-rose-100"
              />
              <button
                type="button"
                aria-label={unlockShow ? "Hide passphrase" : "Show passphrase"}
                onClick={() => setUnlockShow((s) => !s)}
                className="absolute bottom-2 right-3 flex h-8 w-8 items-center justify-center rounded-full text-neutral-500 transition-colors hover:bg-neutral-200/60"
              >
                {unlockShow ? <EyeOff className="h-4 w-4" strokeWidth={2.1} /> : <Eye className="h-4 w-4" strokeWidth={2.1} />}
              </button>
            </label>

            {unlockError && (
              <p className="animate-rise mt-3 rounded-xl bg-rose-50 px-3.5 py-2.5 text-[12px] font-bold text-rose-600 ring-1 ring-rose-200">
                {unlockError}
              </p>
            )}

            <div className="mt-5 flex gap-3">
              <button
                type="button"
                onClick={() => setUnlockTarget(null)}
                disabled={unlockBusy}
                className="flex-1 rounded-2xl bg-neutral-100 py-3 text-[13px] font-extrabold text-neutral-700 transition-colors hover:bg-neutral-200 disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => void doUnlock()}
                disabled={unlockBusy || !unlockPass}
                className="flex flex-1 items-center justify-center gap-2 rounded-2xl bg-neutral-950 py-3 text-[13px] font-extrabold text-white transition-all hover:bg-neutral-800 active:scale-[0.98] disabled:opacity-50"
              >
                {unlockBusy && <Loader2 className="h-4 w-4 animate-spin" strokeWidth={2.4} />}
                Unlock
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ---------- floating new-exam action ---------- */}
      <button
        type="button"
        onClick={onCreate}
        aria-label="New exam"
        className="group fixed bottom-20 right-5 z-40 flex h-16 w-16 items-center justify-center rounded-full bg-neutral-950 shadow-[0_18px_40px_-12px_rgba(0,0,0,0.65)] transition-all duration-200 hover:-translate-y-1 hover:scale-110 hover:bg-neutral-800 hover:shadow-[0_26px_52px_-12px_rgba(0,0,0,0.75)] active:scale-95 sm:right-8"
      >
        <span className="pointer-events-none absolute inset-0 rounded-full ring-2 ring-white/25 transition-all duration-300 group-hover:scale-[1.35] group-hover:opacity-0" />
        <Plus className="h-7 w-7 text-white transition-transform duration-300 group-hover:rotate-90" strokeWidth={3} />
      </button>
    </div>
  );
}
