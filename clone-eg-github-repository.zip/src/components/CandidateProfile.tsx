import { ArrowLeft, ArrowRight, GraduationCap, Hash, IdCard, School, UserRound } from "lucide-react";

export interface Profile {
  fullName: string;
  rollNo: string;
  degree: string;
  year: string;
}

interface CandidateProfileProps {
  /** The verified profile loaded at login — displayed read-only. */
  profile: Profile | null;
  onBack: () => void;
  onContinue: () => void;
}

const card = "rounded-[26px] bg-white p-5 shadow-[0_20px_44px_-22px_rgba(190,80,115,0.45)]";

export default function CandidateProfile({ profile, onBack, onContinue }: CandidateProfileProps) {
  const rows = [
    { icon: UserRound, tint: "bg-pink-100 text-pink-600", label: "FULL NAME", value: profile?.fullName || "—" },
    { icon: Hash, tint: "bg-amber-100 text-amber-600", label: "ROLL NUMBER", value: profile?.rollNo || "—" },
    { icon: School, tint: "bg-violet-100 text-violet-700", label: "COURSE", value: profile?.degree || "—" },
    { icon: GraduationCap, tint: "bg-emerald-100 text-emerald-600", label: "YEAR", value: profile?.year || "—" },
  ];

  return (
    <div className="relative z-10 mx-auto flex min-h-dvh w-full max-w-[560px] flex-col px-5 pb-10 pt-6 sm:px-6">
      {/* ---------- top bar ---------- */}
      <header className="animate-rise relative z-30 flex items-center gap-3">
        <button
          type="button"
          onClick={onBack}
          aria-label="Back to exam list"
          className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full text-neutral-800 transition-all hover:-translate-x-0.5 hover:bg-white/70 hover:text-rose-500 active:scale-95"
        >
          <ArrowLeft className="h-5 w-5" strokeWidth={2.6} />
        </button>
        <h1 className="min-w-0 flex-1 truncate text-[19px] font-extrabold tracking-tight text-neutral-900">
          Your details
        </h1>
      </header>

      {/* ---------- heading ---------- */}
      <div className="animate-rise mt-8" style={{ animationDelay: "70ms" }}>
        <p className="flex items-center gap-1.5 text-[11px] font-extrabold tracking-[0.18em] text-fuchsia-600">
          <IdCard className="h-3.5 w-3.5" strokeWidth={2.4} />
          BEFORE YOU BEGIN
        </p>
        <h2 className="mt-2 text-[32px] font-extrabold leading-tight tracking-tight text-neutral-950 sm:text-[38px]">
          Check these match your ID card
        </h2>
      </div>

      {/* ---------- details card ---------- */}
      <section className={"animate-rise mt-6 " + card} style={{ animationDelay: "140ms" }}>
        <div className="flex flex-col gap-2.5">
          {rows.map((r) => (
            <div key={r.label} className="flex items-center gap-3.5 rounded-2xl bg-[#f3ede7] px-4 py-3.5">
              <span className={"flex h-10 w-10 shrink-0 items-center justify-center rounded-full " + r.tint}>
                <r.icon className="h-[18px] w-[18px]" strokeWidth={2.2} />
              </span>
              <div className="min-w-0">
                <p className="text-[9.5px] font-extrabold tracking-[0.14em] text-neutral-500">{r.label}</p>
                <p className="mt-0.5 truncate text-[14.5px] font-extrabold text-neutral-900">{r.value}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ---------- invigilator note ---------- */}
      <p
        className="animate-rise mt-5 text-center text-[13px] font-semibold leading-relaxed text-neutral-600"
        style={{ animationDelay: "200ms" }}
      >
        Show your ID card to the invigilator. If anything here is wrong, tell the invigilator.
        You cannot edit these details.
      </p>

      {/* ---------- continue ---------- */}
      <button
        type="button"
        onClick={onContinue}
        className="animate-rise group mt-7 flex h-[56px] w-full items-center justify-center gap-2.5 rounded-full bg-neutral-950 text-[15px] font-extrabold text-white shadow-[0_22px_44px_-16px_rgba(0,0,0,0.6)] transition-all duration-300 hover:-translate-y-0.5 hover:bg-neutral-800 active:scale-[0.99]"
        style={{ animationDelay: "260ms" }}
      >
        Continue
        <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" strokeWidth={2.6} />
      </button>
    </div>
  );
}
