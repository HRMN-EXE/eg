import { useCallback, useEffect, useRef, useState, type FormEvent } from "react";
import {
  AlertCircle,
  ArrowRight,
  ClipboardCheck,
  Eye,
  EyeOff,
  GraduationCap,
  HelpCircle,
  Loader2,
  Lock,
  MessageCircleMore,
  Star,
  UserRound,
} from "lucide-react";
import { type Exam, type ExamResult } from "./data/exams";
import { loginStudent, logoutStudent } from "./lib/studentAuth";
import {
  fetchAnswersForAttempt,
  fetchQuestionsForAttempt,
  fetchServerTime,
  requestCheckin,
  startAttempt,
  type DbExamSession,
} from "./lib/examApi";
import WaitingRoom from "./components/WaitingRoom";
import InvigilatorLogin from "./components/InvigilatorLogin";
import InvigilatorPanel from "./components/InvigilatorPanel";
import ExamFlow from "./components/ExamFlow";
import ExamWizard from "./components/ExamWizard";
import ExamList from "./components/ExamList";
import ExamRules from "./components/ExamRules";
import FacultyDashboard from "./components/FacultyDashboard";
import FacultyLogin from "./components/FacultyLogin";
import FacultyResults from "./components/FacultyResults";
import { signOutFaculty } from "./lib/facultyApi";
import CandidateProfile, { type Profile } from "./components/CandidateProfile";

/** Verified candidate profiles persist locally so a returning candidate
 *  resumes with their locked details intact (until they sign out). */
const PROFILE_KEY = "examportal.profile";

const loadProfile = (): Profile | null => {
  try {
    const raw = localStorage.getItem(PROFILE_KEY);
    return raw ? (JSON.parse(raw) as Profile) : null;
  } catch {
    return null;
  }
};

const saveProfile = (p: Profile | null) => {
  try {
    if (p) localStorage.setItem(PROFILE_KEY, JSON.stringify(p));
    else localStorage.removeItem(PROFILE_KEY);
  } catch {
    /* storage unavailable — session-only profile */
  }
};

/* ------------------------------------------------------------------ */
/*  Small building blocks                                              */
/* ------------------------------------------------------------------ */

function SessionBadge() {
  return (
    <div className="animate-rise flex items-center gap-2 rounded-full bg-white/85 px-4 py-2 shadow-[0_4px_16px_-4px_rgba(180,110,90,0.25)] backdrop-blur-sm">
      <span className="relative flex h-2.5 w-2.5">
        <span className="animate-ring absolute inline-flex h-full w-full rounded-full bg-emerald-400" />
        <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-emerald-500" />
      </span>
      <span className="text-[10.5px] font-bold tracking-[0.14em] text-neutral-600">SESSION ACTIVE</span>
      <span className="h-[3px] w-[3px] rounded-full bg-neutral-300" />
      <span className="text-[10.5px] font-bold tracking-[0.14em] text-neutral-400">SPRING MIDTERMS</span>
    </div>
  );
}

function LogoTile() {
  return (
    <div className="animate-floaty relative shrink-0">
      <div className="flex h-[86px] w-[86px] items-center justify-center rounded-[26px] bg-white shadow-[0_20px_45px_-14px_rgba(236,110,140,0.55)] lg:h-[104px] lg:w-[104px] lg:rounded-[30px]">
        <ClipboardCheck className="h-10 w-10 text-amber-500 lg:h-12 lg:w-12" strokeWidth={2.1} />
      </div>
      <span className="animate-twinkle absolute -right-2.5 -top-2.5 flex h-[26px] w-[26px] items-center justify-center rounded-full bg-rose-400 ring-4 ring-white/60 lg:h-[30px] lg:w-[30px]">
        <Star className="h-3 w-3 text-white lg:h-3.5 lg:w-3.5" fill="currentColor" strokeWidth={0} />
      </span>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Entry card                                                         */
/* ------------------------------------------------------------------ */

const fieldBase =
  "h-12 w-full rounded-xl border bg-neutral-50 pl-11 pr-4 text-[14px] font-bold text-neutral-900 outline-none transition-all placeholder:font-medium placeholder:text-neutral-400 focus:bg-white focus:ring-4";

function EntryCard({
  profile,
  onAuthenticated,
  onHelp,
}: {
  profile: Profile | null;
  onAuthenticated: (profile: Profile) => void;
  onHelp: () => void;
}) {
  const [username, setUsername] = useState(profile?.rollNo ?? "");
  const [password, setPassword] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [checking, setChecking] = useState(false);
  const [shake, setShake] = useState(false);

  const fail = () => {
    setShake(true);
    window.setTimeout(() => setShake(false), 500);
  };

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (checking) return;
    setError(null);

    if (!username.trim() || !password) {
      setError("Enter your Student ID and password.");
      fail();
      return;
    }

    setChecking(true);
    const res = await loginStudent(username, password);
    if (res.ok) {
      onAuthenticated(res.profile);
    } else {
      setChecking(false);
      setError(res.reason === "format" ? "Enter your ID like BSCIT2025-0894" : "Invalid ID or password");
      fail();
    }
  };

  const ring = error ? "border-rose-300 focus:border-rose-400 focus:ring-rose-100" : "border-neutral-200 focus:border-rose-300 focus:ring-rose-100";

  return (
    <section className="animate-rise overflow-hidden rounded-[26px] bg-white shadow-[0_28px_60px_-22px_rgba(190,80,115,0.4)]">
      <div className="h-[6px] w-full bg-gradient-to-r from-amber-400 via-rose-400 to-violet-400" />

      <div className="px-6 pb-6 pt-7 lg:px-7">
        <div className="flex items-center gap-4">
          <span className="h-px flex-1 bg-neutral-200/90" />
          <span className="text-[10px] font-bold tracking-[0.24em] text-neutral-400">VERIFY IDENTITY</span>
          <span className="h-px flex-1 bg-neutral-200/90" />
        </div>

        <form onSubmit={submit} className={shake ? "animate-shake" : undefined} noValidate>
          {/* username */}
          <label className="relative mt-6 block">
            <span className="sr-only">Student ID</span>
            <UserRound className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-neutral-400" strokeWidth={2.2} />
            <input
              type="text"
              autoComplete="username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Student ID · e.g. BSCIT2025-0894"
              className={fieldBase + " " + ring}
            />
          </label>

          {/* password */}
          <label className="relative mt-3 block">
            <span className="sr-only">Password</span>
            <Lock className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-neutral-400" strokeWidth={2.2} />
            <input
              type={showPw ? "text" : "password"}
              autoComplete="current-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Password"
              className={fieldBase + " pr-12 " + ring}
            />
            <button
              type="button"
              onClick={() => setShowPw((s) => !s)}
              aria-label={showPw ? "Hide password" : "Show password"}
              className="absolute right-3 top-1/2 flex h-7 w-7 -translate-y-1/2 items-center justify-center rounded-lg text-neutral-400 transition-colors hover:bg-neutral-100 hover:text-neutral-600"
            >
              {showPw ? <EyeOff className="h-4 w-4" strokeWidth={2.2} /> : <Eye className="h-4 w-4" strokeWidth={2.2} />}
            </button>
          </label>

          {error && (
            <p className="animate-rise mt-3 flex items-center gap-1.5 text-[12px] font-bold text-rose-500">
              <AlertCircle className="h-3.5 w-3.5 shrink-0" strokeWidth={2.4} />
              {error}
            </p>
          )}

          {/* submit */}
          <button
            type="submit"
            disabled={checking}
            className="group relative mt-5 flex h-14 w-full items-center justify-center gap-2.5 overflow-hidden rounded-2xl bg-neutral-950 px-5 text-white shadow-[0_16px_32px_-12px_rgba(0,0,0,0.55)] transition-all duration-200 hover:shadow-[0_20px_38px_-12px_rgba(0,0,0,0.65)] active:scale-[0.98] disabled:cursor-default"
          >
            {/* shine sweep */}
            <span className="pointer-events-none absolute inset-y-0 -left-1/2 w-1/3 -skew-x-12 bg-white/10 opacity-0 transition-all duration-700 ease-out group-hover:left-[130%] group-hover:opacity-100" />

            <span className="relative truncate text-[15px] font-semibold tracking-tight">
              {checking ? "Verifying credentials…" : "Student Login"}
            </span>

            <span className="relative flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-white/15 transition-all duration-200 group-hover:translate-x-0.5 group-hover:bg-white/25">
              {checking ? <Loader2 className="h-4 w-4 animate-spin" /> : <ArrowRight className="h-4 w-4" strokeWidth={2.5} />}
            </span>
          </button>
        </form>

        <button
          type="button"
          onClick={onHelp}
          className="mt-4 flex w-full items-center justify-center gap-1.5 text-[11.5px] font-bold text-neutral-500 transition-colors hover:text-rose-500"
        >
          <HelpCircle className="h-3.5 w-3.5" strokeWidth={2.3} />
          Forgot credentials? Contact the Controller of Exams
        </button>

        {profile && (
          <p className="mt-3 text-center text-[11px] font-medium leading-relaxed text-neutral-500">
            Welcome back, <span className="font-bold text-neutral-700">{profile.fullName}</span> — your verified details are locked.
          </p>
        )}
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/*  App                                                                */
/* ------------------------------------------------------------------ */

type View =
  | "landing"
  | "dashboard"
  | "details"
  | "confirm"
  | "waiting"
  | "exam"
  | "faculty"
  | "faculty-dash"
  | "fac-wizard"
  | "faculty-results"
  | "inv-login"
  | "inv-panel";
type Toast = { id: number; kind: "success" | "info" | "error"; msg: string };

export default function App() {
  const [view, setView] = useState<View>("landing");
  const [profile, setProfile] = useState<Profile | null>(loadProfile);
  const [activeExam, setActiveExam] = useState<Exam | null>(null);
  // Live server-backed attempt (questions, deadline, clock offset, answers).
  const [dbSession, setDbSession] = useState<DbExamSession | null>(null);
  const [starting, setStarting] = useState(false);
  // Kept for the in-session exam engine (ExamFlow) plumbing; the exam list
  // itself now loads from Supabase.
  const [, setResults] = useState<Record<string, ExamResult>>({});
  const [toast, setToast] = useState<Toast | null>(null);
  const timers = useRef<number[]>([]);

  const showToast = useCallback((kind: Toast["kind"], msg: string) => {
    setToast({ id: Date.now(), kind, msg });
    timers.current.push(window.setTimeout(() => setToast(null), 3000));
  }, []);

  useEffect(() => {
    const t = timers.current;
    return () => t.forEach((id) => window.clearTimeout(id));
  }, []);

  const handleAuthenticated = useCallback(
    (p: Profile) => {
      setProfile(p);
      saveProfile(p);
      setView("dashboard");
      showToast("success", `Access granted — welcome, ${p.fullName.split(" ")[0] || "Student"}`);
    },
    [showToast],
  );

  const handleLoginHelp = useCallback(() => {
    showToast("info", "Credential resets are handled in person at the Controller of Exams office.");
  }, [showToast]);

  const [checkinBusy, setCheckinBusy] = useState(false);

  /* Ends the session and clears the stored profile for a clean handoff. */
  const handleSignOut = useCallback(() => {
    void logoutStudent();
    saveProfile(null);
    setProfile(null);
    setActiveExam(null);
    setView("landing");
    showToast("info", "Session ended — you have been signed out");
  }, [showToast]);

  /* "Take Exam" routes to the rules & confirmation gate first — but only if
     the exam is actually assigned to this student's cohort. */
  const handleStartExam = useCallback(
    (exam: Exam) => {
      const ym = profile?.year?.match(/(\d+)/);
      const yr = ym ? Number(ym[1]) : null;
      if (exam.cohortYears.length && yr !== null && !exam.cohortYears.includes(yr)) {
        showToast("error", `${exam.course} isn't assigned to your Year ${yr} cohort`);
        return;
      }
      setActiveExam(exam);
      setDbSession(null);
      setView("details");
    },
    [profile, showToast],
  );

  /* Rules + checklist accepted → ask the invigilator's desk for a check-in. */
  const handleRequestCheckin = useCallback(async () => {
    if (!activeExam || checkinBusy) return;
    setCheckinBusy(true);
    const { error } = await requestCheckin(activeExam.id);
    setCheckinBusy(false);
    if (error) {
      showToast("error", error.message);
      return;
    }
    setView("waiting");
  }, [activeExam, checkinBusy, showToast]);

  /** Accepting the rules starts (or resumes) the server attempt, then loads
      questions + saved answers + the server clock before entering the runner. */
  /** Returns true only when the runner actually opens, so the waiting room
      can stay put and surface failures in place. */
  const handleBeginExam = useCallback(async (): Promise<boolean> => {
    if (!activeExam || starting) return false;
    const isDb = activeExam.questions.length === 0 && !activeExam.questionCount;
    if (!isDb) {
      setView("exam");
      showToast("info", `${activeExam.course} started — ${activeExam.durationMin} minutes on the clock`);
      return true;
    }

    setStarting(true);
    const { data: attempt, error: startErr } = await startAttempt(activeExam.id);
    if (startErr || !attempt) {
      setStarting(false);
      showToast("error", startErr?.message ?? "This exam could not be started.");
      return false;
    }
    // Compare the deadline against SERVER time, not the client clock.
    const tFirst = await fetchServerTime();
    if (tFirst.error || !tFirst.data) {
      setStarting(false);
      showToast("error", "The exam could not be loaded. Return to the list and try again.");
      return false;
    }
    const serverNow = new Date(tFirst.data).getTime();
    if (
      attempt.status !== "in_progress" ||
      new Date(attempt.deadline_at).getTime() <= serverNow
    ) {
      setStarting(false);
      showToast("error", "This attempt has already ended.");
      return false;
    }

    const [qRes, aRes, tRes] = await Promise.all([
      fetchQuestionsForAttempt(activeExam.id),
      fetchAnswersForAttempt(attempt.id),
      fetchServerTime(),
    ]);
    if (qRes.error || aRes.error || tRes.error || !tRes.data) {
      setStarting(false);
      showToast("error", "The exam could not be loaded. Return to the list and try again.");
      return false;
    }
    if (qRes.data.length === 0) {
      setStarting(false);
      showToast("error", "Could not load the exam questions.");
      return false;
    }

    const resumed = aRes.data.length > 0;
    setDbSession({
      attemptId: attempt.id,
      examId: activeExam.id,
      deadlineAt: new Date(attempt.deadline_at).getTime(),
      clockOffset: new Date(tRes.data).getTime() - Date.now(),
      questions: qRes.data,
      initialAnswers: Object.fromEntries(aRes.data.map((a) => [a.question_id, a.selected_option])),
    });
    setStarting(false);
    setView("exam");
    showToast("success", resumed ? "Attempt resumed — your saved answers are back" : "Attempt started — the timer is live");
    return true;
  }, [activeExam, starting, showToast]);

  const handleReturnToList = useCallback(() => {
    setActiveExam(null);
    setView("dashboard");
  }, []);

  const handleSubmitted = useCallback((result: ExamResult) => {
    setResults((r) => ({ ...r, [result.examId]: result }));
  }, []);

  const handleExitExam = useCallback(() => {
    setActiveExam(null);
    setDbSession(null);
    setView("dashboard");
  }, []);

  const goLanding = useCallback(() => setView("landing"), []);

  const [invName, setInvName] = useState("");
  const [facultyName, setFacultyName] = useState("");
  const [resultsExam, setResultsExam] = useState<{ id: string; title: string; course_code: string } | null>(null);
  const [wizardExamId, setWizardExamId] = useState<string | null>(null);

  const handleFacultySignOut = useCallback(() => {
    void signOutFaculty();
    setFacultyName("");
    setView("landing");
    showToast("info", "Signed out of the faculty console");
  }, [showToast]);

  const openWizard = useCallback((id: string | null) => {
    setWizardExamId(id);
    setView("fac-wizard");
  }, []);

  return (
    <div className="relative min-h-dvh w-full overflow-hidden bg-[linear-gradient(118deg,#fdf2bf_0%,#fcdcb2_40%,#fbc8d3_76%,#f8c0ce_100%)]">
      <div className="animate-hue pointer-events-none absolute inset-0 bg-[radial-gradient(60%_45%_at_18%_12%,rgba(255,244,190,0.9),transparent_60%),radial-gradient(55%_45%_at_88%_30%,rgba(250,180,200,0.65),transparent_65%)]" />
      <div className="pointer-events-none absolute inset-0 opacity-[0.22] bg-[repeating-linear-gradient(118deg,rgba(255,255,255,0.7)_0px,rgba(255,255,255,0.7)_1px,transparent_1px,transparent_10px)]" />

      {view === "landing" && (
        <main className="relative z-10 mx-auto flex min-h-dvh w-full max-w-[1120px] flex-col justify-center gap-12 px-6 py-14 lg:flex-row lg:items-center lg:gap-20 lg:px-12">
          <section className="flex flex-col items-center gap-9 text-center lg:flex-1 lg:items-start lg:text-left">
            <SessionBadge />
            <div className="flex flex-col items-center gap-7 lg:flex-row lg:gap-8">
              <LogoTile />
              <div>
                <h1 className="text-[36px] font-extrabold leading-none tracking-tight text-neutral-900 sm:text-[42px] lg:text-[64px]">
                  Exam<span className="font-serif font-semibold italic text-rose-500">Portal</span>
                </h1>
                <p className="mt-3 text-[15px] font-medium text-neutral-500 lg:mt-4 lg:text-lg">
                  Student Assessment &amp; Testing Platform
                </p>
              </div>
            </div>
          </section>

          <section className="mx-auto flex w-full max-w-[460px] flex-col gap-5 lg:mx-0 lg:flex-1">
            <EntryCard profile={profile} onAuthenticated={handleAuthenticated} onHelp={handleLoginHelp} />

            <div className="flex flex-col gap-4">
              <button
                type="button"
                onClick={() => setView("faculty")}
                className="group animate-rise flex w-full items-center gap-3 rounded-2xl bg-white p-4 text-left shadow-[0_14px_34px_-16px_rgba(190,80,115,0.35)] transition-all duration-200 hover:-translate-y-0.5 hover:shadow-[0_20px_40px_-16px_rgba(190,80,115,0.45)] active:scale-[0.99]"
                style={{ animationDelay: "270ms" }}
              >
                <GraduationCap className="h-5 w-5 shrink-0 text-neutral-800" strokeWidth={2.1} />
                <span className="min-w-0 flex-1">
                  <span className="block text-[13.5px] font-bold leading-snug text-neutral-800">
                    Are you a faculty member or proctor?
                  </span>
                  <span className="mt-0.5 block text-[12px] font-medium text-neutral-500">
                    Access exam administration &amp; grading
                  </span>
                </span>
                <span className="flex shrink-0 items-center gap-1 text-[13px] font-bold text-rose-500">
                  Faculty Portal
                  <ArrowRight className="h-3.5 w-3.5 transition-transform duration-200 group-hover:translate-x-1" strokeWidth={2.5} />
                </span>
              </button>

              <button
                type="button"
                onClick={() => setView("inv-login")}
                className="group animate-rise flex w-full items-center gap-3 rounded-2xl bg-white p-4 text-left shadow-[0_14px_34px_-16px_rgba(190,80,115,0.35)] transition-all duration-200 hover:-translate-y-0.5 hover:shadow-[0_20px_40px_-16px_rgba(190,80,115,0.45)] active:scale-[0.99]"
                style={{ animationDelay: "310ms" }}
              >
                <Eye className="h-5 w-5 shrink-0 text-neutral-800" strokeWidth={2.1} />
                <span className="min-w-0 flex-1">
                  <span className="block text-[13.5px] font-bold leading-snug text-neutral-800">
                    Are you an invigilator?
                  </span>
                  <span className="mt-0.5 block text-[12px] font-medium text-neutral-500">
                    Approve check-ins &amp; monitor exam rooms
                  </span>
                </span>
                <span className="flex shrink-0 items-center gap-1 text-[13px] font-bold text-rose-500">
                  Invigilator Portal
                  <ArrowRight className="h-3.5 w-3.5 transition-transform duration-200 group-hover:translate-x-1" strokeWidth={2.5} />
                </span>
              </button>
            </div>

            <div className="animate-rise flex justify-center" style={{ animationDelay: "340ms" }}>
              <button
                type="button"
                onClick={() => showToast("info", "Opening channel to Controller of Exams…")}
                className="flex items-center gap-2 rounded-full bg-white px-5 py-3 shadow-[0_10px_26px_-12px_rgba(190,80,115,0.4)] transition-all duration-200 hover:-translate-y-0.5 hover:shadow-[0_16px_30px_-12px_rgba(190,80,115,0.5)] active:scale-[0.98]"
              >
                <MessageCircleMore className="h-[17px] w-[17px] text-neutral-500" strokeWidth={2} />
                <span className="text-[13px] font-semibold text-neutral-700">
                  Need help? Contact Controller of Exams
                </span>
              </button>
            </div>

            <p className="animate-rise mx-auto max-w-[320px] text-center text-[11px] font-medium leading-relaxed text-neutral-500" style={{ animationDelay: "400ms" }}>
              Academic Integrity Policy in effect. Unauthorised logins are logged &amp; monitored.
            </p>
          </section>
        </main>
      )}

      {view === "details" && activeExam && (
        <CandidateProfile
          profile={profile}
          onBack={() => {
            setActiveExam(null);
            setView("dashboard");
          }}
          onContinue={() => setView("confirm")}
        />
      )}

      {view === "waiting" && activeExam && (
        <WaitingRoom
          exam={activeExam}
          onStart={handleBeginExam}
          onLeave={() => {
            setActiveExam(null);
            setView("dashboard");
          }}
          onNotify={showToast}
        />
      )}

      {view === "dashboard" && (
        <ExamList
          profile={profile}
          onNotify={showToast}
          onSignOut={handleSignOut}
          onStartExam={handleStartExam}
        />
      )}

      {view === "confirm" && activeExam && (
        <ExamRules
          exam={activeExam}
          profile={profile}
          onBegin={() => void handleBeginExam()}
          onReturn={handleReturnToList}
          starting={checkinBusy}
          checkin={activeExam.questions.length === 0 && !activeExam.questionCount}
          onRequestCheckin={() => void handleRequestCheckin()}
        />
      )}

      {view === "exam" && activeExam && (
        <ExamFlow
          exam={activeExam}
          session={dbSession}
          onNotify={showToast}
          onSubmitted={handleSubmitted}
          onExit={handleExitExam}
          onSessionLost={() => {
            // Same exam, new check-in: the WaitingRoom → Start flow resumes
            // the attempt server-side with every saved answer intact.
            setDbSession(null);
            setView("waiting");
          }}
        />
      )}

      {view === "faculty" && (
        <FacultyLogin
          onBack={goLanding}
          onSwitchToStudent={goLanding}
          onNotify={showToast}
          onSuccess={(name) => {
            setFacultyName(name);
            setView("faculty-dash");
          }}
        />
      )}

      {view === "faculty-dash" && (
        <FacultyDashboard
          fullName={facultyName}
          onNotify={showToast}
          onSignOut={handleFacultySignOut}
          onCreate={() => openWizard(null)}
          onEdit={(id) => openWizard(id)}
          onViewResults={(exam) => {
            setResultsExam(exam);
            setView("faculty-results");
          }}
        />
      )}

      {view === "faculty-results" && resultsExam && (
        <FacultyResults exam={resultsExam} onBack={() => setView("faculty-dash")} />
      )}

      {view === "fac-wizard" && (
        <ExamWizard examId={wizardExamId} onNotify={showToast} onExit={() => setView("faculty-dash")} />
      )}

      {view === "inv-login" && (
        <InvigilatorLogin
          onBack={goLanding}
          onAuthenticated={(name) => {
            setInvName(name);
            setView("inv-panel");
            showToast("success", `Signed in — welcome, ${name.split(" ")[0]}`);
          }}
        />
      )}

      {view === "inv-panel" && (
        <InvigilatorPanel
          invigilatorName={invName}
          onNotify={showToast}
          onSignOut={() => {
            setInvName("");
            setView("landing");
            showToast("info", "Signed out of the invigilator desk");
          }}
        />
      )}

      {toast && (
        <div
          key={toast.id}
          role="status"
          className="animate-toast fixed bottom-8 left-1/2 z-40 flex max-w-[88%] items-center gap-2 rounded-full bg-neutral-950/95 px-4 py-2.5 shadow-[0_18px_40px_-10px_rgba(0,0,0,0.5)] backdrop-blur"
        >
          {toast.kind === "success" ? (
            <span className="flex h-4 w-4 shrink-0 items-center justify-center rounded-full bg-emerald-500">
              <svg viewBox="0 0 24 24" className="h-2.5 w-2.5" fill="none" stroke="white" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                <path d="M4 12.5l5 5L20 6.5" />
              </svg>
            </span>
          ) : toast.kind === "error" ? (
            <span className="flex h-4 w-4 shrink-0 items-center justify-center rounded-full bg-red-500">
              <span className="text-[10px] font-black leading-none text-white">!</span>
            </span>
          ) : (
            <span className="flex h-4 w-4 shrink-0 items-center justify-center rounded-full bg-rose-400">
              <span className="h-1.5 w-1.5 rounded-full bg-white" />
            </span>
          )}
          <span className="text-[12.5px] font-semibold text-white">{toast.msg}</span>
        </div>
      )}
    </div>
  );
}
