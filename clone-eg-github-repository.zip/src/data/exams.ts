/**
 * Exam catalogue for the student portal.
 * Question sets are real so every count/chip on the Exam List is honest.
 *
 * Each exam carries a `startsAt` timestamp; the list derives the live state:
 *   - now < startsAt                          → Coming Soon (countdown)
 *   - startsAt <= now <= startsAt + duration  → Available (live window)
 *   - now past the window, not attempted      → Missed
 *   - a result exists (or status completed)   → Completed
 *
 * Offsets below are relative to page load so every state is demonstrable.
 */

export interface ExamOption {
  id: string;
  text: string;
}

export interface ExamQuestion {
  id: string;
  topic: string;
  prompt: string;
  hint: string;
  options: ExamOption[];
  correctId: string;
}

export interface Exam {
  id: string;
  course: string;
  code: string;
  accent: "amber" | "violet" | "neutral";
  title: string;
  durationMin: number;
  marks: number;
  passing: number;
  credit: string;
  blurb: string;
  status: "available" | "completed" | "locked";
  /** Student year levels this examination is assigned to — anyone outside
   *  the cohort never sees (and therefore can never attempt) the exam. */
  cohortYears: number[];
  /** Scheduled start (epoch ms). */
  startsAt: number;
  /** Static score for pre-completed catalogue entries. */
  score?: number;
  submittedLabel?: string;
  /** Display-only question count for exams without a playable set. */
  questionCount?: number;
  questions: ExamQuestion[];
}

export interface ExamResult {
  examId: string;
  answers: Record<string, string>;
  correct: number;
  total: number;
  scorePct: number;
  submittedAt: number;
}

/** Passing threshold as a percentage of the exam's own maximum — every
 *  exam can have a different marks total and question count, so the pass
 *  rule is always expressed (and enforced) as a percentage. */
export const passPctOf = (e: Pick<Exam, "passing" | "marks">) =>
  Math.round((e.passing / e.marks) * 100);

/** The "starts soon" urgency window before an exam begins. */
export const SOON_WINDOW_MIN = 30;

const NOW = Date.now();
const at = (offsetMin: number) => NOW + offsetMin * 60_000;

const q = (
  id: string,
  topic: string,
  prompt: string,
  hint: string,
  opts: string[],
  correct: number,
): ExamQuestion => ({
  id,
  topic,
  prompt,
  hint,
  options: opts.map((text, i) => ({ id: String.fromCharCode(97 + i), text })),
  correctId: String.fromCharCode(97 + correct),
});

export const EXAMS: Exam[] = [
  {
    id: "cs301-mid",
    course: "CS301",
    code: "CS301-2025-MID",
    accent: "amber",
    title: "CS301: Data Structures & Algorithms",
    durationMin: 30,
    marks: 20,
    passing: 8,
    credit: "Standard Grade Scale",
    blurb: "Midterm examination covering arrays, linked lists, trees, graphs, and sorting. Single attempt.",
    status: "available",
    cohortYears: [1, 2, 3],
    startsAt: at(-5), // window opened 5 minutes ago — live right now
    questions: [
      q("q1", "Complexity", "Worst-case time complexity of binary search on a sorted array of n elements?", "Each comparison halves the remaining search space.", ["O(1)", "O(log n)", "O(n)", "O(n log n)"], 1),
      q("q2", "ADTs", "Which data structure processes elements in strict Last-In-First-Out order?", "Think of a stack of plates — the last one on comes off first.", ["Queue", "Priority queue", "Stack", "Deque"], 2),
      q("q3", "ADTs", "Which structure serves elements in First-In-First-Out order?", "The first element enqueued is the first one served.", ["Stack", "Queue", "Heap", "Graph"], 1),
      q("q4", "Sorting", "Quicksort degrades to O(n²) on a sorted array with which pivot choice?", "A sorted input with a first-element pivot yields fully unbalanced partitions.", ["Median-of-three", "Random pivot", "Always the first element", "It never degrades"], 2),
      q("q5", "Sorting", "Merge sort's worst-case time complexity is:", "Divide, conquer, then merge — the merge step itself is linear.", ["O(n)", "O(n log n)", "O(n²)", "O(log n)"], 1),
      q("q6", "Heaps", "In a max-heap, the largest element is always located at:", "The heap property pushes the maximum up to the top.", ["The root", "The last leaf", "The rightmost node", "Anywhere"], 0),
      q("q7", "Heaps", "In a min-heap, the smallest element sits at:", "Mirror of the max-heap: the smallest key rises to the root.", ["A random leaf", "The root", "Index n/2", "The deepest level"], 1),
      q("q8", "Trees", "Which BST traversal visits keys in ascending order?", "Left < node < right makes one traversal naturally sorted.", ["Pre-order", "In-order", "Post-order", "Level-order"], 1),
      q("q9", "Trees", "Pre-order traversal visits nodes in the order:", "The root is visited before recursing into either subtree.", ["Left, Root, Right", "Root, Left, Right", "Left, Right, Root", "Root, Right, Left"], 1),
      q("q10", "Trees", "The height of a balanced BST with n nodes is:", "Halving the subtree at each level gives logarithmic depth.", ["O(n)", "O(log n)", "O(1)", "O(n²)"], 1),
      q("q11", "Arrays", "Accessing element i of an array takes:", "Contiguous memory makes indexing a constant-time offset.", ["O(1)", "O(log n)", "O(n)", "O(i)"], 0),
      q("q12", "Lists", "Insertion at the head of a singly linked list costs:", "No shifting needed — just re-point the head pointer.", ["O(1)", "O(n)", "O(log n)", "O(n log n)"], 0),
      q("q13", "Hashing", "Average-case lookup in a hash table is:", "A good hash function spreads keys uniformly across buckets.", ["O(1)", "O(log n)", "O(n)", "O(n²)"], 0),
      q("q14", "Hashing", "Separate chaining resolves collisions by:", "Colliding keys share a bucket as a small linked list.", ["Rehashing", "Storing a list at each bucket", "Probing the next slot", "Dropping the key"], 1),
      q("q15", "Search", "Linear search over n elements is worst-case:", "In the worst case every element must be inspected.", ["O(1)", "O(log n)", "O(n)", "O(n²)"], 2),
      q("q16", "Graphs", "Breadth-first search relies on which structure?", "FIFO ordering explores the graph level by level.", ["Stack", "Queue", "Heap", "Hash map"], 1),
      q("q17", "Graphs", "Depth-first search is naturally implemented with a:", "Backtracking needs last-in-first-out ordering.", ["Queue", "Stack", "Array", "Tree"], 1),
      q("q18", "Graphs", "Dijkstra's shortest-path algorithm uses a:", "Always expand the closest unvisited vertex next.", ["Stack", "Priority queue", "Deque", "Linked list"], 1),
      q("q19", "Notation", "Which expression is evaluated using a stack?", "Operands wait on the stack until an operator arrives.", ["Prefix", "Infix with precedence", "Postfix", "Natural language"], 2),
      q("q20", "Trees", "A node in a binary tree has at most how many children?", "By definition each node has at most two children.", ["1", "2", "3", "Unlimited"], 1),
    ],
  },
  {
    id: "cs304-mid",
    course: "CS304",
    code: "CS304-2025",
    accent: "violet",
    title: "CS304: Database Systems & Architecture",
    durationMin: 45,
    marks: 30,
    passing: 12,
    credit: "Core Credit",
    blurb: "Relational algebra, SQL normalization, transactions, and indexing.",
    status: "available",
    cohortYears: [2, 3, 4],
    startsAt: at(6), // begins in ~6 minutes — shows the urgent "starts soon" state
    questions: [
      q("q1", "SQL", "Which clause filters rows in a SQL query?", "Row filtering happens before any grouping.", ["GROUP BY", "WHERE", "ORDER BY", "HAVING"], 1),
      q("q2", "SQL", "Which JOIN returns only rows with matches in both tables?", "Only mutually matching rows survive the join.", ["LEFT JOIN", "RIGHT JOIN", "INNER JOIN", "FULL OUTER JOIN"], 2),
      q("q3", "SQL", "A LEFT JOIN returns:", "Unmatched left rows still appear, padded with NULLs.", ["Only matching rows", "All left rows plus matched right rows", "All rows from both tables", "Only left rows without matches"], 1),
      q("q4", "SQL", "Which statement belongs to DDL?", "DDL defines structure rather than manipulating data.", ["SELECT", "INSERT", "CREATE TABLE", "UPDATE"], 2),
      q("q5", "Keys", "A primary key must be:", "It both identifies each row and must always exist.", ["Unique only", "Not null only", "Unique and not null", "Numeric"], 2),
      q("q6", "Keys", "A candidate key is best described as a:", "No proper subset of it can still identify rows.", ["Minimal superkey", "Foreign reference", "Composite index", "Surrogate id"], 0),
      q("q7", "Keys", "A foreign key enforces:", "It ties child rows to valid parent keys.", ["Uniqueness", "Referential integrity", "Non-nullability", "Indexing"], 1),
      q("q8", "Normalization", "2NF removes which kind of dependency?", "Non-key attributes must depend on the whole key.", ["Transitive", "Partial", "Multivalued", "Trivial"], 1),
      q("q9", "Normalization", "3NF removes which kind of dependency?", "Drop attributes that depend on other non-key attributes.", ["Partial", "Transitive", "Functional", "Key"], 1),
      q("q10", "Dependencies", "X → Y in a functional dependency means:", "Knowing X fixes the value of Y.", ["Y determines X", "X determines Y", "X and Y are independent", "X is a subset of Y"], 1),
      q("q11", "Transactions", "The 'I' in ACID stands for:", "Concurrent transactions must not interfere with each other.", ["Integrity", "Isolation", "Immutability", "Indexing"], 1),
      q("q12", "Transactions", "Which command permanently applies a transaction?", "It makes all changes durable and visible.", ["ROLLBACK", "SAVEPOINT", "COMMIT", "BEGIN"], 2),
      q("q13", "Transactions", "ROLLBACK will:", "The database returns to its pre-transaction state.", ["Apply changes", "Undo uncommitted changes", "Lock the table", "Drop the transaction log"], 1),
      q("q14", "Concurrency", "A deadlock is best described as:", "Two transactions each hold the lock the other needs.", ["A missing index", "A circular wait for locks", "A failed commit", "A full transaction log"], 1),
      q("q15", "Indexing", "The index structure most databases use by default is a:", "It keeps both lookups and range scans fast.", ["Hash table", "B+ tree", "Skip list", "Bitmap"], 1),
    ],
  },
  {
    id: "cs201-mid",
    course: "CS201",
    code: "CS201-MID",
    accent: "neutral",
    title: "CS201: Discrete Mathematics",
    durationMin: 40,
    marks: 20,
    passing: 8,
    credit: "Standard Grade Scale",
    blurb: "Propositional logic, set theory, combinatorics, and graph fundamentals.",
    status: "completed",
    cohortYears: [1, 2, 3, 4],
    startsAt: at(-60 * 26), // took place yesterday
    score: 19,
    submittedLabel: "Submitted on May 12, 10:45 AM",
    questionCount: 25,
    questions: [],
  },
  {
    id: "cs215-mid",
    course: "CS215",
    code: "CS215-2025-MID",
    accent: "violet",
    title: "CS215: Digital Logic Design",
    durationMin: 35,
    marks: 25,
    passing: 10,
    credit: "Core Credit",
    blurb: "Boolean algebra, Karnaugh maps, combinational and sequential circuit analysis.",
    status: "available",
    cohortYears: [3, 4],
    startsAt: at(-160), // window closed ~2 hours ago without an attempt → Missed
    questionCount: 20,
    questions: [],
  },
];
